#!/usr/bin/env bash
set -u

ROOT="/data3/openha_evo/probe_stage3_strict"
LOG_DIR="/data3/openha_evo/logs"
QUEUE="${ROOT}/queue.txt"
mkdir -p "${ROOT}" "${LOG_DIR}"

cat > "${QUEUE}" <<'EOF'
42|same_task_allowed|same
42|exclude_eval_task|task
42|exclude_eval_task_entity|strict
43|same_task_allowed|same
43|exclude_eval_task|task
43|exclude_eval_task_entity|strict
44|same_task_allowed|same
44|exclude_eval_task|task
44|exclude_eval_task_entity|strict
EOF

run_one() {
    local seed="$1"
    local protocol="$2"
    local kind="$3"
    local gpu="$4"
    local out="${ROOT}/seed${seed}/${protocol}"
    local flags=""
    if [[ "${kind}" == "task" ]]; then
        flags="--exclude-eval-task"
    elif [[ "${kind}" == "strict" ]]; then
        flags="--exclude-eval-task --exclude-eval-entity"
    fi
    mkdir -p "${out}"
    /opt/miniconda3/envs/vllm_env/bin/python \
        /data3/openha_evo/probe_stage3.py \
        --arms prefix_uniform_3,retrieval_uniform_5,retrieval_state_3 \
        --gpus "${gpu}" --sequential --bench-seed "${seed}" \
        --output-root "${out}" --max-steps 400 ${flags}
    /opt/miniconda3/envs/vllm_env/bin/python \
        /data3/openha_evo/repair_stage3_missing.py \
        --root "${out}" --seed "${seed}" --protocol "${kind}" \
        --arms prefix_uniform_3,retrieval_uniform_5,retrieval_state_3 \
        --gpu "${gpu}" --max-steps 400
}

worker() {
    local input="$1"
    local label="$2"
    local gpu="$3"
    while IFS='|' read -r seed protocol kind; do
        [[ -z "${seed}" ]] && continue
        echo "[$(date '+%F %T')] worker=${label} seed=${seed} protocol=${protocol}" 
        run_one "${seed}" "${protocol}" "${kind}" "${gpu}"
    done < "${input}"
}

awk 'NR % 2 == 1' "${QUEUE}" > "${QUEUE}.a"
awk 'NR % 2 == 0' "${QUEUE}" > "${QUEUE}.b"
worker "${QUEUE}.a" a 1 > "${LOG_DIR}/stage3_strict_worker_a.log" 2>&1 &
pid_a=$!
worker "${QUEUE}.b" b 3 > "${LOG_DIR}/stage3_strict_worker_b.log" 2>&1 &
pid_b=$!
echo "${pid_a}" > "${ROOT}/worker_pids.txt"
echo "${pid_b}" >> "${ROOT}/worker_pids.txt"
wait "${pid_a}"; rc_a=$?
wait "${pid_b}"; rc_b=$?
exit $((rc_a || rc_b))
