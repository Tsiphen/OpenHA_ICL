"""Probe Stage 3: automated visual-search-space sweep on the bare OpenHA model.

Baseline switched to the original OpenHA (``openha_eager_icl``): frozen
Qwen2-VL-7B **without** the retrained LoRA adapter, text-ICL on, image-ICL off
by default. Each arm adds image ICL by mutating three orthogonal axes:

    source     : prefix    (exact dir, else category-prefix fallback)
                 retrieval (attribute-similarity memory bank)
    frame_mode : uniform / state / coverage
    k          : 1 / 3 / 5

This is the Stage-3 search space (2 x 3 x 3 = 18 arms). The search is offline
first: ``--offline`` validates every arm by building demos over the kill_entity
subset (no GPU, no VLM forward pass), reporting per-arm empty-demo counts and
per-task demo coverage. GPU mode launches the real eval via ``run_streaming_eval``.

Env var contract (see harness/candidates/search_demo_harness.py):
    OPENHA_DEMO_SOURCE  OPENHA_FRAME_MODE  OPENHA_ICL_K
"""

import argparse
import collections
import json
import os
import subprocess
import sys
import time

import config
import experiment_guard
import metrics
import sub_vla
from harness import visual_memory
from harness.candidates.search_demo_harness import SearchDemoHarness

CONFIG_NAME = "openha_eager_icl"  # bare model: no LoRA, text ICL on
OUT_ROOT = os.path.join(config.EVO_ROOT, "probe_stage3")
SEARCH_HARNESS = os.path.join(config.EVO_ROOT, "harness", "candidates", "search_demo_harness.py")
MEMORY_BANK = os.path.join(config.EVO_ROOT, "eval", "icl_memory_bank", "kill_entity_bank.json")
POOL_ROOT = "/data3/openha_evo/eval/icl_success_pool/00_original_icl_trainonly"
GPU_MIN_FREE_MB = 25000
BENCH_SEED = config.BENCH_SEED

SOURCES = ["prefix", "retrieval"]
FRAME_MODES = ["uniform", "state", "coverage"]
KS = [1, 3, 5]


def build_arms():
    arms = []
    for source in SOURCES:
        for frame in FRAME_MODES:
            for k in KS:
                arms.append({
                    "name": f"{source}_{frame}_{k}",
                    "source": source,
                    "frame_mode": frame,
                    "k": k,
                })
    return arms


def build_kill_subset(limit=None):
    tasks = metrics.read_task_list(config.TRAIN_TASKS)
    subset = [t for t in tasks if config.category(t) == "kill_entity"]
    if limit is not None:
        subset = subset[:limit]
    os.makedirs(OUT_ROOT, exist_ok=True)
    path = os.path.join(OUT_ROOT, "kill_entity_subset.txt")
    with open(path, "w") as f:
        f.write("\n".join(subset) + ("\n" if subset else ""))
    return path, subset


def ensure_memory_bank():
    rebuild = not os.path.exists(MEMORY_BANK)
    if not rebuild:
        try:
            experiment_guard.assert_bank_has_known_splits(MEMORY_BANK)
            return
        except RuntimeError:
            rebuild = True
    os.makedirs(os.path.dirname(MEMORY_BANK), exist_ok=True)
    entries = visual_memory.build_bank(
        POOL_ROOT, MEMORY_BANK, categories=["kill_entity"],
        train_tasks_path=config.TRAIN_TASKS, test_tasks_path=config.TEST_TASKS)
    print(f"[stage3] built memory bank: {len(entries)} entries -> {MEMORY_BANK}", flush=True)


def arm_env(arm, exclude_eval_task=False, exclude_eval_entity=False):
    env = {
        "OPENHA_HARNESS_PATH": SEARCH_HARNESS,
        "OPENHA_AGENT_MODULE": "streaming_openha_original_harness",
        "OPENHA_DEMO_SOURCE": arm["source"],
        "OPENHA_FRAME_MODE": arm["frame_mode"],
        "OPENHA_ICL_K": str(arm["k"]),
        "OPENHA_SUCCESS_POOL": POOL_ROOT,
        "OPENHA_MEMORY_BANK": MEMORY_BANK,
    }
    if exclude_eval_task:
        env["OPENHA_EXCLUDE_EVAL_TASK"] = "1"
    if exclude_eval_entity:
        env["OPENHA_EXCLUDE_EVAL_ENTITY"] = "1"
    return env


def offline_validate(subset, arms=None, limit=None, exclude_eval_task=False,
                     exclude_eval_entity=False):
    """Build demos for every arm over the subset without touching the VLM/GPU."""
    os.environ["OPENHA_SUCCESS_POOL"] = POOL_ROOT
    os.environ["OPENHA_MEMORY_BANK"] = MEMORY_BANK
    tasks = subset if limit is None else subset[:limit]
    report = {}
    for arm in (arms or build_arms()):
        harness = SearchDemoHarness(
            source=arm["source"], frame_mode=arm["frame_mode"], k=arm["k"],
            exclude_eval_task=exclude_eval_task,
            exclude_eval_entity=exclude_eval_entity)
        empty = 0
        short = 0
        per_task = {}
        for t in tasks:
            demos = harness.build_visual_demos("", t)
            n = len(demos)
            per_task[t] = n
            if n == 0:
                empty += 1
            elif n < arm["k"]:
                short += 1
        report[arm["name"]] = {
            "tasks": len(tasks),
            "empty": empty,
            "short_of_k": short,
            "avg_demos": round(sum(per_task.values()) / max(1, len(tasks)), 3),
            "sample": {t: per_task[t] for t in tasks[:3]},
        }
        print(f"[offline] {arm['name']}: empty={empty}/{len(tasks)} "
              f"short={short} avg_demos={report[arm['name']]['avg_demos']}", flush=True)
    return report


def parse_gpus(spec):
    if not spec.strip():
        return None
    return [int(x.strip()) for x in spec.split(",") if x.strip() != ""]


def pick_free_gpus(n, min_free_mb=GPU_MIN_FREE_MB):
    out = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=index,memory.used,memory.total", "--format=csv,noheader,nounits"],
        text=True,
    )
    gpus = []
    for line in out.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 3:
            idx, used, total = int(parts[0]), int(parts[1]), int(parts[2])
            gpus.append((idx, total - used))
    gpus.sort(key=lambda x: -x[1])
    chosen = [idx for idx, free in gpus if free >= min_free_mb][:n]
    if len(chosen) < n:
        raise RuntimeError(f"Need {n} GPUs with >= {min_free_mb} MB free, found {len(chosen)}")
    return chosen


def launch_arm(arm, subset_path, gpu, max_steps,
               exclude_eval_task=False, exclude_eval_entity=False):
    record_path = os.path.join(OUT_ROOT, arm["name"])
    os.makedirs(record_path, exist_ok=True)
    log_file = os.path.join(config.LOGS_DIR, f"probe_stage3_{arm['name']}.log")
    # Bare model: no lora_adapter_path.
    proc = sub_vla.run_eval(
        CONFIG_NAME, subset_path, record_path, gpu,
        max_steps=max_steps, log_file=log_file,
        lora_adapter_path=None, bench_seed=BENCH_SEED,
        extra_env=arm_env(arm, exclude_eval_task, exclude_eval_entity),
    )
    print(f"[stage3] launched {arm['name']} gpu={gpu} pid={proc.pid}", flush=True)
    return record_path, proc


def collect_arm(arm, record_path, proc, subset_path):
    rc = proc.wait()
    result_dir = os.path.join(record_path, CONFIG_NAME)
    m = metrics.compute_metrics(result_dir, subset_path) if rc == 0 else None
    asr = m["overall"]["asr"] if m else None
    entry = {
        "rc": rc,
        "asr": asr,
        "by_category": m["by_category"] if m else None,
        "missing": len(m["missing"]) if m else None,
    }
    print(f"[stage3] {arm['name']} rc={rc} asr={asr}", flush=True)
    return entry


def run_parallel(arms, subset_path, gpus, max_steps,
                 exclude_eval_task=False, exclude_eval_entity=False):
    """Run all arms across ``gpus``, one arm per GPU at a time (work queue).

    Fixes the ``zip(arms, gpus)`` truncation bug: when there are more arms than
    GPUs, finished arms are replaced by the next pending arm on the freed GPU
    instead of silently dropping the tail arms.
    """
    summary = {}
    pending = collections.deque(arms)
    running = {}  # gpu -> (arm, record_path, proc)

    # Initial wave: fill every GPU with one arm.
    for gpu in gpus:
        if not pending:
            break
        arm = pending.popleft()
        record_path, proc = launch_arm(
            arm, subset_path, gpu, max_steps,
            exclude_eval_task, exclude_eval_entity)
        running[gpu] = (arm, record_path, proc)

    while running:
        finished_gpu = None
        for gpu, (arm, record_path, proc) in running.items():
            if proc.poll() is not None:
                summary[arm["name"]] = collect_arm(arm, record_path, proc, subset_path)
                finished_gpu = gpu
                break
        if finished_gpu is None:
            time.sleep(2)
            continue
        del running[finished_gpu]
        if pending:
            arm = pending.popleft()
            record_path, proc = launch_arm(
                arm, subset_path, finished_gpu, max_steps,
                exclude_eval_task, exclude_eval_entity)
            running[finished_gpu] = (arm, record_path, proc)

    return summary


def main():
    global OUT_ROOT, BENCH_SEED
    p = argparse.ArgumentParser(description="Stage-3 visual search-space sweep (bare OpenHA)")
    p.add_argument("--offline", action="store_true", help="validate arms without GPU/VLM")
    p.add_argument("--max-steps", type=int, default=config.DEFAULT_MAX_STEPS)
    p.add_argument("--bench-seed", type=int, default=config.BENCH_SEED)
    p.add_argument("--output-root", default=OUT_ROOT,
                   help="root directory for this seed/protocol run")
    p.add_argument("--arms", default="", help="comma-separated arm names (default: all 18)")
    p.add_argument("--gpus", default="", help="comma-separated GPU indices (default: auto-pick)")
    p.add_argument("--sequential", action="store_true", help="run arms one at a time on first GPU")
    p.add_argument("--subset-limit", type=int, default=None, help="cap subset to N tasks")
    p.add_argument("--exclude-eval-task", action="store_true",
                   help="do not allow a task to retrieve demos from itself")
    p.add_argument("--exclude-eval-entity", action="store_true",
                   help="for entity tasks, do not allow demos from the same entity")
    args = p.parse_args()

    OUT_ROOT = os.path.abspath(args.output_root)
    BENCH_SEED = args.bench_seed

    ensure_memory_bank()
    subset_path, subset = build_kill_subset(limit=args.subset_limit)
    guard = experiment_guard.assert_no_test_leak(POOL_ROOT, MEMORY_BANK)
    config_path, snapshot = experiment_guard.write_run_config_snapshot(
        OUT_ROOT,
        stage="stage3_clean_core_sweep",
        config_name=CONFIG_NAME,
        success_pool=POOL_ROOT,
        memory_bank=MEMORY_BANK,
        task_list=subset_path,
        subset_limit=args.subset_limit,
        arms=args.arms or "all",
        max_steps=args.max_steps,
        bench_seed=BENCH_SEED,
        exclude_eval_task=args.exclude_eval_task,
        exclude_eval_entity=args.exclude_eval_entity,
        guard=guard,
    )
    print(f"[stage3] guard ok; run config -> {config_path}", flush=True)
    print(f"[stage3] run config sha256 = {snapshot['config_sha256']}", flush=True)
    print(f"[stage3] kill_entity subset = {len(subset)} tasks -> {subset_path}", flush=True)

    arms = build_arms()
    if args.arms:
        want = set(args.arms.split(","))
        arms = [a for a in arms if a["name"] in want]
    if not arms:
        print("ERROR: no arms selected", file=sys.stderr)
        sys.exit(2)
    print(f"[stage3] {len(arms)} arms, config={CONFIG_NAME} (bare, no LoRA)", flush=True)

    if args.offline:
        report = offline_validate(
            subset, arms=arms, limit=args.subset_limit,
            exclude_eval_task=args.exclude_eval_task,
            exclude_eval_entity=args.exclude_eval_entity)
        out_path = os.path.join(OUT_ROOT, "offline_search_validation.json")
        with open(out_path, "w") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        print(f"[stage3] offline validation -> {out_path}", flush=True)
        return

    if args.gpus:
        gpus = parse_gpus(args.gpus)
    elif args.sequential:
        gpus = pick_free_gpus(1)
    else:
        gpus = pick_free_gpus(len(arms))
    print(f"[stage3] GPUs = {gpus}", flush=True)

    summary = {}
    if args.sequential:
        gpu = gpus[0]
        for arm in arms:
            record_path, proc = launch_arm(
                arm, subset_path, gpu, args.max_steps,
                args.exclude_eval_task, args.exclude_eval_entity)
            summary[arm["name"]] = collect_arm(arm, record_path, proc, subset_path)
    else:
        summary = run_parallel(
            arms, subset_path, gpus, args.max_steps,
            args.exclude_eval_task, args.exclude_eval_entity)

    out_path = os.path.join(OUT_ROOT, "probe_summary.json")
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"[stage3] summary -> {out_path}", flush=True)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
