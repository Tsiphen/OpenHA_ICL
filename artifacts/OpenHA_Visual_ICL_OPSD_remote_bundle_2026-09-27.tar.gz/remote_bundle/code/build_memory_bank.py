"""Build the offline visual memory bank for image-ICL retrieval (Stage 2B).

Scans the success pool, records each rollout's entity attributes and action
signature, and writes a lightweight JSON index. Frames are not copied; the index
stores rollout paths and frames are re-read on demand during retrieval.
"""

import argparse
import json
import os

import config
from harness import visual_memory

DEFAULT_POOL = "/data3/openha_evo/eval/icl_success_pool/00_original_icl_trainonly"
DEFAULT_OUT = "/data3/openha_evo/eval/icl_memory_bank/kill_entity_bank.json"


def main():
    p = argparse.ArgumentParser(description="Build visual memory bank")
    p.add_argument("--pool", default=DEFAULT_POOL)
    p.add_argument("--out", default=DEFAULT_OUT)
    p.add_argument("--categories", default="kill_entity",
                   help="comma-separated categories to index")
    args = p.parse_args()

    cats = [c.strip() for c in args.categories.split(",") if c.strip()]
    entries = visual_memory.build_bank(
        args.pool, args.out, categories=cats,
        train_tasks_path=config.TRAIN_TASKS, test_tasks_path=config.TEST_TASKS)

    by_entity = {}
    for e in entries:
        by_entity.setdefault(e["entity"], 0)
        by_entity[e["entity"]] += 1
    print(f"[bank] wrote {len(entries)} entries -> {args.out}")
    print(f"[bank] {len(by_entity)} entities: "
          f"{json.dumps(by_entity, sort_keys=True)}")


if __name__ == "__main__":
    main()
