#!/usr/bin/env python3
"""Build matched ordinary self-imitation and fixed-prefix control files."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def read_jsonl(path):
    text = Path(path).read_text(encoding="utf-8")
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        return [json.loads(line) for line in text.splitlines() if line.strip()]
    return value if isinstance(value, list) else [value]


def write_jsonl(path, rows):
    with Path(path).open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def replace_target(sample, target):
    sample = json.loads(json.dumps(sample))
    sample["target_type"] = "recorded_action"
    sample["target"] = target
    sample["messages"][-1]["content"][0]["text"] = target
    return sample


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--opsd1-dir", required=True)
    parser.add_argument("--replay", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    opsd1 = Path(args.opsd1_dir)
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    replay = read_jsonl(args.replay)
    by_key = {(r["task"], int(r["prefix_index"])): r for r in replay}
    for split in ("train", "eval"):
        rows = read_jsonl(opsd1 / f"{split}.jsonl")
        imitation = []
        for row in rows:
            src = by_key[(row["task"], int(row["prefix_index"]))]
            imitation.append(replace_target(row, src.get("recorded_action_text", "Action: no_op ")))
        write_jsonl(out / f"{split}.jsonl", imitation)
    # Keep all replay conditions aligned to the exact 64 selected query prefixes.
    selected = []
    for split in ("train", "eval"):
        selected.extend(read_jsonl(opsd1 / f"{split}.jsonl"))
    for condition in ("current_history", "truncation_control", "success_demo",
                      "category_demo", "negative_demo"):
        rows = []
        for sample in selected:
            src = by_key.get((sample["task"], int(sample["prefix_index"])))
            if not src:
                continue
            item = {
                "id": sample["id"],
                "task": sample["task"],
                "prefix_index": sample["prefix_index"],
                "phase": sample["phase"],
                "condition": condition,
                "teacher_content": src.get("content", ""),
                "recorded_action_text": src.get("recorded_action_text", ""),
                "decoded_action": src.get("decoded_action", {}),
                "source_rollout": src.get("rollout_dir"),
            }
            rows.append(item)
        write_jsonl(out / f"{condition}.jsonl", rows)
    (out / "manifest.json").write_text(json.dumps({
        "project": "ICL-OpenHA",
        "stage": "OPSD-controls",
        "ordinary_self_imitation": "recorded_action_text",
        "conditions": ["frozen_no_demo", "frozen_success_demo",
                       "ordinary_self_imitation", "category_demo", "negative_demo"],
        "rows_per_condition": 64,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
