#!/usr/bin/env python3
"""Run one held-out generation variant per process to avoid GPU fragmentation."""

from __future__ import annotations

import argparse
import gc
import json
from pathlib import Path

import torch
from peft import PeftModel
from qwen_vl_utils import process_vision_info
from transformers import AutoProcessor, Qwen2VLForConditionalGeneration


def read_rows(path):
    return [json.loads(line) for line in Path(path).open(encoding="utf-8") if line.strip()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-path", required=True)
    ap.add_argument("--eval-jsonl", required=True)
    ap.add_argument("--variant", required=True)
    ap.add_argument("--adapter")
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    processor = AutoProcessor.from_pretrained(args.model_path, trust_remote_code=True)
    base = Qwen2VLForConditionalGeneration.from_pretrained(
        args.model_path, torch_dtype=torch.float16, device_map="auto",
        trust_remote_code=True, attn_implementation="sdpa",
    )
    model = PeftModel.from_pretrained(base, args.adapter) if args.adapter else base
    model.eval()
    device = next(model.parameters()).device
    results = []
    for row in read_rows(args.eval_jsonl):
        messages = row["messages"][:-1]
        text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        images, videos = process_vision_info(messages)
        x = processor(text=[text], images=images, videos=videos,
                      return_tensors="pt", padding=True)
        x = {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in x.items()}
        with torch.no_grad():
            out = model.generate(**x, max_new_tokens=64, do_sample=False)
        prompt_len = x["input_ids"].shape[1]
        decoded = processor.batch_decode(out[:, prompt_len:], skip_special_tokens=False)[0]
        results.append({
            "variant": args.variant,
            "id": row["id"],
            "task": row["task"],
            "phase": row["phase"],
            "target_teacher_text": row.get("teacher_target", ""),
            "generated": decoded,
        })
    Path(args.output).write_text(json.dumps({
        "stage": "held-out-no-demo-generation",
        "variant": args.variant,
        "eval_rows": len(results),
        "results": results,
        "environment_success_rate": None,
    }, indent=2, ensure_ascii=False))
    del model, base, processor
    gc.collect()
    torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
