"""Protocol guardrails for leakage-safe OpenHA ICL experiments.

This module centralises the checks that make a run paper-grade:

  - write success-pool manifests with train/test split provenance
  - assert demo pools and retrieval banks do not contain held-out TEST_V2 tasks
  - write run configuration snapshots and stable hashes
  - mark old pre-leakfix result directories as exploratory

The checks are intentionally fail-closed. If a task cannot be assigned to a
known split, it is treated as unsafe for final experiments.
"""

import argparse
import datetime as _dt
import hashlib
import json
import os

import config
import metrics
from harness import visual_memory


KNOWN_CATEGORIES = ("kill_entity", "mine_block", "custom", "craft_item")
REQUIRED_ROLLOUT_FILES = ("episode.jsonl", "action.jsonl", "success.json")


def utc_now():
    return _dt.datetime.now(_dt.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_json(obj):
    payload = json.dumps(obj, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def read_task_set(path):
    return set(metrics.read_task_list(path))


def task_from_dirname(name):
    """Convert success-pool directory names back to colon task names."""
    if ":" in name:
        return name
    for cat in KNOWN_CATEGORIES:
        prefix = cat + "_"
        if name.startswith(prefix):
            return cat + ":" + name[len(prefix):]
    head, _, tail = name.partition("_")
    return head + ":" + tail if tail else name


def dirname_from_task(task):
    return task.replace(":", "_")


def split_of_task(task, train_tasks, test_tasks):
    if task in train_tasks:
        return "train"
    if task in test_tasks:
        return "test"
    return "unknown"


def iter_rollouts(pool_root):
    if not os.path.isdir(pool_root):
        return
    for task_dirname in sorted(os.listdir(pool_root)):
        task_dir = os.path.join(pool_root, task_dirname)
        if not os.path.isdir(task_dir):
            continue
        task = task_from_dirname(task_dirname)
        for rollout_id in sorted(os.listdir(task_dir)):
            rollout_dir = os.path.join(task_dir, rollout_id)
            if not os.path.isdir(rollout_dir):
                continue
            if not os.path.exists(os.path.join(rollout_dir, "episode.jsonl")):
                continue
            yield task, task_dirname, rollout_id, rollout_dir


def rollout_file_status(rollout_dir):
    status = {}
    for fn in REQUIRED_ROLLOUT_FILES + ("info.jsonl", "thought.jsonl", "loss.json"):
        path = os.path.join(rollout_dir, fn)
        status[fn] = {
            "exists": os.path.exists(path),
            "size": os.path.getsize(path) if os.path.exists(path) else 0,
        }
    return status


def build_pool_manifest(pool_root, out_path, train_tasks_path=None, test_tasks_path=None):
    train_tasks = read_task_set(train_tasks_path or config.TRAIN_TASKS)
    test_tasks = read_task_set(test_tasks_path or config.TEST_TASKS)
    entries = []
    task_splits = {}

    for task, task_dirname, rollout_id, rollout_dir in iter_rollouts(pool_root) or []:
        split = split_of_task(task, train_tasks, test_tasks)
        task_splits[task] = split
        files = rollout_file_status(rollout_dir)
        entries.append({
            "task": task,
            "task_dirname": task_dirname,
            "split": split,
            "rollout_id": rollout_id,
            "rollout_dir": rollout_dir,
            "files": files,
            "complete": all(files[fn]["exists"] and files[fn]["size"] > 0
                            for fn in REQUIRED_ROLLOUT_FILES),
            "has_thought": files["thought.jsonl"]["exists"] and files["thought.jsonl"]["size"] > 0,
        })

    leaked_test_tasks = sorted(t for t, s in task_splits.items() if s == "test")
    unknown_tasks = sorted(t for t, s in task_splits.items() if s == "unknown")
    summary = {
        "created_at": utc_now(),
        "pool_root": pool_root,
        "train_tasks_path": train_tasks_path or config.TRAIN_TASKS,
        "test_tasks_path": test_tasks_path or config.TEST_TASKS,
        "train_tasks_sha256": sha256_file(train_tasks_path or config.TRAIN_TASKS),
        "test_tasks_sha256": sha256_file(test_tasks_path or config.TEST_TASKS),
        "rollout_count": len(entries),
        "task_count": len(task_splits),
        "split_counts": {
            "train": sum(1 for s in task_splits.values() if s == "train"),
            "test": sum(1 for s in task_splits.values() if s == "test"),
            "unknown": sum(1 for s in task_splits.values() if s == "unknown"),
        },
        "leaked_test_tasks": leaked_test_tasks,
        "unknown_tasks": unknown_tasks,
        "complete_rollouts": sum(1 for e in entries if e["complete"]),
        "thought_rollouts": sum(1 for e in entries if e["has_thought"]),
    }
    manifest = {"summary": summary, "entries": entries}
    manifest["summary"]["manifest_sha256"] = sha256_json(entries)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    return manifest


def load_bank_tasks(bank_path):
    if not bank_path or not os.path.exists(bank_path):
        return []
    with open(bank_path) as f:
        bank = json.load(f)
    tasks = []
    for entry in bank:
        task = entry.get("task", "")
        if task:
            tasks.append(task_from_dirname(task))
    return tasks


def assert_no_test_leak(pool_root, bank_path=None, train_tasks_path=None,
                        test_tasks_path=None, require_known=True):
    train_tasks = read_task_set(train_tasks_path or config.TRAIN_TASKS)
    test_tasks = read_task_set(test_tasks_path or config.TEST_TASKS)

    pool_tasks = sorted({task for task, _, _, _ in iter_rollouts(pool_root) or []})
    bank_tasks = sorted(set(load_bank_tasks(bank_path)))
    all_demo_tasks = sorted(set(pool_tasks) | set(bank_tasks))

    leaked = [t for t in all_demo_tasks if t in test_tasks]
    unknown = [t for t in all_demo_tasks if t not in train_tasks and t not in test_tasks]
    if leaked:
        raise RuntimeError(
            "TEST_V2 demo leakage detected: " + ", ".join(leaked)
        )
    if require_known and unknown:
        raise RuntimeError(
            "Unknown-split demo tasks detected: " + ", ".join(unknown)
        )
    return {
        "pool_root": pool_root,
        "bank_path": bank_path,
        "pool_task_count": len(pool_tasks),
        "bank_task_count": len(bank_tasks),
        "demo_task_count": len(all_demo_tasks),
        "leaked_test_tasks": leaked,
        "unknown_tasks": unknown,
        "train_demo_tasks": [t for t in all_demo_tasks if t in train_tasks],
    }


def assert_bank_has_known_splits(bank_path):
    if not bank_path or not os.path.exists(bank_path):
        return {"bank_path": bank_path, "exists": False, "entries": 0}
    with open(bank_path) as f:
        bank = json.load(f)
    missing = [i for i, e in enumerate(bank) if e.get("split") not in ("train", "test")]
    if missing:
        raise RuntimeError(
            f"Retrieval bank has {len(missing)} entries without known split: {bank_path}"
        )
    return {"bank_path": bank_path, "exists": True, "entries": len(bank)}


def write_run_config_snapshot(out_dir, **kwargs):
    os.makedirs(out_dir, exist_ok=True)
    snapshot = {
        "created_at": utc_now(),
        "config": kwargs,
        "paths": {
            "train_tasks": config.TRAIN_TASKS,
            "test_tasks": config.TEST_TASKS,
            "evo_root": config.EVO_ROOT,
        },
        "hashes": {
            "train_tasks_sha256": sha256_file(config.TRAIN_TASKS),
            "test_tasks_sha256": sha256_file(config.TEST_TASKS),
        },
    }
    for key in ("success_pool", "memory_bank", "task_list", "manifest"):
        path = kwargs.get(key)
        if path and os.path.exists(path) and os.path.isfile(path):
            snapshot["hashes"][key + "_sha256"] = sha256_file(path)
    snapshot["config_sha256"] = sha256_json(snapshot)
    path = os.path.join(out_dir, "run_config.json")
    with open(path, "w") as f:
        json.dump(snapshot, f, indent=2, ensure_ascii=False)
    return path, snapshot


def mark_exploratory(paths):
    marker = (
        "# Exploratory Pre-Leakfix Result\n\n"
        "This result directory predates the train-only demo-pool guardrails or "
        "was produced before final protocol lock. Use it for method exploration "
        "only; do not report it as a final paper number.\n"
    )
    marked = []
    for path in paths:
        if not os.path.isdir(path):
            continue
        out = os.path.join(path, "EXPLORATORY_PRE_LEAKFIX.md")
        with open(out, "w") as f:
            f.write(marker)
        marked.append(out)
    return marked


def stage0(args):
    out_dir = args.out_dir
    os.makedirs(out_dir, exist_ok=True)

    if args.rebuild_bank:
        visual_memory.build_bank(
            args.pool_root, args.bank_path, categories=["kill_entity"],
            train_tasks_path=config.TRAIN_TASKS, test_tasks_path=config.TEST_TASKS)

    train_manifest_path = os.path.join(out_dir, "pool_manifest_trainonly.json")
    train_manifest = build_pool_manifest(args.pool_root, train_manifest_path)

    annotated_manifest_path = os.path.join(out_dir, "pool_manifest_annotated.json")
    annotated_manifest = build_pool_manifest(args.annotated_pool_root, annotated_manifest_path)

    checks = {
        "pool_guard": assert_no_test_leak(args.pool_root, args.bank_path),
        "bank_split": assert_bank_has_known_splits(args.bank_path),
        "train_manifest": train_manifest["summary"],
        "annotated_manifest": annotated_manifest["summary"],
    }
    config_path, snapshot = write_run_config_snapshot(
        out_dir,
        stage="stage0_protocol_lock",
        success_pool=args.pool_root,
        annotated_pool=args.annotated_pool_root,
        memory_bank=args.bank_path,
        manifest=train_manifest_path,
    )
    checks["run_config"] = {
        "path": config_path,
        "config_sha256": snapshot["config_sha256"],
    }

    if args.mark_old:
        old_paths = [
            os.path.join(config.EVO_ROOT, "probe_image_icl"),
            os.path.join(config.EVO_ROOT, "probe_stage2"),
            os.path.join(config.EVO_ROOT, "probe_stage3"),
            os.path.join(config.EVO_ROOT, "probe_stage3b"),
        ]
        checks["marked_exploratory"] = mark_exploratory(old_paths)

    checks_path = os.path.join(out_dir, "stage0_checks.json")
    with open(checks_path, "w") as f:
        json.dump(checks, f, indent=2, ensure_ascii=False)
    print(json.dumps(checks, indent=2, ensure_ascii=False))
    print(f"[guard] wrote {checks_path}")
    return checks


def main():
    parser = argparse.ArgumentParser(description="OpenHA ICL protocol guardrails")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p0 = sub.add_parser("stage0", help="write manifests and run leakage checks")
    p0.add_argument("--pool-root", default=os.path.join(
        config.EVO_ROOT, "eval", "icl_success_pool", "00_original_icl_trainonly"))
    p0.add_argument("--annotated-pool-root", default=os.path.join(
        config.EVO_ROOT, "eval", "icl_success_pool", "01_annotated_icl"))
    p0.add_argument("--bank-path", default=os.path.join(
        config.EVO_ROOT, "eval", "icl_memory_bank", "kill_entity_bank.json"))
    p0.add_argument("--out-dir", default=os.path.join(config.EVO_ROOT, "stage0_protocol"))
    p0.add_argument("--mark-old", action="store_true")
    p0.add_argument("--no-rebuild-bank", dest="rebuild_bank", action="store_false")
    p0.set_defaults(rebuild_bank=True)

    args = parser.parse_args()
    if args.cmd == "stage0":
        stage0(args)


if __name__ == "__main__":
    main()
