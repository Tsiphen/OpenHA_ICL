"""Add OPENHA_HARNESS_PATH hook to a writable copy of the original agent.

The original `streaming_openha_original.py` is owned by `user` (read-only), so
we produce `streaming_openha_original_harness.py` (writable) and add an
`OPENHA_AGENT_MODULE` env override to `run_streaming_eval_evo.py` so the eval
script can point at the patched module. Backward-compatible when env is unset.

Wires the Meta-Harness three-method interface plus multimodal ICL:

  - build_context(instruction, task_name, obs=None)  -> injected at reset()
  - build_visual_demos(instruction, task_name, obs=None) -> image demo pairs
  - learn_from_rollout(task_name, success, trajectory=None) -> fired after each rollout
  - get_state()/set_state(state)  -> exposed as agent.get_harness_state()/set_harness_state()

The image demos are prepended as (user image -> assistant text) messages in a
backward-compatible override of `gen_response`, so text-only harnesses behave
identically to the original.
"""

import sys

SRC = "/data3/openha_repro/streaming_openha_original.py"
DST = "/data3/openha_repro/streaming_openha_original_harness.py"
EVAL = "/data3/openha_repro/run_streaming_eval_evo.py"

with open(SRC) as f:
    text = f.read()

edits = []

# 1. Cache + visual-demo slots in __init__.
edits.append((
    "        self._icl_enabled = icl_enabled\n"
    "        openha_output_mode = output_mode\n",
    "        self._icl_enabled = icl_enabled\n"
    "        self._harness_cache = None\n"
    "        self._icl_image_demos = []\n"
    "        openha_output_mode = output_mode\n",
))

# 2. Add harness loading + learn/state helpers + multimodal hook + gen_response override.
old2 = (
    "    def _build_icl_instruction(self, instruction: str, task_name: str) -> str:\n"
    "        if not self._icl_enabled or not task_name:\n"
    "            return instruction\n"
    "\n"
    "        category = task_name.split(\":\", 1)[0]\n"
)
new2 = '''    def _load_harness(self, harness_path: str):
        """Load a candidate harness module from OPENHA_HARNESS_PATH.

        A harness may be exposed as a module-level HARNESS instance, a
        build_context / build_icl_instruction function, or a Harness class.
        The loaded object is cached on the agent so build_context, build_visual_demos,
        learn_from_rollout, get_state and set_state all reuse the same instance.
        """
        if self._harness_cache is not None and self._harness_cache[0] == harness_path:
            return self._harness_cache[1]
        import importlib.util
        pkg_dir = os.path.dirname(os.path.dirname(os.path.dirname(harness_path)))
        if pkg_dir and pkg_dir not in sys.path:
            sys.path.insert(0, pkg_dir)
        spec = importlib.util.spec_from_file_location("openha_harness", harness_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        h = getattr(mod, "HARNESS", None)
        if h is None:
            fn = getattr(mod, "build_context", None) or getattr(mod, "build_icl_instruction", None)
            if callable(fn):
                h = type("FnHarness", (), {"build_context": staticmethod(fn)})()
        if h is None:
            cls = getattr(mod, "Harness", None)
            if cls is not None:
                h = cls()
        if h is None:
            raise RuntimeError(
                f"Harness module {harness_path} must expose HARNESS, build_context, "
                "build_icl_instruction, or Harness"
            )
        self._harness_cache = (harness_path, h)
        return h

    def learn_from_rollout(self, task_name: str, success: bool, trajectory=None) -> None:
        """Signal the active harness to learn from a finished rollout."""
        harness_path = os.environ.get("OPENHA_HARNESS_PATH", "")
        if not harness_path:
            return
        h = self._load_harness(harness_path)
        fn = getattr(h, "learn_from_rollout", None)
        if callable(fn):
            fn(task_name, success, trajectory)

    def get_harness_state(self) -> str:
        harness_path = os.environ.get("OPENHA_HARNESS_PATH", "")
        if not harness_path:
            return ""
        h = self._load_harness(harness_path)
        fn = getattr(h, "get_state", None)
        return fn() if callable(fn) else ""

    def set_harness_state(self, state: str) -> None:
        harness_path = os.environ.get("OPENHA_HARNESS_PATH", "")
        if not harness_path:
            return
        h = self._load_harness(harness_path)
        fn = getattr(h, "set_state", None)
        if callable(fn):
            fn(state)

    def _build_icl_instruction(self, instruction: str, task_name: str) -> str:
        self._icl_image_demos = []
        if not self._icl_enabled or not task_name:
            return instruction

        harness_path = os.environ.get("OPENHA_HARNESS_PATH", "")
        if harness_path:
            h = self._load_harness(harness_path)
            build = getattr(h, "build_context", None) or getattr(h, "build_icl_instruction", None)
            out = build(instruction, task_name) if callable(build) else instruction
            vd = getattr(h, "build_visual_demos", None)
            if callable(vd):
                try:
                    self._icl_image_demos = vd(instruction, task_name) or []
                except Exception:
                    self._icl_image_demos = []
            return out

        category = task_name.split(":", 1)[0]

    def gen_response(self, obs, instruction, info=None, verbose=False, if_token_ids=False):
        """OpenHA.gen_response with ICL demo messages prepended.

        When self._icl_image_demos is non-empty, each (image, text) pair is
        rendered as a user(image) -> assistant(text) message before the rolling
        history and the current observation. The system prompt + instruction
        lead the very first message. Backward-compatible: identical to the
        original when there are no demo images.
        """
        import copy
        import numpy as np
        from openagents.utils import extract

        if info is not None:
            real_obs = info['pov']
        elif isinstance(obs, np.ndarray):
            real_obs = obs
        else:
            raise ValueError("NO OBS")
        image = self.processor_wrapper.create_image_input(real_obs)
        self._current_obs = [image]
        messages = []

        demos = getattr(self, "_icl_image_demos", None) or []
        lead = self.system_message + instruction
        for didx, (demo_img, demo_text) in enumerate(demos):
            try:
                demo_input = self.processor_wrapper.create_image_input(demo_img)
            except Exception:
                demo_input = demo_img
            dprompt = lead if didx == 0 else ""
            lead = ""
            messages.append(self.processor_wrapper.create_message_vllm(
                role="user", input_type="image", prompt=[copy.copy(dprompt)], image=[demo_input]))
            messages.append(self.processor_wrapper.create_message_vllm(
                role="assistant", input_type="text", prompt=[copy.copy(demo_text or "")]))

        if self.maximum_history_length:
            hist_len = self.maximum_history_length
            if demos:
                hist_len = max(0, hist_len - len(demos))
            else:
                try:
                    trunc_k = int(os.environ.get("OPENHA_HISTORY_TRUNC_K", "0") or "0")
                except ValueError:
                    trunc_k = 0
                if trunc_k > 0:
                    hist_len = max(0, hist_len - trunc_k)
            history = self._history[-hist_len:] if hist_len > 0 else []
            for hdx, history_message in enumerate(history):
                if history_message is None:
                    continue
                hobs = copy.copy(history_message["obs"])
                hresp = copy.copy(history_message["response"])
                hprompt = ""
                if hdx == 0 and not demos:
                    hprompt = self.system_message + instruction
                messages.append(self.processor_wrapper.create_message_vllm(
                    role="user", input_type="image", prompt=[copy.copy(hprompt)], image=hobs))
                messages.append(self.processor_wrapper.create_message_vllm(
                    role="assistant", input_type="text", prompt=[hresp]))

        cprompt = ""
        if not messages:
            cprompt = self.system_message + instruction
        messages.append(self.processor_wrapper.create_message_vllm(
            role="user", input_type="image", prompt=[copy.copy(cprompt)], image=self._current_obs))
        if self._enforce_format:
            messages.append(self.processor_wrapper.create_message_vllm(
                role="assistant", input_type="text", prompt=[self.enforce_prefix]))

        output = self.generate(messages=messages, verbose=verbose, if_token_ids=if_token_ids)
        content_action, content = output["action"], output["content"]
        self._logprobs = output.get("logprob")
        self._response_tokens = output.get("response_tokens")
        self._sampled_logprobs = output.get("sampled_logprobs")
        if verbose:
            print(content)

        self._points = []
        hierarchical_actions = extract.extract_hierarchical_action(content)
        grounding_actions = hierarchical_actions["grounding"]
        for grounding_action in grounding_actions:
            self._points.extend(grounding_action["point"])
        if not self._points:
            self._points = [[320, 180]]
        self._thought = content
        return content_action, content

'''
edits.append((old2, new2))

for i, (old, new) in enumerate(edits, 1):
    if old not in text:
        print(f"ERROR: agent edit {i} target block not found", file=sys.stderr)
        sys.exit(2)
    text = text.replace(old, new, 1)

with open(DST, "w") as f:
    f.write(text)
print("WROTE", DST)

# 3. Patch the eval script to allow agent-module override (idempotent).
with open(EVAL) as f:
    ev = f.read()

old3 = '    agent_module_name = config.get("agent_module", "streaming_openha_agent_v2")\n'
new3 = '    agent_module_name = os.environ.get("OPENHA_AGENT_MODULE") or config.get("agent_module", "streaming_openha_agent_v2")\n'

changed = False

if old3 in ev:
    ev = ev.replace(old3, new3, 1)
    changed = True
elif new3 not in ev:
    print("ERROR: eval edit (agent_module_name) target block not found", file=sys.stderr)
    sys.exit(2)

# 4. Fire learn_from_rollout at the end of run_single_task (idempotent).
old4 = (
    "    # Save result\n"
    "    result_file = \"success.json\" if success else \"loss.json\"\n"
    "    with open(os.path.join(rollout_path, result_file), \"w\") as f:\n"
    "        json.dump({\"task\": task_name, \"steps\": num_steps, \"fps\": fps, \"success\": success}, f)\n"
    "\n"
    "    env.close()\n"
    "    return success, fps, num_steps, rollout_path\n"
)
new4 = (
    "    # Save result\n"
    "    result_file = \"success.json\" if success else \"loss.json\"\n"
    "    with open(os.path.join(rollout_path, result_file), \"w\") as f:\n"
    "        json.dump({\"task\": task_name, \"steps\": num_steps, \"fps\": fps, \"success\": success}, f)\n"
    "\n"
    "    # Signal the active harness to learn from this rollout (Meta-Harness hook).\n"
    "    if hasattr(agent, \"learn_from_rollout\"):\n"
    "        agent.learn_from_rollout(task_name, success)\n"
    "\n"
    "    env.close()\n"
    "    return success, fps, num_steps, rollout_path\n"
)

if old4 in ev:
    ev = ev.replace(old4, new4, 1)
    changed = True
elif "agent.learn_from_rollout(task_name, success)" not in ev:
    print("ERROR: eval edit (learn_from_rollout) target block not found", file=sys.stderr)
    sys.exit(2)

if changed:
    with open(EVAL, "w") as f:
        f.write(ev)
    print("PATCHED", EVAL)
else:
    print("ALREADY PATCHED", EVAL)
