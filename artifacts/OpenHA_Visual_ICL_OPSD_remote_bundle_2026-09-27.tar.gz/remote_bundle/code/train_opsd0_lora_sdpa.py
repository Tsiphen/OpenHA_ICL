#!/usr/bin/env python3
"""Minimal SDPA-compatible LoRA trainer for the OPSD-0 smoke test."""

from __future__ import annotations

import argparse
import inspect
import json
from pathlib import Path
from typing import List

import torch
from peft import LoraConfig, get_peft_model
from qwen_vl_utils import process_vision_info
from torch.utils.data import Dataset
from transformers import (
    AutoProcessor,
    Qwen2VLForConditionalGeneration,
    Trainer,
    TrainingArguments,
)


class OPSD0Dataset(Dataset):
    def __init__(self, path, processor, max_samples=0):
        self.samples = []
        with Path(path).open(encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    self.samples.append(json.loads(line))
                    if max_samples and len(self.samples) >= max_samples:
                        break
        if not self.samples:
            raise ValueError(f"No samples found in {path}")
        self.processor = processor
        self.assistant_marker = self.processor.tokenizer(
            "<|im_start|>assistant\n", add_special_tokens=False
        ).input_ids

    def __len__(self):
        return len(self.samples)

    @staticmethod
    def _find_subsequence(ids: List[int], pattern: List[int]) -> int:
        for index in range(0, len(ids) - len(pattern) + 1):
            if ids[index:index + len(pattern)] == pattern:
                return index
        return -1

    def __getitem__(self, index):
        sample = self.samples[index]
        messages = sample["messages"]
        text = self.processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=False
        )
        image_inputs, video_inputs = process_vision_info(messages)
        inputs = self.processor(
            text=[text],
            images=image_inputs,
            videos=video_inputs,
            return_tensors="pt",
            padding=True,
        )
        labels = inputs["input_ids"].clone()
        ids = labels[0].tolist()
        marker_start = self._find_subsequence(ids, self.assistant_marker)
        if marker_start < 0:
            labels[:] = -100
        else:
            labels[:, :marker_start + len(self.assistant_marker)] = -100
        inputs["labels"] = labels
        return inputs


def collate_one(batch):
    if len(batch) != 1:
        raise ValueError("OPSD-0 uses batch size 1 for variable-size images")
    return batch[0]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", required=True)
    parser.add_argument("--train_jsonl", required=True)
    parser.add_argument("--eval_jsonl", required=True)
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--max_train_samples", type=int, default=0)
    parser.add_argument("--max_eval_samples", type=int, default=256)
    parser.add_argument("--max_steps", type=int, default=4)
    parser.add_argument("--learning_rate", type=float, default=1e-5)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=1)
    parser.add_argument("--save_steps", type=int, default=2)
    parser.add_argument("--eval_steps", type=int, default=2)
    parser.add_argument("--lora_rank", type=int, default=8)
    parser.add_argument("--lora_alpha", type=int, default=16)
    args = parser.parse_args()

    processor = AutoProcessor.from_pretrained(
        args.model_path, trust_remote_code=True
    )
    model = Qwen2VLForConditionalGeneration.from_pretrained(
        args.model_path,
        torch_dtype=torch.float16,
        device_map="auto",
        trust_remote_code=True,
        attn_implementation="sdpa",
    )
    if hasattr(model, "visual"):
        model.visual.requires_grad_(False)
    # The checkpoint is already loaded in fp16, not quantized. Calling
    # prepare_model_for_kbit_training here needlessly creates fp32 copies and
    # can exceed the available GPU memory on shared nodes.
    model = get_peft_model(
        model,
        LoraConfig(
            r=args.lora_rank,
            lora_alpha=args.lora_alpha,
            lora_dropout=0.05,
            bias="none",
            task_type="CAUSAL_LM",
            target_modules=[
                "q_proj", "k_proj", "v_proj", "o_proj",
                "gate_proj", "up_proj", "down_proj",
            ],
        ),
    )
    model.print_trainable_parameters()

    train_dataset = OPSD0Dataset(
        args.train_jsonl, processor, args.max_train_samples
    )
    eval_dataset = OPSD0Dataset(
        args.eval_jsonl, processor, args.max_eval_samples
    )
    kwargs = dict(
        output_dir=args.output_dir,
        per_device_train_batch_size=1,
        per_device_eval_batch_size=1,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        max_steps=args.max_steps,
        learning_rate=args.learning_rate,
        warmup_ratio=0.03,
        logging_steps=1,
        save_steps=args.save_steps,
        eval_steps=args.eval_steps,
        save_total_limit=2,
        fp16=True,
        remove_unused_columns=False,
        report_to=[],
        dataloader_num_workers=0,
    )
    if "eval_strategy" in inspect.signature(TrainingArguments).parameters:
        kwargs["eval_strategy"] = "steps"
    else:
        kwargs["evaluation_strategy"] = "steps"
    trainer = Trainer(
        model=model,
        args=TrainingArguments(**kwargs),
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        data_collator=collate_one,
        processing_class=processor,
    )
    trainer.train()
    final_dir = Path(args.output_dir) / "final_adapter"
    final_dir.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(final_dir)
    processor.save_pretrained(final_dir)
    print(f"[done] saved LoRA adapter to {final_dir}", flush=True)


if __name__ == "__main__":
    main()
