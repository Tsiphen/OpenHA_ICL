"""Probe: frozen model, image-only ICL (k=1/3/5) vs text baseline on kill_entity.

Runs 4 arms in parallel on free GPUs with the frozen round0 LoRA adapter:
    0. baseline  : baseline_hint.py       (text ICL)
    1. image_k1  : image_demo_harness.py  k=1  (pure image)
    2. image_k3  : image_demo_harness.py  k=3
    3. image_k5  : image_demo_harness.py  k=5

Reports per-arm ASR on the kill_entity subset and writes probe_summary.json.
"""

import argparse
import json
import os
import subprocess
import sys

import config
import experiment_guard
import metrics
import sub_vla

CONFIG_NAME = "openha_eager_sft_v4_icl"
ROUND0_ADAPTER = "/data3/openha_evo/adapters/round0/final_adapter/final_adapter"
OUT_ROOT = os.path.join(config.EVO_ROOT, "probe_image_icl")
BASELINE_HARNESS = os.path.join(config.EVO_ROOT, "harness", "candidates", "baseline_hint.py")
IMAGE_HARNESS = os.path.join(config.EVO_ROOT, "harness", "candidates", "image_demo_harness.py")
POOL_ROOT = "/data3/openha_evo/eval/icl_success_pool/00_original_icl_trainonly"
GPU_MIN_FREE_MB = 25000

ARMS = [
    {"name": "baseline", "harness": BASELINE_HARNESS, "env": {}},
    {"name": "image_k1", "harness": IMAGE_HARNESS, "env": {"OPENHA_ICL_K": "1"}},
    {"name": "image_k3", "harness": IMAGE_HARNESS, "env": {"OPENHA_ICL_K": "3"}},
    {"name": "image_k5", "harness": IMAGE_HARNESS, "env": {"OPENHA_ICL_K": "5"}},
]


def build_kill_subset(limit=None):
    tasks = metrics.read_task_list(config.TRAIN_TASKS)
    subset = [t for t in tasks if config.category(t) == "kill_entity"]
    if limit is not None:
        subset = subset[:limit]
    os.makedirs(OUT_ROOT, exist_ok=True)
    path = os.path.join(OUT_ROOT, "kill_entity_subset.txt")
    with open(path, "w") as f:
        f.write("\n".join(subset) + ("\n" if subset else ""))
    return path, subset


def parse_gpus(spec):
    """Parse a comma-separated GPU index list, or "" for auto-pick."""
    if not spec.strip():
        return None
    return [int(x.strip()) for x in spec.split(",") if x.strip() != ""]


def pick_free_gpus(n, min_free_mb=GPU_MIN_FREE_MB):
    out = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=index,memory.used,memory.total", "--format=csv,noheader,nounits"],
        text=True,
    )
    gpus = []
    for line in out.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 3:
            idx, used, total = int(parts[0]), int(parts[1]), int(parts[2])
            gpus.append((idx, total - used))
    gpus.sort(key=lambda x: -x[1])
    chosen = [idx for idx, free in gpus if free >= min_free_mb][:n]
    if len(chosen) < n:
        raise RuntimeError(f"Need {n} GPUs with >= {min_free_mb} MB free, found {len(chosen)}")
    return chosen


def launch_arm(arm, subset_path, gpu, max_steps):
    record_path = os.path.join(OUT_ROOT, arm["name"])
    os.makedirs(record_path, exist_ok=True)
    extra_env = {
        "OPENHA_HARNESS_PATH": arm["harness"],
        "OPENHA_AGENT_MODULE": "streaming_openha_original_harness",
        "OPENHA_SUCCESS_POOL": POOL_ROOT,
    }
    extra_env.update(arm["env"])
    log_file = os.path.join(config.LOGS_DIR, f"probe_image_icl_{arm['name']}.log")
    proc = sub_vla.run_eval(
        CONFIG_NAME, subset_path, record_path, gpu,
        max_steps=max_steps, log_file=log_file,
        lora_adapter_path=ROUND0_ADAPTER, bench_seed=config.BENCH_SEED,
        extra_env=extra_env,
    )
    print(f"[probe] launched {arm['name']} gpu={gpu} pid={proc.pid}", flush=True)
    return record_path, proc


def collect_arm(arm, record_path, proc, subset_path):
    rc = proc.wait()
    result_dir = os.path.join(record_path, CONFIG_NAME)
    m = metrics.compute_metrics(result_dir, subset_path) if rc == 0 else None
    asr = m["overall"]["asr"] if m else None
    entry = {
        "rc": rc,
        "asr": asr,
        "by_category": m["by_category"] if m else None,
        "missing": len(m["missing"]) if m else None,
    }
    print(f"[probe] {arm['name']} rc={rc} asr={asr}", flush=True)
    return entry


def main():
    p = argparse.ArgumentParser(description="Image-ICL probe on kill_entity")
    p.add_argument("--max-steps", type=int, default=config.DEFAULT_MAX_STEPS)
    p.add_argument("--arms", default="", help="comma-separated arm names (default: all)")
    p.add_argument("--gpus", default="", help="comma-separated GPU indices (default: auto-pick free)")
    p.add_argument("--sequential", action="store_true",
                   help="run arms one at a time on the first GPU (for a single free GPU)")
    p.add_argument("--subset-limit", type=int, default=None,
                   help="cap the kill_entity subset to N tasks (for smoke tests)")
    args = p.parse_args()

    subset_path, subset = build_kill_subset(limit=args.subset_limit)
    guard = experiment_guard.assert_no_test_leak(POOL_ROOT)
    config_path, snapshot = experiment_guard.write_run_config_snapshot(
        OUT_ROOT,
        stage="stage1_lora_sft_uniform_image",
        config_name=CONFIG_NAME,
        success_pool=POOL_ROOT,
        task_list=subset_path,
        subset_limit=args.subset_limit,
        arms=args.arms or "all",
        max_steps=args.max_steps,
        bench_seed=config.BENCH_SEED,
        guard=guard,
    )
    print(f"[probe] guard ok; run config -> {config_path}", flush=True)
    print(f"[probe] run config sha256 = {snapshot['config_sha256']}", flush=True)
    print(f"[probe] kill_entity subset = {len(subset)} tasks -> {subset_path}", flush=True)

    arms = ARMS
    if args.arms:
        want = set(args.arms.split(","))
        arms = [a for a in ARMS if a["name"] in want]
    if not arms:
        print("ERROR: no arms selected", file=sys.stderr)
        sys.exit(2)

    if args.gpus:
        gpus = parse_gpus(args.gpus)
    elif args.sequential:
        gpus = pick_free_gpus(1)
    else:
        gpus = pick_free_gpus(len(arms))
    print(f"[probe] GPUs = {gpus}", flush=True)

    summary = {}
    if args.sequential:
        gpu = gpus[0]
        for arm in arms:
            record_path, proc = launch_arm(arm, subset_path, gpu, args.max_steps)
            summary[arm["name"]] = collect_arm(arm, record_path, proc, subset_path)
    else:
        procs = []
        for arm, gpu in zip(arms, gpus):
            record_path, proc = launch_arm(arm, subset_path, gpu, args.max_steps)
            procs.append((arm, record_path, proc))
        for arm, record_path, proc in procs:
            summary[arm["name"]] = collect_arm(arm, record_path, proc, subset_path)

    out_path = os.path.join(OUT_ROOT, "probe_summary.json")
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"[probe] summary -> {out_path}", flush=True)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
