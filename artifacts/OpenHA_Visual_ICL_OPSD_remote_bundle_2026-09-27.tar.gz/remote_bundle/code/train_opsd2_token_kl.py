#!/usr/bin/env python3
"""Offline teacher-logit cache followed by token-level KL LoRA training."""

from __future__ import annotations

import argparse
import copy
import gc
import json
from pathlib import Path

import torch
import torch.nn.functional as F
from peft import LoraConfig, get_peft_model
from qwen_vl_utils import process_vision_info
from transformers import AutoProcessor, Qwen2VLForConditionalGeneration


def rows(path):
    return [json.loads(line) for line in Path(path).open(encoding="utf-8") if line.strip()]


def model_and_processor(model_path):
    p = AutoProcessor.from_pretrained(model_path, trust_remote_code=True)
    m = Qwen2VLForConditionalGeneration.from_pretrained(
        model_path, torch_dtype=torch.float16, device_map="auto",
        trust_remote_code=True, attn_implementation="sdpa",
    )
    return m, p


def encode(processor, messages):
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=False)
    image_inputs, video_inputs = process_vision_info(messages)
    x = processor(text=[text], images=image_inputs, videos=video_inputs,
                  return_tensors="pt", padding=True)
    marker = processor.tokenizer("<|im_start|>assistant\n", add_special_tokens=False).input_ids
    ids = x["input_ids"][0].tolist()
    start = next((i for i in range(len(ids) - len(marker) + 1)
                  if ids[i:i + len(marker)] == marker), -1)
    if start < 0:
        raise RuntimeError("assistant marker not found")
    return x, start + len(marker)


def move(x, device):
    return {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in x.items()}


def target_messages(sample):
    return copy.deepcopy(sample["messages"])


def teacher_messages(smoke, target):
    m = copy.deepcopy(smoke["messages"])
    m.append({"role": "assistant", "content": [{"type": "text", "text": target}]})
    return m


def cache_teacher(args, train, smoke_by_id, cache_path):
    model, processor = model_and_processor(args.model_path)
    device = next(model.parameters()).device
    cached = []
    model.eval()
    with torch.no_grad():
        for i, sample in enumerate(train):
            x, start = encode(processor, teacher_messages(smoke_by_id[sample["id"]], sample["teacher_target"]))
            out = model(**move(x, device), use_cache=False)
            end = int(x["attention_mask"][0].sum().item())
            logits = out.logits[0, start - 1:end - 1].detach().cpu().half()
            ids = x["input_ids"][0, start:end].detach().cpu()
            cached.append({"id": sample["id"], "ids": ids, "logits": logits})
            print(f"[teacher-cache] {i + 1}/{len(train)}", flush=True)
    torch.save(cached, cache_path)
    del model
    gc.collect()
    torch.cuda.empty_cache()


def train_student(args, train, cache_path):
    model, processor = model_and_processor(args.model_path)
    if hasattr(model, "visual"):
        model.visual.requires_grad_(False)
    model = get_peft_model(model, LoraConfig(
        r=8, lora_alpha=16, lora_dropout=0.05, bias="none",
        task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj"],
    ))
    model.print_trainable_parameters()
    device = next(model.parameters()).device
    cached = {x["id"]: x for x in torch.load(cache_path, map_location="cpu", weights_only=False)}
    opt = torch.optim.AdamW((p for p in model.parameters() if p.requires_grad), lr=args.learning_rate)
    marker = processor.tokenizer("<|im_start|>assistant\n", add_special_tokens=False).input_ids
    model.train()
    for step in range(args.steps):
        sample = train[step % len(train)]
        x, start = encode(processor, target_messages(sample))
        out = model(**move(x, device), use_cache=False)
        end = int(x["attention_mask"][0].sum().item())
        student_logits = out.logits[0, start - 1:end - 1].float()
        teacher = cached[sample["id"]]
        n = min(student_logits.shape[0], teacher["logits"].shape[0])
        t = teacher["logits"][:n].to(device=device, dtype=torch.float32)
        s = student_logits[:n]
        loss = F.kl_div(
            F.log_softmax(s / args.temperature, dim=-1),
            F.softmax(t / args.temperature, dim=-1),
            reduction="batchmean",
        ) * (args.temperature ** 2)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        if (step + 1) % 5 == 0:
            print(f"[student] step={step + 1}/{args.steps} loss={loss.item():.5f}", flush=True)
    final = Path(args.output_dir) / "final_adapter"
    final.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(final)
    processor.save_pretrained(final)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-path", required=True)
    ap.add_argument("--train-jsonl", required=True)
    ap.add_argument("--teacher-jsonl", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--steps", type=int, default=60)
    ap.add_argument("--learning-rate", type=float, default=1e-5)
    ap.add_argument("--temperature", type=float, default=2.0)
    args = ap.parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    train = rows(args.train_jsonl)
    smoke_by_id = {x["id"]: x for x in rows(args.teacher_jsonl)}
    cache_path = out / "teacher_logits.pt"
    if not cache_path.exists():
        cache_teacher(args, train, smoke_by_id, cache_path)
    train_student(args, train, cache_path)
    (out / "status.json").write_text(json.dumps({
        "stage": "OPSD-2-token-KL", "status": "complete",
        "train_rows": len(train), "steps": args.steps,
        "teacher_logits": str(cache_path),
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
