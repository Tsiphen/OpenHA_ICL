#!/usr/bin/env python3
"""Fixed-prefix counterfactual replay for OpenHA visual demonstrations.

The script reuses recorded observation prefixes and changes only the
demonstration condition. It is deliberately offline: no Minecraft environment
is stepped and no rollout is allowed to influence another condition.

The primary comparison is:
  current_history vs truncation_control vs success_demo vs negative_demo

The two key controls are:
  - truncation_control: same 16-image budget, but no demonstration images;
  - success_demo: retrieved train-only images plus the remaining history.

This does not claim oracle action labels. Recorded environment actions are
reported only as behavioral alignment references.
"""

from __future__ import annotations

import argparse
import base64
import copy
import io
import json
import os
import random
import re
import sys
from pathlib import Path

import numpy as np


def jsonable(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    try:
        import torch
        if isinstance(value, torch.Tensor):
            return value.detach().cpu().tolist()
    except Exception:
        pass
    return repr(value)


def decode_frame(line):
    from PIL import Image

    item = json.loads(line)
    raw = base64.b64decode(item["base64"])
    return np.asarray(Image.open(io.BytesIO(raw)).convert("RGB"))


def load_rollout(rollout_dir):
    rollout_dir = Path(rollout_dir)
    with (rollout_dir / "episode.jsonl").open() as handle:
        frames = [decode_frame(line) for line in handle if line.strip()]
    with (rollout_dir / "action.jsonl").open() as handle:
        actions = [json.loads(line) or {} for line in handle if line.strip()]
    success_path = rollout_dir / "success.json"
    success = json.loads(success_path.read_text()) if success_path.exists() else {}
    n = min(len(frames), len(actions))
    return frames[:n], actions[:n], success


def task_from_dir(name):
    for category in ("kill_entity", "mine_block", "craft_item", "custom"):
        prefix = category + "_"
        if name.startswith(prefix):
            return category + ":" + name[len(prefix):]
    return name.replace("_", ":", 1)


def find_rollouts(root, include_failures=False):
    root = Path(root)
    found = []
    for episode in sorted(root.glob("*/*/episode.jsonl")):
        rollout_dir = episode.parent
        if include_failures or (rollout_dir / "success.json").exists():
            found.append((task_from_dir(rollout_dir.parent.name), rollout_dir))
    return found


def sample_prefixes(n_frames, actions, fractions, mode="fractions"):
    if mode == "phase":
        candidates = []
        # Early observation: before the agent has produced a meaningful action.
        candidates.append(("scan", min(n_frames - 1, max(1, 3))))

        movement_index = None
        engage_index = None
        for index, action in enumerate(actions[:n_frames]):
            action = action or {}
            camera = action.get("camera") or [0.0, 0.0]
            moving = any(
                bool(action.get(key, 0))
                for key in ("forward", "back", "left", "right", "jump")
            ) or any(abs(float(value)) > 1e-6 for value in camera[:2])
            engaging = bool(action.get("attack", 0)) or bool(action.get("use", 0))
            if movement_index is None and index >= 1 and moving:
                movement_index = index
            if engage_index is None and index >= 1 and engaging:
                engage_index = index

        if movement_index is not None:
            candidates.append(("approach_onset", movement_index))
        if engage_index is not None:
            candidates.append(("engage_onset", engage_index))
        candidates.append(("late_execution", max(1, n_frames - 2)))

        out = []
        seen = set()
        for label, index in candidates:
            index = min(n_frames - 1, max(1, int(index)))
            if index not in seen:
                out.append((index, label))
                seen.add(index)
        return out

    out = []
    seen = set()
    for fraction in fractions:
        # The current frame is included separately; history contains frames
        # strictly before it.
        index = min(n_frames - 1, max(1, int(round((n_frames - 1) * fraction))))
        if index not in seen:
            out.append((index, f"fraction_{fraction:g}"))
            seen.add(index)
    return out


def action_vector(action):
    action = action or {}
    keys = [
        "attack", "use", "forward", "back", "left", "right", "jump",
        "sprint", "sneak", "inventory", "pickItem",
    ]
    vector = {key: int(bool(action.get(key, 0))) for key in keys}
    camera = action.get("camera")
    if camera is None:
        camera = [0.0, 0.0]
    vector["camera"] = [float(camera[0]), float(camera[1])]
    return vector


def action_distance(left, right):
    left = action_vector(left)
    right = action_vector(right)
    keys = [key for key in left if key != "camera"]
    hamming = sum(left[key] != right[key] for key in keys)
    camera_l1 = sum(abs(a - b) for a, b in zip(left["camera"], right["camera"]))
    return {
        "binary_hamming": int(hamming),
        "camera_l1": float(camera_l1),
        "total": float(hamming + camera_l1 / 20.0),
    }


def token_stats(tokens):
    if not tokens:
        return {"count": 0, "mean_logprob": None, "min_logprob": None}
    values = []
    for item in tokens:
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            try:
                values.append(float(item[1]))
            except (TypeError, ValueError):
                pass
    if not values:
        return {"count": len(tokens), "mean_logprob": None, "min_logprob": None}
    return {
        "count": len(values),
        "mean_logprob": float(np.mean(values)),
        "min_logprob": float(np.min(values)),
    }


def make_scored_hf_generate(agent):
    """Attach local-HF token scores without changing the shared OpenHA source."""
    import types
    from openagents.agents.utils.vlm_client import encode_image_to_pil

    def scored_generate(self, messages, if_token_ids):
        import torch

        self._last_replay_messages = copy.deepcopy(messages)
        images = []
        for message in messages:
            if message["role"] == "system":
                continue
            for part in message["content"]:
                if part["type"] == "image":
                    part["image"] = encode_image_to_pil(part["image"])
                    images.append(part["image"])
        if not images:
            images = None
        text_prompt = self.processor.apply_chat_template(
            messages, add_generation_prompt=True
        )
        inputs = self.processor(
            text=[text_prompt], images=images, padding=True, return_tensors="pt"
        ).to(self.model.device)
        input_len = inputs["input_ids"].shape[-1]
        gen_cfg = {
            "do_sample": bool(self.temperature),
            "temperature": self.temperature,
            "top_p": self.top_p,
            "repetition_penalty": 1.0,
            "output_scores": True,
            "return_dict_in_generate": True,
        }
        if self.top_k > 0:
            gen_cfg["top_k"] = self.top_k
        generated = self.model.generate(
            **inputs,
            max_new_tokens=max(1, self.max_tokens - input_len),
            **gen_cfg,
            pad_token_id=self.processor.tokenizer.eos_token_id,
            eos_token_id=self.processor.tokenizer.eos_token_id,
        )
        output_ids = generated.sequences[0][input_len:]
        content = self.processor.batch_decode(
            [output_ids],
            skip_special_tokens=False,
            clean_up_tokenization_spaces=False,
        )[0]
        token_scores = []
        for token_id, score in zip(output_ids.tolist(), generated.scores):
            logprob = torch.log_softmax(score[0].float(), dim=-1)[token_id]
            token = self.processor.tokenizer.decode(
                [token_id], skip_special_tokens=False
            )
            token_scores.append([token, float(logprob.detach().cpu())])
        return {
            "content": content,
            "action": output_ids if if_token_ids else content,
            "sampled_logprobs": token_scores,
            "response_tokens": token_scores,
        }

    agent._generate_local_hf = types.MethodType(scored_generate, agent)


def score_target(agent, messages, target):
    """Score a fixed action string under a previously built prompt."""
    import torch
    from openagents.agents.utils.vlm_client import encode_image_to_pil

    prompt_messages = copy.deepcopy(messages)
    images = []
    for message in prompt_messages:
        if message["role"] == "system":
            continue
        for part in message["content"]:
            if part["type"] == "image":
                part["image"] = encode_image_to_pil(part["image"])
                images.append(part["image"])
    if not images:
        images = None
    prompt_text = agent.processor.apply_chat_template(
        prompt_messages, add_generation_prompt=True
    )
    full_text = prompt_text + target
    prompt_inputs = agent.processor(
        text=[prompt_text],
        images=images,
        padding=True,
        return_tensors="pt",
    ).to(agent.model.device)
    full_inputs = agent.processor(
        text=[full_text],
        images=images,
        padding=True,
        return_tensors="pt",
    ).to(agent.model.device)
    prompt_len = int(prompt_inputs["input_ids"].shape[-1])
    target_ids = full_inputs["input_ids"][0][prompt_len:]
    if target_ids.numel() == 0:
        return {"count": 0, "sum_logprob": 0.0, "mean_logprob": None}
    with torch.inference_mode():
        logits = agent.model(**full_inputs, use_cache=False).logits[0]
    start = max(0, prompt_len - 1)
    end = min(start + int(target_ids.numel()), logits.shape[0] - 1)
    target_ids = target_ids[: max(0, end - start)]
    if target_ids.numel() == 0:
        return {"count": 0, "sum_logprob": 0.0, "mean_logprob": None}
    selected = torch.log_softmax(logits[start:end].float(), dim=-1)
    values = selected.gather(-1, target_ids.unsqueeze(-1)).squeeze(-1)
    return {
        "count": int(values.numel()),
        "sum_logprob": float(values.sum().detach().cpu()),
        "mean_logprob": float(values.mean().detach().cpu()),
    }


def patch_flash_attention_to_sdpa():
    """Use Transformers SDPA when flash_attn is unavailable on the server."""
    from openagents.agents.utils import vlm_client

    for model_cls_name in (
        "Qwen2VLForConditionalGeneration",
        "Qwen2_5_VLForConditionalGeneration",
    ):
        model_cls = getattr(vlm_client, model_cls_name, None)
        if model_cls is None:
            continue
        original = model_cls.from_pretrained

        def load_with_sdpa(*args, _original=original, **kwargs):
            kwargs["attn_implementation"] = "sdpa"
            return _original(*args, **kwargs)

        model_cls.from_pretrained = staticmethod(load_with_sdpa)


def build_negative_demos(task, bank, k, mode, seed):
    """Choose a train-only same-category but attribute-mismatched demo."""
    from harness import visual_icl
    from harness.visual_memory import category_of, entity_of, attrs_of, attr_similarity

    category = category_of(task)
    entity = entity_of(task)
    query_attrs = attrs_of(entity)
    candidates = []
    for entry in bank:
        if entry.get("category") != category:
            continue
        if entry.get("task") == task or entry.get("entity") == entity:
            continue
        score = attr_similarity(query_attrs, entry.get("attrs"))
        candidates.append((score, entry))
    if not candidates:
        return []
    candidates.sort(key=lambda item: item[0])
    chosen = candidates[min(seed % min(3, len(candidates)), len(candidates) - 1)][1]
    return visual_icl.load_demos(
        chosen["rollout_dir"], k=k, mode=mode, text_mode="none"
    )


def build_conditions(task, args):
    from harness import visual_icl, visual_memory

    bank = visual_memory.load_bank(args.memory_bank)
    entity = visual_memory.entity_of(task)
    success = visual_memory.retrieve(
        bank,
        task,
        k=args.k,
        mode=args.demo_mode,
        text_mode="none",
        exclude_task=task,
        exclude_entity=entity,
    )
    category = visual_icl.load_demos_for_task(
        args.success_pool,
        task,
        k=args.k,
        mode=args.demo_mode,
        text_mode="none",
        exclude_task=task,
        exclude_entity=entity,
    )
    negative = build_negative_demos(
        task, bank, args.k, args.demo_mode, args.seed
    )
    return {
        "truncation_control": {"demos": [], "trunc_k": args.k},
        "current_history": {"demos": [], "trunc_k": 0},
        "success_demo": {"demos": success, "trunc_k": 0},
        "category_demo": {"demos": category, "trunc_k": 0},
        "negative_demo": {"demos": negative, "trunc_k": 0},
    }


def run_one(
    agent,
    task,
    instruction,
    frames,
    actions,
    prefix_index,
    phase,
    name,
    spec,
    args,
    reference_content=None,
):
    os.environ["OPENHA_HISTORY_TRUNC_K"] = str(spec["trunc_k"])
    agent.reset(instruction=instruction, task_name=task)
    history_frames = frames[:prefix_index]
    # MineStudio's action.jsonl stores bare environment actions, while
    # OpenHA.create_history expects an explicit env_action field.
    history_actions = [
        {"env_action": copy.deepcopy(action)}
        for action in actions[:prefix_index]
    ]
    agent.create_history(
        actions=history_actions,
        observations=history_frames,
    )
    agent._icl_image_demos = spec["demos"]
    current = frames[prefix_index]
    _, content = agent.gen_response(
        current,
        instruction,
        info={"pov": current},
        if_token_ids=False,
    )
    decoded = []
    try:
        decoded = agent.action_tokenizer.decode(content)
    except Exception:
        decoded = []
    env_action = decoded[-1] if decoded else {}
    tokens = getattr(agent, "_sampled_logprobs", None) or []
    if reference_content is None:
        reference_content = content
    reference_stats = score_target(
        agent, agent._last_replay_messages, reference_content
    )
    recorded_action_text = ""
    recorded_stats = {"count": 0, "sum_logprob": 0.0, "mean_logprob": None}
    try:
        encoded = agent.action_tokenizer.encode(
            trajectory={"actions": [actions[prefix_index]]}
        )
        if encoded:
            recorded_action_text = encoded[0]["action"]
            recorded_stats = score_target(
                agent, agent._last_replay_messages, recorded_action_text
            )
    except Exception:
        recorded_action_text = ""
    return {
        "condition": name,
        "task": task,
        "prefix_index": prefix_index,
        "phase": phase,
        "prefix_length": prefix_index,
        "history_images_used": max(
            0,
            min(agent.maximum_history_length, prefix_index)
            - spec["trunc_k"]
            - len(spec["demos"]),
        ),
        "demo_count": len(spec["demos"]),
        "total_prompt_images": 1
        + len(spec["demos"])
        + max(
            0,
            min(agent.maximum_history_length, prefix_index)
            - spec["trunc_k"]
            - len(spec["demos"]),
        ),
        "content": content,
        "decoded_action": jsonable(env_action),
        "recorded_next_action": jsonable(actions[prefix_index]),
        "distance_to_recorded": action_distance(
            env_action, actions[prefix_index]
        ),
        "token_stats": token_stats(tokens),
        "sampled_logprobs": jsonable(tokens),
        "reference_content": reference_content,
        "reference_token_stats": reference_stats,
        "recorded_action_text": recorded_action_text,
        "recorded_action_token_stats": recorded_stats,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--success-pool", required=True)
    parser.add_argument("--memory-bank", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max-tasks", type=int, default=3)
    parser.add_argument("--k", type=int, default=3)
    parser.add_argument("--history-length", type=int, default=15)
    parser.add_argument("--demo-mode", choices=["uniform", "state"], default="state")
    parser.add_argument("--prefix-fractions", default="0.2,0.5,0.8")
    parser.add_argument(
        "--prefix-mode", choices=["fractions", "phase"], default="fractions"
    )
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--include-failures", action="store_true")
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--max-tokens", type=int, default=2048)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    evo_root = str(Path(args.success_pool).parents[2])
    openha_root = os.environ.get("OPENHA_ROOT", "/data3/openha_repro/OpenHA")
    sys.path[:0] = ["/data3/openha_repro", openha_root, evo_root]

    from streaming_openha_original_harness import StreamingOpenHAAgent

    patch_flash_attention_to_sdpa()
    rollouts = find_rollouts(args.source_root, args.include_failures)
    by_task = {}
    for task, rollout in rollouts:
        by_task.setdefault(task, rollout)
    selected = sorted(by_task.items())[: args.max_tasks]
    if not selected:
        raise RuntimeError(f"No rollouts found under {args.source_root}")

    agent = StreamingOpenHAAgent(
        model_path=args.model_path,
        output_mode="text_action",
        system_message_tag="text_action",
        temperature=args.temperature,
        max_tokens=args.max_tokens,
        maximum_history_length=args.history_length,
        get_sampled_logprobs=1,
    )
    make_scored_hf_generate(agent)

    fractions = [float(x) for x in args.prefix_fractions.split(",") if x.strip()]
    results = []
    manifest = {
        "project": "ICL-OpenHA",
        "owner": "tsiphen",
        "stage": "Stage4-B-fixed-prefix-replay",
        "source_root": args.source_root,
        "success_pool": args.success_pool,
        "memory_bank": args.memory_bank,
        "model_path": args.model_path,
        "seed": args.seed,
        "temperature": args.temperature,
        "k": args.k,
        "demo_mode": args.demo_mode,
        "prefix_mode": args.prefix_mode,
        "conditions": [
            "current_history",
            "truncation_control",
            "success_demo",
            "category_demo",
            "negative_demo",
        ],
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    progress_path = output.with_suffix(".progress.jsonl")
    if progress_path.exists():
        progress_path.unlink()

    for task, rollout_dir in selected:
        frames, actions, success = load_rollout(rollout_dir)
        if len(frames) < 3:
            continue
        instruction = task.replace(":", " ").replace("_", " ")
        conditions = build_conditions(task, args)
        for prefix_index, phase in sample_prefixes(
            len(frames), actions, fractions, mode=args.prefix_mode
        ):
            reference_content = None
            for name, spec in conditions.items():
                print(
                    f"[replay] task={task} prefix={prefix_index} condition={name}",
                    flush=True,
                )
                record = run_one(
                    agent,
                    task,
                    instruction,
                    frames,
                    actions,
                    prefix_index,
                    phase,
                    name,
                    spec,
                    args,
                    reference_content=reference_content,
                )
                if name == "truncation_control":
                    reference_content = record["content"]
                record["rollout_dir"] = str(rollout_dir)
                record["source_success"] = bool(success.get("success", False))
                results.append(record)
                with progress_path.open("a") as handle:
                    handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    (output.parent / "PROJECT_MARKER.txt").write_text(
        "PROJECT=ICL-OpenHA\nOWNER=tsiphen\nSTAGE=Stage4-B-fixed-prefix-replay\n"
    )
    (output.parent / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False)
    )
    output.write_text(json.dumps(results, indent=2, ensure_ascii=False))

    # Summary emphasizes within-prefix changes, not rollout success claims.
    by_prefix = {}
    for record in results:
        key = (record["task"], record["prefix_index"])
        by_prefix.setdefault(key, {})[record["condition"]] = record
    summary = []
    for (task, prefix), rows in sorted(by_prefix.items()):
        base = rows.get("truncation_control") or rows.get("current_history")
        for name, row in sorted(rows.items()):
            if name == base["condition"]:
                continue
            summary.append({
                "task": task,
                "prefix_index": prefix,
                "condition": name,
                "baseline_condition": base["condition"],
                "exact_text_changed": row["content"] != base["content"],
                "action_changed": row["decoded_action"] != base["decoded_action"],
                "action_distance_between_conditions": action_distance(
                    row["decoded_action"], base["decoded_action"]
                ),
                "mean_logprob_delta": (
                    None
                    if row["token_stats"]["mean_logprob"] is None
                    or base["token_stats"]["mean_logprob"] is None
                    else row["token_stats"]["mean_logprob"]
                    - base["token_stats"]["mean_logprob"]
                ),
            })
    (output.parent / "fixed_prefix_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False)
    )
    print(f"[replay] wrote {len(results)} condition rows to {output}", flush=True)


if __name__ == "__main__":
    main()
