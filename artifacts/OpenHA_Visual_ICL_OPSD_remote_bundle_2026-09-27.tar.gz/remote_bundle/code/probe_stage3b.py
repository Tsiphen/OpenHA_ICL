"""Probe Stage 3B: demo-text abstraction-level sweep (parallel to Stage 3).

Stage 3 swept ``source x frame_mode x k`` with demo text OFF (image-only ICL).
Stage 3B sweeps a fourth axis -- the abstraction level of the demo *text* that
accompanies each demo image -- while pinning the frame selector to the Stage-3
winner (``state``). This is the "untapped lever" from report.md section 13.2.

Axes (3 x 2 x 2 = 12 arms):

    text_level : none     -> empty text (image-only, matches Stage 3)
                 raw      -> low-level discrete action ("attack=1, forward=1")
                 abstract -> high-level CoA output from ``thought.jsonl``
    source     : prefix / retrieval
    k          : 3 / 5

``abstract`` needs ``thought.jsonl`` in each success rollout (a per-step record
of the VLM's CoA ``content``). Until that annotation exists it silently falls
back to empty text, so the offline validator reports ``abstract_ready`` per arm.
"""

import argparse
import collections
import json
import os
import subprocess
import sys
import time

import config
import experiment_guard
import metrics
import sub_vla
from harness import visual_memory
from harness.candidates.search_demo_harness import SearchDemoHarness

CONFIG_NAME = "openha_eager_icl"  # bare model: no LoRA, text ICL on
OUT_ROOT = os.path.join(config.EVO_ROOT, "probe_stage3b")
SEARCH_HARNESS = os.path.join(config.EVO_ROOT, "harness", "candidates", "search_demo_harness.py")
MEMORY_BANK = os.path.join(config.EVO_ROOT, "eval", "icl_memory_bank", "kill_entity_bank.json")
POOL_ROOT = "/data3/openha_evo/eval/icl_success_pool/00_original_icl_trainonly"
# ``abstract`` demo text needs per-step CoA (thought.jsonl), which only exists in
# the annotated pool (annotate_coa.py promotes success rollouts there).
ABSTRACT_POOL_ROOT = "/data3/openha_evo/eval/icl_success_pool/01_annotated_icl"
ABSTRACT_MEMORY_BANK = os.path.join(config.EVO_ROOT, "eval", "icl_memory_bank", "kill_entity_bank_annotated.json")
GPU_MIN_FREE_MB = 25000

TEXT_LEVELS = ["none", "raw", "abstract"]
SOURCES = ["prefix", "retrieval"]
FRAME_MODE = "state"  # Stage-3 winner, pinned
KS = [3, 5]


def build_arms():
    arms = []
    for text_level in TEXT_LEVELS:
        for source in SOURCES:
            for k in KS:
                arms.append({
                    "name": f"{source}_{FRAME_MODE}_{k}_{text_level}",
                    "source": source,
                    "frame_mode": FRAME_MODE,
                    "k": k,
                    "text_level": text_level,
                })
    return arms


def build_kill_subset(limit=None):
    tasks = metrics.read_task_list(config.TRAIN_TASKS)
    subset = [t for t in tasks if config.category(t) == "kill_entity"]
    if limit is not None:
        subset = subset[:limit]
    os.makedirs(OUT_ROOT, exist_ok=True)
    path = os.path.join(OUT_ROOT, "kill_entity_subset.txt")
    with open(path, "w") as f:
        f.write("\n".join(subset) + ("\n" if subset else ""))
    return path, subset


def _pool_has_rollouts(pool_root):
    if not os.path.isdir(pool_root):
        return False
    for d in os.listdir(pool_root):
        td = os.path.join(pool_root, d)
        if not os.path.isdir(td):
            continue
        for r in os.listdir(td):
            rd = os.path.join(td, r)
            if os.path.isdir(rd) and os.path.exists(os.path.join(rd, "episode.jsonl")):
                return True
    return False


def ensure_memory_bank():
    os.makedirs(os.path.dirname(MEMORY_BANK), exist_ok=True)
    rebuild_main = not os.path.exists(MEMORY_BANK)
    if not rebuild_main:
        try:
            experiment_guard.assert_bank_has_known_splits(MEMORY_BANK)
        except RuntimeError:
            rebuild_main = True
    if rebuild_main:
        entries = visual_memory.build_bank(
            POOL_ROOT, MEMORY_BANK, categories=["kill_entity"],
            train_tasks_path=config.TRAIN_TASKS, test_tasks_path=config.TEST_TASKS)
        print(f"[stage3b] built memory bank: {len(entries)} entries -> {MEMORY_BANK}", flush=True)
    os.makedirs(os.path.dirname(ABSTRACT_MEMORY_BANK), exist_ok=True)
    rebuild_abstract = not os.path.exists(ABSTRACT_MEMORY_BANK)
    if not rebuild_abstract:
        try:
            experiment_guard.assert_bank_has_known_splits(ABSTRACT_MEMORY_BANK)
        except RuntimeError:
            rebuild_abstract = True
    if rebuild_abstract and _pool_has_rollouts(ABSTRACT_POOL_ROOT):
        entries = visual_memory.build_bank(
            ABSTRACT_POOL_ROOT, ABSTRACT_MEMORY_BANK, categories=["kill_entity"],
            train_tasks_path=config.TRAIN_TASKS, test_tasks_path=config.TEST_TASKS)
        print(f"[stage3b] built abstract memory bank: {len(entries)} entries -> {ABSTRACT_MEMORY_BANK}", flush=True)


def _pool_bank_for(text_level):
    if text_level == "abstract":
        return ABSTRACT_POOL_ROOT, ABSTRACT_MEMORY_BANK
    return POOL_ROOT, MEMORY_BANK


def arm_env(arm, exclude_eval_task=False, exclude_eval_entity=False):
    pool, bank = _pool_bank_for(arm["text_level"])
    env = {
        "OPENHA_HARNESS_PATH": SEARCH_HARNESS,
        "OPENHA_AGENT_MODULE": "streaming_openha_original_harness",
        "OPENHA_DEMO_SOURCE": arm["source"],
        "OPENHA_FRAME_MODE": arm["frame_mode"],
        "OPENHA_ICL_K": str(arm["k"]),
        "OPENHA_DEMO_TEXT_LEVEL": arm["text_level"],
        "OPENHA_SUCCESS_POOL": pool,
        "OPENHA_MEMORY_BANK": bank,
    }
    if exclude_eval_task:
        env["OPENHA_EXCLUDE_EVAL_TASK"] = "1"
    if exclude_eval_entity:
        env["OPENHA_EXCLUDE_EVAL_ENTITY"] = "1"
    return env


def offline_validate(subset, arms=None, limit=None, exclude_eval_task=False,
                     exclude_eval_entity=False):
    """Build demos for every arm without touching the VLM/GPU."""
    tasks = subset if limit is None else subset[:limit]
    report = {}
    for arm in (arms or build_arms()):
        pool, bank = _pool_bank_for(arm["text_level"])
        harness = SearchDemoHarness(
            source=arm["source"], frame_mode=arm["frame_mode"], k=arm["k"],
            text_level=arm["text_level"], pool_root=pool, bank_path=bank,
            exclude_eval_task=exclude_eval_task,
            exclude_eval_entity=exclude_eval_entity)
        empty = 0
        short = 0
        nonempty_text = 0
        for t in tasks:
            demos = harness.build_visual_demos("", t)
            n = len(demos)
            if n == 0:
                empty += 1
            elif n < arm["k"]:
                short += 1
            nonempty_text += sum(1 for _, txt in demos if txt)
        report[arm["name"]] = {
            "tasks": len(tasks),
            "empty": empty,
            "short_of_k": short,
            "nonempty_text_demos": nonempty_text,
            "abstract_ready": nonempty_text > 0 if arm["text_level"] == "abstract" else None,
        }
        print(f"[offline] {arm['name']}: empty={empty}/{len(tasks)} "
              f"short={short} nonempty_text={nonempty_text}", flush=True)
    return report


def parse_gpus(spec):
    if not spec.strip():
        return None
    return [int(x.strip()) for x in spec.split(",") if x.strip() != ""]


def pick_free_gpus(n, min_free_mb=GPU_MIN_FREE_MB):
    out = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=index,memory.used,memory.total", "--format=csv,noheader,nounits"],
        text=True,
    )
    gpus = []
    for line in out.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 3:
            idx, used, total = int(parts[0]), int(parts[1]), int(parts[2])
            gpus.append((idx, total - used))
    gpus.sort(key=lambda x: -x[1])
    chosen = [idx for idx, free in gpus if free >= min_free_mb][:n]
    if len(chosen) < n:
        raise RuntimeError(f"Need {n} GPUs with >= {min_free_mb} MB free, found {len(chosen)}")
    return chosen


def launch_arm(arm, subset_path, gpu, max_steps,
               exclude_eval_task=False, exclude_eval_entity=False):
    record_path = os.path.join(OUT_ROOT, arm["name"])
    os.makedirs(record_path, exist_ok=True)
    log_file = os.path.join(config.LOGS_DIR, f"probe_stage3b_{arm['name']}.log")
    proc = sub_vla.run_eval(
        CONFIG_NAME, subset_path, record_path, gpu,
        max_steps=max_steps, log_file=log_file,
        lora_adapter_path=None, bench_seed=config.BENCH_SEED,
        extra_env=arm_env(arm, exclude_eval_task, exclude_eval_entity),
    )
    print(f"[stage3b] launched {arm['name']} gpu={gpu} pid={proc.pid}", flush=True)
    return record_path, proc


def collect_arm(arm, record_path, proc, subset_path):
    rc = proc.wait()
    result_dir = os.path.join(record_path, CONFIG_NAME)
    m = metrics.compute_metrics(result_dir, subset_path) if rc == 0 else None
    asr = m["overall"]["asr"] if m else None
    entry = {
        "rc": rc,
        "asr": asr,
        "by_category": m["by_category"] if m else None,
        "missing": len(m["missing"]) if m else None,
    }
    print(f"[stage3b] {arm['name']} rc={rc} asr={asr}", flush=True)
    return entry


def run_parallel(arms, subset_path, gpus, max_steps,
                 exclude_eval_task=False, exclude_eval_entity=False):
    summary = {}
    pending = collections.deque(arms)
    running = {}
    for gpu in gpus:
        if not pending:
            break
        arm = pending.popleft()
        record_path, proc = launch_arm(
            arm, subset_path, gpu, max_steps,
            exclude_eval_task, exclude_eval_entity)
        running[gpu] = (arm, record_path, proc)
    while running:
        finished_gpu = None
        for gpu, (arm, record_path, proc) in running.items():
            if proc.poll() is not None:
                summary[arm["name"]] = collect_arm(arm, record_path, proc, subset_path)
                finished_gpu = gpu
                break
        if finished_gpu is None:
            time.sleep(2)
            continue
        del running[finished_gpu]
        if pending:
            arm = pending.popleft()
            record_path, proc = launch_arm(
                arm, subset_path, finished_gpu, max_steps,
                exclude_eval_task, exclude_eval_entity)
            running[finished_gpu] = (arm, record_path, proc)
    return summary


def main():
    p = argparse.ArgumentParser(description="Stage-3B demo-text abstraction-level sweep (bare OpenHA)")
    p.add_argument("--offline", action="store_true", help="validate arms without GPU/VLM")
    p.add_argument("--max-steps", type=int, default=config.DEFAULT_MAX_STEPS)
    p.add_argument("--arms", default="", help="comma-separated arm names (default: all 12)")
    p.add_argument("--gpus", default="", help="comma-separated GPU indices (default: auto-pick)")
    p.add_argument("--sequential", action="store_true", help="run arms one at a time on first GPU")
    p.add_argument("--subset-limit", type=int, default=None, help="cap subset to N tasks")
    p.add_argument("--text-levels", default="", help="comma-separated text levels (default: none,raw,abstract)")
    p.add_argument("--exclude-eval-task", action="store_true",
                   help="do not allow a task to retrieve demos from itself")
    p.add_argument("--exclude-eval-entity", action="store_true",
                   help="for entity tasks, do not allow demos from the same entity")
    args = p.parse_args()

    ensure_memory_bank()
    subset_path, subset = build_kill_subset(limit=args.subset_limit)
    print(f"[stage3b] kill_entity subset = {len(subset)} tasks -> {subset_path}", flush=True)

    arms = build_arms()
    if args.text_levels:
        want = set(args.text_levels.split(","))
        arms = [a for a in arms if a["text_level"] in want]
    if args.arms:
        want = set(args.arms.split(","))
        arms = [a for a in arms if a["name"] in want]
    if not arms:
        print("ERROR: no arms selected", file=sys.stderr)
        sys.exit(2)
    guard = {
        "main": experiment_guard.assert_no_test_leak(POOL_ROOT, MEMORY_BANK),
    }
    if any(a["text_level"] == "abstract" for a in arms):
        guard["abstract"] = experiment_guard.assert_no_test_leak(
            ABSTRACT_POOL_ROOT, ABSTRACT_MEMORY_BANK)
    config_path, snapshot = experiment_guard.write_run_config_snapshot(
        OUT_ROOT,
        stage="stage3b_demo_text_level",
        config_name=CONFIG_NAME,
        success_pool=POOL_ROOT,
        annotated_pool=ABSTRACT_POOL_ROOT,
        memory_bank=MEMORY_BANK,
        abstract_memory_bank=ABSTRACT_MEMORY_BANK,
        task_list=subset_path,
        subset_limit=args.subset_limit,
        arms=args.arms or "all",
        text_levels=args.text_levels or "all",
        max_steps=args.max_steps,
        bench_seed=config.BENCH_SEED,
        exclude_eval_task=args.exclude_eval_task,
        exclude_eval_entity=args.exclude_eval_entity,
        guard=guard,
    )
    print(f"[stage3b] guard ok; run config -> {config_path}", flush=True)
    print(f"[stage3b] run config sha256 = {snapshot['config_sha256']}", flush=True)
    print(f"[stage3b] {len(arms)} arms, config={CONFIG_NAME} (bare, no LoRA)", flush=True)

    if args.offline:
        report = offline_validate(
            subset, arms=arms, limit=args.subset_limit,
            exclude_eval_task=args.exclude_eval_task,
            exclude_eval_entity=args.exclude_eval_entity)
        out_path = os.path.join(OUT_ROOT, "offline_search_validation.json")
        with open(out_path, "w") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        print(f"[stage3b] offline validation -> {out_path}", flush=True)
        return

    if args.gpus:
        gpus = parse_gpus(args.gpus)
    elif args.sequential:
        gpus = pick_free_gpus(1)
    else:
        gpus = pick_free_gpus(len(arms))
    print(f"[stage3b] GPUs = {gpus}", flush=True)

    summary = {}
    if args.sequential:
        gpu = gpus[0]
        for arm in arms:
            record_path, proc = launch_arm(
                arm, subset_path, gpu, args.max_steps,
                args.exclude_eval_task, args.exclude_eval_entity)
            summary[arm["name"]] = collect_arm(arm, record_path, proc, subset_path)
    else:
        summary = run_parallel(
            arms, subset_path, gpus, args.max_steps,
            args.exclude_eval_task, args.exclude_eval_entity)

    out_path = os.path.join(OUT_ROOT, "probe_summary.json")
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"[stage3b] summary -> {out_path}", flush=True)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
