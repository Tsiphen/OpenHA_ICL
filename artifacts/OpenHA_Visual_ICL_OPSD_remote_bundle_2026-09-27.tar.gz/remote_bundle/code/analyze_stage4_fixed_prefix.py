#!/usr/bin/env python3
"""Analyze Stage4-B fixed-prefix replay without overstating causality.

The input is a replay JSON produced by replay_stage4_fixed_prefix.py. All
comparisons are paired within (task, prefix_index), with
truncation_control as the primary baseline. The report deliberately separates:

* likelihood of the sampled action text under each condition;
* likelihood of the recorded next action text, which is only a behavioral
  reference and not an oracle action label;
* decoded-action and exact-text changes.

This is a pilot report, not an end-to-end success-rate result.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path

import numpy as np


CONDITIONS = [
    "current_history",
    "success_demo",
    "category_demo",
    "negative_demo",
]


def finite(value):
    return value is not None and np.isfinite(float(value))


def paired_deltas(rows, field, baseline="truncation_control"):
    grouped = {}
    for row in rows:
        key = (row["task"], int(row["prefix_index"]))
        grouped.setdefault(key, {})[row["condition"]] = row
    out = {}
    for condition in CONDITIONS:
        values = []
        pairs = []
        for key, group in sorted(grouped.items()):
            base = group.get(baseline)
            target = group.get(condition)
            if not base or not target:
                continue
            base_value = base.get(field, {}).get("mean_logprob")
            target_value = target.get(field, {}).get("mean_logprob")
            if finite(base_value) and finite(target_value):
                value = float(target_value) - float(base_value)
                values.append(value)
                pairs.append({
                    "task": key[0],
                    "prefix_index": key[1],
                    "delta": value,
                })
        out[condition] = {
            "n_pairs": len(values),
            "mean_delta": float(np.mean(values)) if values else None,
            "median_delta": float(np.median(values)) if values else None,
            "std_delta": float(np.std(values, ddof=1)) if len(values) > 1 else None,
            "positive": int(sum(value > 0 for value in values)),
            "negative": int(sum(value < 0 for value in values)),
            "zero": int(sum(value == 0 for value in values)),
            "bootstrap_ci95_mean": bootstrap_ci(values),
            "pairs": pairs,
        }
    return out


def paired_deltas_by_phase(rows, field, baseline="truncation_control"):
    phases = sorted({row.get("phase", "unknown") for row in rows})
    return {
        phase: paired_deltas(
            [row for row in rows if row.get("phase", "unknown") == phase],
            field,
            baseline=baseline,
        )
        for phase in phases
    }


def paired_condition_contrast(rows, field, left, right):
    grouped = {}
    for row in rows:
        key = (row["task"], int(row["prefix_index"]))
        grouped.setdefault(key, {})[row["condition"]] = row
    values = []
    pairs = []
    for key, group in sorted(grouped.items()):
        left_row = group.get(left)
        right_row = group.get(right)
        if not left_row or not right_row:
            continue
        left_value = left_row.get(field, {}).get("mean_logprob")
        right_value = right_row.get(field, {}).get("mean_logprob")
        if finite(left_value) and finite(right_value):
            value = float(left_value) - float(right_value)
            values.append(value)
            pairs.append({
                "task": key[0],
                "prefix_index": key[1],
                "delta": value,
            })
    return {
        "left": left,
        "right": right,
        "n_pairs": len(values),
        "mean_delta": float(np.mean(values)) if values else None,
        "median_delta": float(np.median(values)) if values else None,
        "std_delta": float(np.std(values, ddof=1)) if len(values) > 1 else None,
        "positive": int(sum(value > 0 for value in values)),
        "negative": int(sum(value < 0 for value in values)),
        "zero": int(sum(value == 0 for value in values)),
        "bootstrap_ci95_mean": bootstrap_ci(values),
        "pairs": pairs,
    }


def bootstrap_ci(values, seed=20260919, n_boot=10000):
    if not values:
        return [None, None]
    values = np.asarray(values, dtype=float)
    if len(values) == 1:
        value = float(values[0])
        return [value, value]
    rng = np.random.default_rng(seed)
    samples = rng.choice(values, size=(n_boot, len(values)), replace=True)
    means = samples.mean(axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    return [float(low), float(high)]


def summarize_pairs(rows):
    grouped = {}
    for row in rows:
        key = (row["task"], int(row["prefix_index"]))
        grouped.setdefault(key, {})[row["condition"]] = row
    result = {}
    for condition in CONDITIONS:
        action_flips = 0
        text_changes = 0
        distance_changed = 0
        available = 0
        count_mismatch = 0
        for group in grouped.values():
            base = group.get("truncation_control")
            target = group.get(condition)
            if not base or not target:
                continue
            available += 1
            action_flips += int(
                target.get("decoded_action") != base.get("decoded_action")
            )
            text_changes += int(target.get("content") != base.get("content"))
            distance_changed += int(
                target.get("action_distance_between_conditions")
                != base.get("action_distance_between_conditions")
            )
            for field in ("reference_token_stats", "recorded_action_token_stats"):
                left = base.get(field, {}).get("count")
                right = target.get(field, {}).get("count")
                if left is not None and right is not None and left != right:
                    count_mismatch += 1
        result[condition] = {
            "n_pairs": available,
            "decoded_action_flips": action_flips,
            "exact_text_changes": text_changes,
            "distance_field_changes": distance_changed,
            "token_count_mismatch_events": count_mismatch,
        }
    return result


def make_report(data, report_json_path):
    rows = data["rows"]
    meta = data["meta"]
    ref_stats = paired_deltas(rows, "reference_token_stats")
    recorded_stats = paired_deltas(rows, "recorded_action_token_stats")
    ref_by_phase = paired_deltas_by_phase(rows, "reference_token_stats")
    recorded_by_phase = paired_deltas_by_phase(
        rows, "recorded_action_token_stats"
    )
    contrast_specs = [
        ("success_demo", "negative_demo"),
        ("success_demo", "category_demo"),
        ("category_demo", "negative_demo"),
    ]
    contrasts = {
        f"{left}_vs_{right}": {
            "fixed_sampled_action": paired_condition_contrast(
                rows, "reference_token_stats", left, right
            ),
            "recorded_next_action": paired_condition_contrast(
                rows, "recorded_action_token_stats", left, right
            ),
        }
        for left, right in contrast_specs
    }
    pair_stats = summarize_pairs(rows)
    result = {
        "meta": meta,
        "n_rows": len(rows),
        "n_prefixes": len({
            (row["task"], int(row["prefix_index"])) for row in rows
        }),
        "reference_sampled_action": ref_stats,
        "reference_recorded_next_action": recorded_stats,
        "reference_sampled_action_by_phase": ref_by_phase,
        "reference_recorded_next_action_by_phase": recorded_by_phase,
        "condition_contrasts": contrasts,
        "paired_behavior": pair_stats,
        "interpretation": {
            "supported": [
                "Changing the demonstration condition changes the likelihood "
                "assigned to a fixed action string at some prefixes.",
                "The current pilot does not show reliable discrete decoded-action "
                "flips relative to truncation_control.",
            ],
            "not_supported": [
                "A success demonstration universally increases the likelihood "
                "of the recorded next action.",
                "The recorded next action is an oracle action ground truth.",
                "A causal end-to-end success-rate improvement from this pilot alone.",
            ],
        },
    }
    report_json_path.write_text(json.dumps(result, indent=2, ensure_ascii=False))
    return result


def fmt(value):
    return "n/a" if value is None else f"{value:.4f}"


def write_markdown(result, path):
    meta = result["meta"]
    lines = [
        "# Stage4-B Fixed-Prefix Replay Pilot Analysis",
        "",
        f"> **Status:** pilot / mechanism screening only; generated on {dt.date.today().isoformat()}.",
        "> It is not a final paper main result and does not establish end-to-end causality.",
        "",
        "## Scope",
        "",
        f"- Rows: `{result['n_rows']}`",
        f"- Fixed prefixes: `{result['n_prefixes']}`",
        f"- Baseline: `truncation_control`",
        f"- Demo mode: `{meta.get('demo_mode', 'unknown')}`, `k={meta.get('k', 'unknown')}`",
        "- The source is a successful rollout replay. The recorded next action is "
          "reported as a behavior-alignment reference, not oracle action GT.",
        "",
        "## Paired Token-Likelihood Deltas",
        "",
        "All values are target mean log-probability under the condition minus the "
        "same target under `truncation_control`; positive is higher likelihood.",
        "",
        "| Condition | Fixed sampled action: mean delta | 95% bootstrap CI | + / - / 0 | Recorded next action: mean delta | 95% bootstrap CI | + / - / 0 |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for condition in CONDITIONS:
        left = result["reference_sampled_action"][condition]
        right = result["reference_recorded_next_action"][condition]
        lines.append(
            f"| `{condition}` | {fmt(left['mean_delta'])} | "
            f"[{fmt(left['bootstrap_ci95_mean'][0])}, {fmt(left['bootstrap_ci95_mean'][1])}] | "
            f"{left['positive']} / {left['negative']} / {left['zero']} | "
            f"{fmt(right['mean_delta'])} | "
            f"[{fmt(right['bootstrap_ci95_mean'][0])}, {fmt(right['bootstrap_ci95_mean'][1])}] | "
            f"{right['positive']} / {right['negative']} / {right['zero']} |"
        )
    lines += [
        "",
        "## Phase-Stratified Deltas",
        "",
        "This section is exploratory. A phase is defined from the recorded "
        "rollout action history before the current observation; it does not use "
        "a future success label.",
        "",
        "| Phase | Condition | N | Fixed sampled action mean delta | Recorded next action mean delta |",
        "|---|---|---:|---:|---:|",
    ]
    phases = sorted(result["reference_sampled_action_by_phase"])
    for phase in phases:
        for condition in CONDITIONS:
            left = result["reference_sampled_action_by_phase"][phase][condition]
            right = result["reference_recorded_next_action_by_phase"][phase][condition]
            lines.append(
                f"| `{phase}` | `{condition}` | {left['n_pairs']} | "
                f"{fmt(left['mean_delta'])} | {fmt(right['mean_delta'])} |"
            )
    lines += [
        "",
        "## Demo-Type Contrasts",
        "",
        "These are paired condition-vs-condition differences. Positive means the "
        "left condition assigns higher mean log-probability than the right "
        "condition under the same prefix.",
        "",
        "| Contrast | N | Fixed sampled action mean delta | 95% CI | Recorded next action mean delta | 95% CI |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for contrast_name, contrast in result["condition_contrasts"].items():
        left = contrast["fixed_sampled_action"]
        right = contrast["recorded_next_action"]
        lines.append(
            f"| `{contrast_name}` | {left['n_pairs']} | "
            f"{fmt(left['mean_delta'])} | "
            f"[{fmt(left['bootstrap_ci95_mean'][0])}, {fmt(left['bootstrap_ci95_mean'][1])}] | "
            f"{fmt(right['mean_delta'])} | "
            f"[{fmt(right['bootstrap_ci95_mean'][0])}, {fmt(right['bootstrap_ci95_mean'][1])}] |"
        )
    lines += [
        "",
        "## Discrete Output Changes",
        "",
        "| Condition | Prefix pairs | Decoded-action flips | Exact text changes |",
        "|---|---:|---:|---:|",
    ]
    for condition in CONDITIONS:
        item = result["paired_behavior"][condition]
        lines.append(
            f"| `{condition}` | {item['n_pairs']} | "
            f"{item['decoded_action_flips']} | {item['exact_text_changes']} |"
        )
    lines += [
        "",
        "## Current Conclusion",
        "",
        "**Supported:** the demonstration condition modulates action-token "
        "likelihood under a fixed observation/history prefix. This modulation is "
        "prefix-dependent and does not necessarily change the decoded action.",
        "",
        "**Not supported yet:** success demos consistently make the recorded next "
        "action more likely. The two references can move in different directions, "
        "and the recorded action is not an oracle label.",
        "",
        "## Next Experiment",
        "",
        "The 29-task phase-balanced replay is complete. The next experiment "
        "should test action-vector distance, phase alignment, and closed-loop "
        "success-rate consequences, with success-vs-negative/category contrasts "
        "reported explicitly.",
    ]
    path.write_text("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--demo-mode", default="state")
    parser.add_argument("--k", type=int, default=3)
    args = parser.parse_args()

    input_path = Path(args.input)
    rows = json.loads(input_path.read_text())
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = input_path.stem + "_analysis"
    result = make_report(
        {
            "rows": rows,
            "meta": {
                "source": str(input_path),
                "demo_mode": args.demo_mode,
                "k": args.k,
            },
        },
        output_dir / f"{stem}.json",
    )
    write_markdown(result, output_dir / f"{stem}.md")
    print(json.dumps({
        "rows": result["n_rows"],
        "prefixes": result["n_prefixes"],
        "json": str(output_dir / f"{stem}.json"),
        "markdown": str(output_dir / f"{stem}.md"),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
