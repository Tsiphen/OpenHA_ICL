"""Offline visual-ICL utilities: extract demonstration keyframes from rollouts.

Success rollouts are recorded by MineStudio as, under ``<task>/<rollout_id>/``:

  - episode.jsonl : one line per timestep, {"base64": <png b64>, "format": "png",
                    "resolution": [w, h]}
  - action.jsonl  : one line per timestep, discrete env action dict
  - info.jsonl    : one line per timestep, env info dict
  - success.json  : {"task":..., "steps":..., "fps":..., "success":true}

These helpers turn a rollout directory into a small list of (image, action-text)
demonstration pairs suitable for in-context injection into the VLM.

Two keyframe strategies are provided:

  - ``uniform`` : evenly spaced frames (Stage 1 baseline)
  - ``state``   : state-anchored frames at action/state transition points (Stage 2)
"""

import base64
import io
import json
import os


def _decode_frame_to_np(line):
    """Decode one episode.jsonl line into an RGB numpy array (H, W, 3)."""
    import numpy as np
    from PIL import Image

    d = json.loads(line)
    raw = base64.b64decode(d["base64"])
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    return np.asarray(img)


def load_frames(episode_jsonl_path):
    """Return a list of RGB numpy arrays, one per timestep, in order."""
    with open(episode_jsonl_path) as f:
        return [_decode_frame_to_np(line) for line in f if line.strip()]


def load_actions(action_jsonl_path):
    """Return a list of discrete action dicts, one per timestep, in order."""
    with open(action_jsonl_path) as f:
        return [json.loads(line) for line in f if line.strip()]


def load_infos(info_jsonl_path):
    """Return a list of env info dicts, one per timestep, in order."""
    if not os.path.exists(info_jsonl_path):
        return []
    with open(info_jsonl_path) as f:
        return [json.loads(line) for line in f if line.strip()]


def load_thoughts(thought_jsonl_path):
    """Return a list of CoA/reasoning text strings, one per timestep.

    ``thought.jsonl`` is an optional per-step record of the VLM's full CoA
    output (the ``content`` field). Each line is ``{"content": "..."}``.
    Returns an empty list when the file is absent (abstract text not annotated).
    """
    if not os.path.exists(thought_jsonl_path):
        return []
    out = []
    with open(thought_jsonl_path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            d = json.loads(line)
            out.append(d.get("content", "") if isinstance(d, dict) else str(d))
    return out


def uniform_keyframe_indices(n_frames, k):
    """Return ``k`` evenly spaced indices into ``[0, n_frames)`` (deduped)."""
    k = max(1, int(k))
    if n_frames <= 0:
        return []
    k = min(k, n_frames)
    if k == 1:
        return [n_frames // 2]
    step = (n_frames - 1) / (k - 1)
    return sorted({int(round(step * i)) for i in range(k)})


def _action_to_text(action):
    """Compress a discrete action dict into a short human-readable label."""
    if not action:
        return ""
    active = [k for k, v in action.items() if v not in (0, False, None)]
    if not active:
        return "(noop)"
    return ", ".join(f"{k}={action[k]}" for k in active)


# ---- State-anchored keyframe extraction (Stage 2A) ----

# Binary/motion keys used to build the per-frame action feature vector.
ACTION_KEYS = [
    "attack", "back", "forward", "left", "right", "jump", "sprint", "sneak",
    "use", "inventory", "pickItem",
]

# Default weights for the anchor-importance scorer. ``attack_onset`` is boosted
# because for kill_entity the moment the agent starts attacking is the single
# most informative frame.
DEFAULT_ANCHOR_WEIGHTS = {
    "transition": 1.0,
    "health": 1.0,
    "attack_onset": 2.0,
    "displacement": 1.0,
    "boundary": 1.0,
}


def _action_vec(action):
    """Binarise a discrete action into a small numeric feature vector."""
    v = [1.0 if action.get(k, 0) else 0.0 for k in ACTION_KEYS]
    cam = action.get("camera") or [0.0, 0.0]
    v.append(min(1.0, (abs(cam[0]) + abs(cam[1])) / 200.0))
    return v


def state_anchor_scores(actions, infos=None, weights=None):
    """Return a per-frame importance score aligned with ``actions``.

    Features (each normalised to [0, 1] before weighted combination):
      - ``transition``     : L1 change of the action vector from the previous frame
      - ``health``         : |health_t - health_{t-1}|  (combat damage)
      - ``attack_onset``   : 0 -> 1 attack transitions
      - ``displacement``   : |dx| + |dz| positional movement
      - ``boundary``       : first / last frame anchors
    """
    import numpy as np

    n = len(actions)
    if n == 0:
        return np.zeros(0, dtype=float)
    w = weights or DEFAULT_ANCHOR_WEIGHTS

    av = np.array([_action_vec(a) for a in actions], dtype=float)

    trans = np.zeros(n)
    if n > 1:
        trans[1:] = np.abs(av[1:] - av[:-1]).sum(axis=1)
    trans = trans / (trans.max() + 1e-8)

    health = np.zeros(n)
    if infos and n > 1:
        h = np.array([
            infos[i].get("health", 0.0) if i < len(infos) else 0.0
            for i in range(n)
        ])
        health[1:] = np.abs(h[1:] - h[:-1])
        health = health / (health.max() + 1e-8)

    onset = np.zeros(n)
    if n > 1:
        atk = av[:, 0]
        onset[1:] = ((atk[1:] > 0) & (atk[:-1] == 0)).astype(float)

    disp = np.zeros(n)
    if infos and n > 1:
        xs = np.array([
            infos[i].get("location_stats", {}).get("xpos", 0.0) if i < len(infos) else 0.0
            for i in range(n)
        ])
        zs = np.array([
            infos[i].get("location_stats", {}).get("zpos", 0.0) if i < len(infos) else 0.0
            for i in range(n)
        ])
        disp[1:] = np.abs(xs[1:] - xs[:-1]) + np.abs(zs[1:] - zs[:-1])
        disp = disp / (disp.max() + 1e-8)

    boundary = np.zeros(n)
    boundary[0] = 1.0
    boundary[-1] = 1.0

    return (
        w["transition"] * trans
        + w["health"] * health
        + w["attack_onset"] * onset
        + w["displacement"] * disp
        + w["boundary"] * boundary
    )


def state_anchor_keyframe_indices(n_frames, k, actions=None, infos=None,
                                  weights=None, min_gap=1):
    """Pick ``k`` anchor frames by importance with a temporal-diversity gap."""
    k = max(1, int(k))
    if n_frames <= 0:
        return []
    k = min(k, n_frames)
    if k == n_frames:
        return list(range(n_frames))
    if not actions:
        return uniform_keyframe_indices(n_frames, k)

    import numpy as np

    score = state_anchor_scores(actions, infos, weights)
    if k == 1:
        return [int(np.argmax(score))]

    # Always anchor the start and end states.
    chosen = [0, n_frames - 1]
    order = sorted(range(n_frames), key=lambda i: -score[i])
    for i in order:
        if len(chosen) >= k:
            break
        if all(abs(i - c) >= min_gap for c in chosen):
            chosen.append(i)
    if len(chosen) < k:
        for i in order:
            if i not in chosen:
                chosen.append(i)
                if len(chosen) == k:
                    break
    return sorted(chosen)


def coverage_keyframe_indices(n_frames, k, actions=None, infos=None, min_gap=1):
    """Pick k frames balancing coverage (uniform spread) and important moments.

    Anchors first/last for k>=2, then fills the middle by interleaving uniform
    candidates (temporal coverage) with attack-onset peaks (importance). Unlike
    the pure state scorer, this never collapses onto a single cluster.
    """
    import numpy as np

    k = max(1, int(k))
    if n_frames <= 0:
        return []
    k = min(k, n_frames)
    if k == 1:
        return [n_frames // 2]
    if k == n_frames:
        return list(range(n_frames))

    chosen = [0, n_frames - 1]
    if k == 2:
        return sorted(chosen)

    onset = np.zeros(n_frames)
    if actions:
        av = np.array([_action_vec(a) for a in actions], dtype=float)
        if n_frames > 1:
            atk = av[:, 0]
            onset[1:] = ((atk[1:] > 0) & (atk[:-1] == 0)).astype(float)

    uniform_candidates = [i for i in uniform_keyframe_indices(n_frames, k)
                          if i not in chosen]
    onset_candidates = sorted(
        (i for i in range(n_frames) if i not in chosen and onset[i] > 0),
        key=lambda i: -onset[i],
    )

    def respects_gap(i):
        return all(abs(i - c) >= min_gap for c in chosen)

    interleaved = []
    for j in range(max(len(uniform_candidates), len(onset_candidates))):
        if j < len(uniform_candidates):
            interleaved.append(uniform_candidates[j])
        if j < len(onset_candidates):
            interleaved.append(onset_candidates[j])

    for i in interleaved:
        if len(chosen) >= k:
            break
        if i not in chosen and respects_gap(i):
            chosen.append(i)

    if len(chosen) < k:
        for i in range(n_frames):
            if i not in chosen:
                chosen.append(i)
                if len(chosen) == k:
                    break

    return sorted(chosen)


def load_demos(rollout_dir, k=3, mode="uniform", anchor_weights=None,
               text_mode="raw"):
    """Return list of (np_image, demo_text) sampled from one rollout dir.

    ``mode`` is ``"uniform"`` (evenly spaced), ``"state"`` (state-anchored),
    or ``"coverage"`` (first/last + uniform + attack-onset mix).

    ``text_mode`` selects the demo text abstraction level:
      - ``"raw"``      : low-level discrete action (``attack=1, forward=1``)
      - ``"abstract"`` : high-level CoA output from ``thought.jsonl`` (falls
                         back to "" when the file has not been annotated)
      - ``"none"``     : empty text (image-only ICL)
    """
    ep = os.path.join(rollout_dir, "episode.jsonl")
    ac = os.path.join(rollout_dir, "action.jsonl")
    if not (os.path.exists(ep) and os.path.exists(ac)):
        return []
    frames = load_frames(ep)
    actions = load_actions(ac)
    if mode == "state":
        infos = load_infos(os.path.join(rollout_dir, "info.jsonl"))
        idxs = state_anchor_keyframe_indices(
            len(frames), k, actions, infos, anchor_weights)
    elif mode == "coverage":
        idxs = coverage_keyframe_indices(len(frames), k, actions)
    else:
        idxs = uniform_keyframe_indices(len(frames), k)

    thoughts = None
    if text_mode == "abstract":
        thoughts = load_thoughts(os.path.join(rollout_dir, "thought.jsonl"))

    demos = []
    for i in idxs:
        if text_mode == "abstract":
            text = thoughts[i] if thoughts and i < len(thoughts) else ""
        elif text_mode == "none":
            text = ""
        else:
            text = _action_to_text(actions[i]) if i < len(actions) else ""
        demos.append((frames[i], text))
    return demos


def find_rollout(task_dir):
    """Return the first rollout dir containing episode.jsonl, else None."""
    if not os.path.isdir(task_dir):
        return None
    for name in sorted(os.listdir(task_dir)):
        p = os.path.join(task_dir, name)
        if os.path.isdir(p) and os.path.exists(os.path.join(p, "episode.jsonl")):
            return p
    return None


def _task_dirname_to_task(name):
    if ":" in name:
        return name
    for cat in ("kill_entity", "mine_block", "custom", "craft_item"):
        prefix = cat + "_"
        if name.startswith(prefix):
            return cat + ":" + name[len(prefix):]
    head, _, tail = name.partition("_")
    return head + ":" + tail if tail else name


def _entity_of(task_name):
    return task_name.split(":", 1)[1] if ":" in task_name else task_name


def load_demos_for_task(success_pool_root, task_name, k=3, mode="uniform",
                        anchor_weights=None, text_mode="raw",
                        exclude_task=None, exclude_entity=None):
    """Load ``k`` demo (image, text) pairs for a task from the success pool.

    ``success_pool_root`` contains one dir per task named with underscores
    (``kill_entity_zombie``), each holding ``<rollout_id>/episode.jsonl``. Falls
    back to any task dir sharing the same category prefix if the exact task is
    absent. ``text_mode`` is passed through to :func:`load_demos`.
    """
    exclude_task = exclude_task or ""
    exclude_entity = exclude_entity or ""
    task_dir = os.path.join(success_pool_root, task_name.replace(":", "_"))
    rollout = None
    if task_name != exclude_task and _entity_of(task_name) != exclude_entity:
        rollout = find_rollout(task_dir)
    if rollout is None and ":" in task_name:
        cat = task_name.split(":", 1)[0] + "_"
        parent = os.path.dirname(task_dir)
        if os.path.isdir(parent):
            for d in sorted(os.listdir(parent)):
                candidate_task = _task_dirname_to_task(d)
                if candidate_task == exclude_task:
                    continue
                if _entity_of(candidate_task) == exclude_entity:
                    continue
                if d.startswith(cat):
                    rollout = find_rollout(os.path.join(parent, d))
                    if rollout:
                        break
    if rollout is None:
        return []
    return load_demos(rollout, k=k, mode=mode, anchor_weights=anchor_weights,
                      text_mode=text_mode)
