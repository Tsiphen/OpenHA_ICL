"""Visual memory bank + retrieval for image-ICL demos (Stage 2B).

The bank is a lightweight, offline-built index over the success pool. Each
entry records the entity attributes (locomotion / hostility / attack style)
and a discrete action signature of one success rollout. Retrieval hard-filters
by task category, soft-ranks by attribute match (locomotion is dominant) and
then picks a representative demo among the best attribute tier.

This solves the Stage-1 fallback weakness where ``kill_entity:bat`` (flying)
would wrongly fall back to ``kill_entity_cow`` (ground): attribute retrieval
routes flying queries to the closest flying demo (e.g. parrot).

The index stores rollout *paths*, not images; frames are re-read on demand via
``visual_icl.load_demos``.
"""

import json
import os

from harness import visual_icl


# Minecraft entity attributes used for kill_entity retrieval.
ENTITY_ATTRS = {
    # test-v2 kill_entity entities
    "bat": {"locomotion": "flying", "hostility": "passive", "attack": "melee"},
    "bee": {"locomotion": "flying", "hostility": "neutral", "attack": "melee"},
    "cat": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "cave_spider": {"locomotion": "ground", "hostility": "hostile", "attack": "melee"},
    "cod": {"locomotion": "aquatic", "hostility": "passive", "attack": "melee"},
    "creeper": {"locomotion": "ground", "hostility": "hostile", "attack": "melee"},
    "donkey": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "enderman": {"locomotion": "ground", "hostility": "neutral", "attack": "melee"},
    "evoker": {"locomotion": "ground", "hostility": "hostile", "attack": "ranged"},
    "ghast": {"locomotion": "flying", "hostility": "hostile", "attack": "ranged"},
    "horse": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "iron_golem": {"locomotion": "ground", "hostility": "neutral", "attack": "melee"},
    "llama": {"locomotion": "ground", "hostility": "neutral", "attack": "melee"},
    "mooshroom": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "ocelot": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "pillager": {"locomotion": "ground", "hostility": "hostile", "attack": "ranged"},
    "polar_bear": {"locomotion": "ground", "hostility": "neutral", "attack": "melee"},
    "pufferfish": {"locomotion": "aquatic", "hostility": "passive", "attack": "melee"},
    "rabbit": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "salmon": {"locomotion": "aquatic", "hostility": "passive", "attack": "melee"},
    "sheep": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "skeleton": {"locomotion": "ground", "hostility": "hostile", "attack": "ranged"},
    "slime": {"locomotion": "ground", "hostility": "hostile", "attack": "melee"},
    "squid": {"locomotion": "aquatic", "hostility": "passive", "attack": "melee"},
    "stray": {"locomotion": "ground", "hostility": "hostile", "attack": "ranged"},
    "tropical_fish": {"locomotion": "aquatic", "hostility": "passive", "attack": "melee"},
    "vex": {"locomotion": "flying", "hostility": "hostile", "attack": "melee"},
    "witch": {"locomotion": "ground", "hostility": "hostile", "attack": "ranged"},
    "zombie_villager": {"locomotion": "ground", "hostility": "hostile", "attack": "melee"},
    # success-pool-only extras
    "cow": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "drowned": {"locomotion": "aquatic", "hostility": "hostile", "attack": "melee"},
    "fox": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "husk": {"locomotion": "ground", "hostility": "hostile", "attack": "melee"},
    "parrot": {"locomotion": "flying", "hostility": "passive", "attack": "melee"},
    "pig": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "skeleton_horse": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "turtle": {"locomotion": "aquatic", "hostility": "passive", "attack": "melee"},
    "villager": {"locomotion": "ground", "hostility": "passive", "attack": "melee"},
    "vindicator": {"locomotion": "ground", "hostility": "hostile", "attack": "melee"},
}

# Attribute importance for kill_entity: locomotion is the dominant behavioural
# axis (flying / ground / aquatic change the whole visual-action pattern),
# followed by attack style, then hostility.
ATTR_WEIGHTS = {"locomotion": 0.5, "attack": 0.3, "hostility": 0.2}

# Action keys used to build a rollout's behavioural signature.
SIGNATURE_KEYS = ["attack", "forward", "jump", "use", "sprint", "left", "right", "back"]


# Categories that may contain an underscore themselves (e.g. kill_entity).
KNOWN_CATEGORIES = ("kill_entity", "mine_block", "custom", "craft_item")


def parse_task(task_name):
    """Return ``(category, entity)`` for colon or underscore task names.

    Handles the ``kill_entity_cow`` convention where the category itself
    contains an underscore, by matching against known category prefixes.
    """
    if ":" in task_name:
        cat, entity = task_name.split(":", 1)
        return cat, entity
    for c in KNOWN_CATEGORIES:
        if task_name.startswith(c + "_"):
            return c, task_name[len(c) + 1:]
    head, _, tail = task_name.partition("_")
    return head, tail


def entity_of(task_name):
    """Extract the entity name from ``kill_entity:bat`` or ``kill_entity_bat``."""
    return parse_task(task_name)[1]


def category_of(task_name):
    return parse_task(task_name)[0]


def attrs_of(entity):
    return ENTITY_ATTRS.get(entity)


def action_signature(rollout_dir):
    """Normalised frequency of key discrete actions over a rollout."""
    ac = os.path.join(rollout_dir, "action.jsonl")
    if not os.path.exists(ac):
        return {}
    actions = visual_icl.load_actions(ac)
    sig = {k: 0.0 for k in SIGNATURE_KEYS}
    for a in actions:
        for k in SIGNATURE_KEYS:
            if a.get(k, 0):
                sig[k] += 1.0
    n = max(1, len(actions))
    return {k: v / n for k, v in sig.items()}


def attr_similarity(query_attrs, entry_attrs):
    if not query_attrs or not entry_attrs:
        return 0.0
    s = 0.0
    for key, w in ATTR_WEIGHTS.items():
        if query_attrs.get(key) == entry_attrs.get(key):
            s += w
    return s


def _read_task_set(path):
    if not path:
        return set()
    tasks = set()
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                tasks.add(line)
    return tasks


def _split_of(task_name, train_tasks=None, test_tasks=None):
    task = task_name if ":" in task_name else task_name.replace("_", ":", 1)
    for cat in KNOWN_CATEGORIES:
        prefix = cat + "_"
        if task_name.startswith(prefix):
            task = cat + ":" + task_name[len(prefix):]
            break
    if train_tasks and task in train_tasks:
        return "train"
    if test_tasks and task in test_tasks:
        return "test"
    return "unknown"


def build_bank(success_pool_root, out_path, categories=None,
               train_tasks_path=None, test_tasks_path=None):
    """Scan the success pool and write a retrieval index JSON.

    Returns the list of entries (also persisted to ``out_path``).
    """
    categories = categories or ["kill_entity"]
    train_tasks = _read_task_set(train_tasks_path)
    test_tasks = _read_task_set(test_tasks_path)
    entries = []
    for name in sorted(os.listdir(success_pool_root)):
        task_dir = os.path.join(success_pool_root, name)
        if not os.path.isdir(task_dir):
            continue
        cat = category_of(name)
        if categories and cat not in categories:
            continue
        entity = entity_of(name)
        attrs = attrs_of(entity)
        for rname in sorted(os.listdir(task_dir)):
            rdir = os.path.join(task_dir, rname)
            if not os.path.isdir(rdir):
                continue
            if not os.path.exists(os.path.join(rdir, "episode.jsonl")):
                continue
            entries.append({
                "task": name,
                "split": _split_of(name, train_tasks, test_tasks),
                "entity": entity,
                "category": cat,
                "attrs": attrs,
                "rollout_dir": rdir,
                "action_signature": action_signature(rdir),
            })
    out_path = out_path
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(entries, f, indent=2, ensure_ascii=False)
    return entries


def load_bank(bank_path):
    with open(bank_path) as f:
        return json.load(f)


def _attack_ratio(entry):
    sig = entry.get("action_signature") or {}
    return sig.get("attack", 0.0)


def retrieve(bank, task_name, k=3, mode="uniform", text_mode="raw",
             exclude_task=None, exclude_entity=None):
    """Return list of (image, text) demo pairs retrieved for ``task_name``.

    Priority: exact entity match > highest attribute similarity. Ties within the
    best attribute tier are broken toward the more attack-heavy (kill-like) demo.

    ``text_mode`` (none/raw/abstract) is forwarded to ``visual_icl.load_demos``.
    """
    cat = category_of(task_name)
    entity = entity_of(task_name)
    query_attrs = attrs_of(entity)
    exclude_task = exclude_task or ""
    exclude_entity = exclude_entity or ""

    candidates = []
    for e in bank:
        if e.get("category") != cat:
            continue
        entry_task = e.get("task", "")
        entry_task_colon = entry_task
        if ":" not in entry_task_colon:
            entry_task_colon = f"{category_of(entry_task)}:{entity_of(entry_task)}"
        if entry_task_colon == exclude_task:
            continue
        if e.get("entity") == exclude_entity:
            continue
        candidates.append(e)
    if not candidates:
        return []

    exact = [e for e in candidates if e.get("entity") == entity]
    if exact:
        exact.sort(key=lambda e: -_attack_ratio(e))
        chosen = exact[0]
    else:
        for e in candidates:
            e["_sim"] = attr_similarity(query_attrs, e.get("attrs"))
        candidates.sort(key=lambda e: (-e["_sim"], -_attack_ratio(e)))
        chosen = candidates[0]

    return visual_icl.load_demos(chosen["rollout_dir"], k=k, mode=mode,
                                 text_mode=text_mode)
