"""Target-first harness candidate (M2).

Hypothesis: the baseline puts the specific target LAST (after generic examples).
This candidate leads with the concrete goal ("Current target: ...") so the VLM
grounds its objective before consuming generic demonstrations. Mechanism = goal
anchoring via ordering, keeping the same concrete-example content.
"""

from harness.base import Harness


class TargetFirstHint(Harness):
    name = "target_first_hint"

    def build_context(self, instruction: str, task_name: str, obs=None) -> str:
        if not task_name:
            return instruction

        category = task_name.split(":", 1)[0]
        target = (
            task_name.split(":", 1)[1].replace("_", " ")
            if ":" in task_name
            else task_name.replace("_", " ")
        )

        common = (
            "\n\n## Similar task demonstrations\n"
            "Use these examples as behavioral hints, but still act from the current screenshot only.\n"
            "Always output exactly one valid Minecraft action for the next step.\n"
        )
        hints = {
            "kill_entity": (
                f"Current target: kill the {target}. Prioritize visual search, approach, and attack.\n"
                "Example: Kill a zombie. Scan left/right until visible, center it, approach, attack when close.\n"
                "Example: Kill a skeleton. If not visible, keep turning and moving to search; do not stare at the ground."
            ),
            "mine_block": (
                f"Current target: mine {target}. Prioritize finding the correct block, centering it, and mining.\n"
                "Example: Mine cobblestone. Center the crosshair, move close, hold attack until it breaks.\n"
                "Example: Mine a log or ore. Look around systematically; attack only when the block is centered."
            ),
            "craft_item": (
                f"Current target: craft {target}. Prioritize opening the right GUI and collecting the crafted result.\n"
                "Example: Craft planks. Open inventory, place the ingredient, collect the result.\n"
                "Example: Craft a tool or rail. Use the crafting table GUI, place ingredients, collect the result."
            ),
            "custom": (
                f"Current target: {target}. Prioritize locating, centering, and using the target block.\n"
                "Example: Interact with a campfire. Locate it, approach, center the crosshair, then use/right-click.\n"
                "Example: Interact with a crafting table or beacon. Face it directly and use it; do not only walk around."
            ),
        }

        hint = hints.get(category)
        if not hint:
            return instruction
        return instruction + common + hint


HARNESS = TargetFirstHint()
