"""Generic Stage-3 search harness: source x frame-mode x k in one file.

Decouples the image-ICL demo selection into three orthogonal axes, each read
from an env var so a single candidate file covers the whole 18-arm search space:

    OPENHA_DEMO_SOURCE : prefix    -> load_demos_for_task (exact dir, else
                                      category-prefix fallback)
                         retrieval -> visual_memory.retrieve (attribute match)
    OPENHA_FRAME_MODE  : uniform / state / coverage
    OPENHA_ICL_K       : 1 / 3 / 5

This is the mechanism the Stage-3 proposer mutates; no per-arm file is needed.
"""

import os

from harness.base import Harness
from harness import visual_icl
from harness import visual_memory

POOL_ROOT = os.environ.get(
    "OPENHA_SUCCESS_POOL",
    "/data3/openha_evo/eval/icl_success_pool/00_original_icl_trainonly",
)
BANK_PATH = os.environ.get(
    "OPENHA_MEMORY_BANK",
    "/data3/openha_evo/eval/icl_memory_bank/kill_entity_bank.json",
)


class SearchDemoHarness(Harness):
    name = "search_demo_harness"

    def __init__(self, source="prefix", frame_mode="uniform", k=1,
                 include_text=False, text_level=None,
                 pool_root=None, bank_path=None,
                 exclude_eval_task=False, exclude_eval_entity=False):
        self.source = source
        self.frame_mode = frame_mode
        self.k = int(k)
        if text_level is None:
            text_level = "raw" if include_text else "none"
        self.text_level = text_level  # none / raw / abstract
        self.pool_root = pool_root or POOL_ROOT
        self.bank_path = bank_path or BANK_PATH
        self.exclude_eval_task = bool(exclude_eval_task)
        self.exclude_eval_entity = bool(exclude_eval_entity)
        self._bank = None

    def _load_bank(self):
        if self._bank is None:
            self._bank = (visual_memory.load_bank(self.bank_path)
                          if os.path.exists(self.bank_path) else [])
        return self._bank

    def build_context(self, instruction, task_name, obs=None):
        return instruction

    def build_visual_demos(self, instruction, task_name, obs=None):
        exclude_task = task_name if self.exclude_eval_task else None
        exclude_entity = None
        if self.exclude_eval_entity and ":" in task_name:
            exclude_entity = task_name.split(":", 1)[1]
        if self.source == "retrieval":
            demos = visual_memory.retrieve(
                self._load_bank(), task_name, k=self.k, mode=self.frame_mode,
                text_mode=self.text_level, exclude_task=exclude_task,
                exclude_entity=exclude_entity)
        else:
            demos = visual_icl.load_demos_for_task(
                self.pool_root, task_name, k=self.k, mode=self.frame_mode,
                text_mode=self.text_level, exclude_task=exclude_task,
                exclude_entity=exclude_entity)
        return demos


def _default_text_level():
    lvl = os.environ.get("OPENHA_DEMO_TEXT_LEVEL", "")
    if lvl:
        return lvl
    return "raw" if os.environ.get("OPENHA_ICL_INCLUDE_TEXT", "0") == "1" else "none"


HARNESS = SearchDemoHarness(
    source=os.environ.get("OPENHA_DEMO_SOURCE", "prefix"),
    frame_mode=os.environ.get("OPENHA_FRAME_MODE", "uniform"),
    k=int(os.environ.get("OPENHA_ICL_K", "1")),
    text_level=_default_text_level(),
    exclude_eval_task=os.environ.get("OPENHA_EXCLUDE_EVAL_TASK", "0") == "1",
    exclude_eval_entity=os.environ.get("OPENHA_EXCLUDE_EVAL_ENTITY", "0") == "1",
)
