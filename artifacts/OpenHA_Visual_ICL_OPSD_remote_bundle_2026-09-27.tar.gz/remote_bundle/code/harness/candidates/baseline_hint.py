"""Baseline harness: byte-for-byte equivalent of the current hardcoded ICL hints.

This candidate exists so the M1 A/B comparison runs both arms through the same
`OPENHA_HARNESS_PATH` code path, isolating the hint *text* as the only variable.
"""

from harness.base import Harness


class BaselineHint(Harness):
    name = "baseline_hint"

    def build_context(self, instruction: str, task_name: str, obs=None) -> str:
        if not task_name:
            return instruction

        category = task_name.split(":", 1)[0]
        target = (
            task_name.split(":", 1)[1].replace("_", " ")
            if ":" in task_name
            else task_name.replace("_", " ")
        )

        common = (
            "\n\n## Similar task demonstrations\n"
            "Use these examples as behavioral hints, but still act from the current screenshot only.\n"
            "Always output exactly one valid Minecraft action for the next step.\n"
        )
        hints = {
            "kill_entity": (
                "Example: Kill a zombie. First scan left/right until the mob is visible, then center it, "
                "approach while keeping it in view, and repeatedly attack when close.\n"
                "Example: Kill a skeleton. If the target is not visible, keep turning and moving to search; "
                "do not stay still or only look at the ground.\n"
                f"Current target: kill the {target}. Prioritize visual search, approach, and attack."
            ),
            "mine_block": (
                "Example: Mine cobblestone. Search for the block, center the crosshair on it, move close, "
                "then hold attack until the block breaks.\n"
                "Example: Mine a log or ore. Look around systematically, avoid staring at empty sky, "
                "and keep attacking only when the target block is centered.\n"
                f"Current target: mine {target}. Prioritize finding the correct block, centering it, and mining."
            ),
            "craft_item": (
                "Example: Craft planks. Open inventory, use the available ingredient in the crafting grid, "
                "and collect the result item.\n"
                "Example: Craft a tool or rail. If a crafting table is needed, open/use the table GUI, "
                "place the recipe ingredients, then collect the crafted item.\n"
                f"Current target: craft {target}. Prioritize opening the right GUI and collecting the crafted result."
            ),
            "custom": (
                "Example: Interact with a campfire. Locate the target block, approach it, center the crosshair, "
                "then use/right-click.\n"
                "Example: Interact with a crafting table or beacon. Face the block directly and use it; "
                "do not only walk around after reaching it.\n"
                f"Current target: {target}. Prioritize locating, centering, and using the target block."
            ),
        }

        hint = hints.get(category)
        if not hint:
            return instruction
        return instruction + common + hint


HARNESS = BaselineHint()
