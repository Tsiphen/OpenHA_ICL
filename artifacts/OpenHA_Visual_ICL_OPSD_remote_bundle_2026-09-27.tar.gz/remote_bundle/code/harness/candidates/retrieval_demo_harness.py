"""Attribute-retrieval image-demo ICL harness candidate (Stage 2B probe).

Instead of falling back to the first category demo, this harness retrieves the
demo whose entity attributes (locomotion / hostility / attack style) best match
the query task, using the offline memory bank. Frames are state-anchored.
"""

import os

from harness.base import Harness
from harness import visual_memory

BANK_PATH = os.environ.get(
    "OPENHA_MEMORY_BANK",
    "/data3/openha_evo/eval/icl_memory_bank/kill_entity_bank.json",
)


class RetrievalDemoHarness(Harness):
    name = "retrieval_demo_harness"

    def __init__(self, k=1, include_text=False):
        self.k = int(k)
        self.include_text = bool(include_text)
        self._bank = None

    def _load_bank(self):
        if self._bank is None:
            self._bank = visual_memory.load_bank(BANK_PATH)
        return self._bank

    def build_context(self, instruction, task_name, obs=None):
        return instruction

    def build_visual_demos(self, instruction, task_name, obs=None):
        bank = self._load_bank()
        demos = visual_memory.retrieve(bank, task_name, k=self.k, mode="state")
        if not self.include_text:
            demos = [(img, "") for img, _ in demos]
        return demos


HARNESS = RetrievalDemoHarness(
    k=int(os.environ.get("OPENHA_ICL_K", "1")),
    include_text=os.environ.get("OPENHA_ICL_INCLUDE_TEXT", "0") == "1",
)
