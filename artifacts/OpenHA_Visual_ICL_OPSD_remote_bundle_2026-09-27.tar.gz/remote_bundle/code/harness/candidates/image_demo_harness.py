"""Image-demo ICL harness candidate (probe).

``build_context`` leaves the instruction unchanged (no text ICL);
``build_visual_demos`` injects ``k`` keyframes sampled from a success rollout as
pure-image demonstrations. ``include_text`` optionally appends the per-frame
discrete action label (image-text interleave). ``k`` and ``include_text`` are
controlled by env vars so one candidate file serves the whole 1/3/5 probe.
"""

import os

from harness.base import Harness
from harness import visual_icl

POOL_ROOT = os.environ.get(
    "OPENHA_SUCCESS_POOL",
    "/data3/openha_evo/eval/icl_success_pool/00_original_icl_trainonly",
)


class ImageDemoHarness(Harness):
    name = "image_demo_harness"

    def __init__(self, k=1, include_text=False):
        self.k = int(k)
        self.include_text = bool(include_text)

    def build_context(self, instruction, task_name, obs=None):
        return instruction

    def build_visual_demos(self, instruction, task_name, obs=None):
        demos = visual_icl.load_demos_for_task(POOL_ROOT, task_name, k=self.k)
        if not self.include_text:
            demos = [(img, "") for img, _ in demos]
        return demos


HARNESS = ImageDemoHarness(
    k=int(os.environ.get("OPENHA_ICL_K", "1")),
    include_text=os.environ.get("OPENHA_ICL_INCLUDE_TEXT", "0") == "1",
)
