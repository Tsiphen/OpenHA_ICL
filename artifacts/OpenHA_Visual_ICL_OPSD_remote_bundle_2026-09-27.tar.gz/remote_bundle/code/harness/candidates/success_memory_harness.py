"""Stateful success-memory harness (Meta-Harness reference).

Demonstrates the full three-method interface so the harness is a *learning
program*, not just a static prompt:

  - build_context: injects the baseline concrete hints for the category, plus a
    running "success memory" — a compact, learned summary of what has worked on
    recent rollouts (or, when nothing has worked yet, a fallback encouraging
    systematic search).
  - learn_from_rollout: on success, appends the solved target to memory and
    resets the failure counter; on loss, increments the failure counter.
  - get_state / set_state: JSON-serializable memory, so it persists across
    tasks within one eval process and can be checkpointed across rounds.

This is the candidate that actually exercises Meta-Harness's `learn_from_batch`
analogue; the M1/M2 text candidates are stateless by comparison.
"""

import json

from harness.base import Harness

_COMMON = (
    "\n\n## Similar task demonstrations\n"
    "Use these examples as behavioral hints, but still act from the current screenshot only.\n"
    "Always output exactly one valid Minecraft action for the next step.\n"
)

_HINTS = {
    "kill_entity": (
        "Example: Kill a zombie. First scan left/right until the mob is visible, then center it, "
        "approach while keeping it in view, and repeatedly attack when close.\n"
        "Example: Kill a skeleton. If the target is not visible, keep turning and moving to search; "
        "do not stay still or only look at the ground.\n"
        "Current target: kill the {target}. Prioritize visual search, approach, and attack."
    ),
    "mine_block": (
        "Example: Mine cobblestone. Search for the block, center the crosshair on it, move close, "
        "then hold attack until the block breaks.\n"
        "Example: Mine a log or ore. Look around systematically, avoid staring at empty sky, "
        "and keep attacking only when the target block is centered.\n"
        "Current target: mine {target}. Prioritize finding the correct block, centering it, and mining."
    ),
    "craft_item": (
        "Example: Craft planks. Open inventory, use the available ingredient in the crafting grid, "
        "and collect the result item.\n"
        "Example: Craft a tool or rail. If a crafting table is needed, open/use the table GUI, "
        "place the recipe ingredients, then collect the crafted item.\n"
        "Current target: craft {target}. Prioritize opening the right GUI and collecting the crafted result."
    ),
    "custom": (
        "Example: Interact with a campfire. Locate the target block, approach it, center the crosshair, "
        "then use/right-click.\n"
        "Example: Interact with a crafting table or beacon. Face the block directly and use it; "
        "do not only walk around after reaching it.\n"
        "Current target: {target}. Prioritize locating, centering, and using the target block."
    ),
}


def _category_and_target(task_name):
    if not task_name or ":" not in task_name:
        return None, task_name
    return task_name.split(":", 1)[0], task_name.split(":", 1)[1].replace("_", " ")


class SuccessMemoryHarness(Harness):
    name = "success_memory_harness"

    def __init__(self):
        self._memory = {}

    def build_context(self, instruction: str, task_name: str, obs=None) -> str:
        if not task_name:
            return instruction
        category, target = _category_and_target(task_name)
        base = _HINTS.get(category)
        if not base:
            return instruction

        memory = self._memory.get(category)
        if memory and memory["successes"]:
            recent = ", ".join(memory["successes"][-3:])
            memory_line = (
                f"\nRecent successes on similar tasks: {recent}. Reuse those strategies."
            )
        elif memory:
            memory_line = (
                f"\nNo success yet on {category} tasks after {memory['losses']} attempt(s); "
                "prefer systematic visual search over repeated identical moves."
            )
        else:
            memory_line = ""

        return instruction + _COMMON + base.format(target=target) + memory_line

    def learn_from_rollout(self, task_name: str, success: bool, trajectory=None) -> None:
        if not task_name:
            return
        category, target = _category_and_target(task_name)
        m = self._memory.setdefault(category, {"successes": [], "losses": 0})
        if success:
            if target not in m["successes"]:
                m["successes"].append(target)
            m["losses"] = 0
        else:
            m["losses"] += 1

    def get_state(self) -> str:
        return json.dumps(self._memory, ensure_ascii=False)

    def set_state(self, state: str) -> None:
        self._memory = json.loads(state) if state else {}


HARNESS = SuccessMemoryHarness()
