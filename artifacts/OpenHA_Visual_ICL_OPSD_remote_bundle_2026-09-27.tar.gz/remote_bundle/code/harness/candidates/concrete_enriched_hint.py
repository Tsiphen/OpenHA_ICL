"""Concrete-enriched harness candidate (M2).

Hypothesis: M1 showed the abstract "lessons" format hurt (esp. custom). The
baseline already works via concrete examples, so this candidate KEEPS the
concrete-example mechanism and enriches it: three examples per category plus an
explicit single "Avoid:" anti-pattern line. Mechanism = richer concrete
demonstrations + explicit avoidance, not a format rewrite.
"""

from harness.base import Harness


class ConcreteEnrichedHint(Harness):
    name = "concrete_enriched_hint"

    def build_context(self, instruction: str, task_name: str, obs=None) -> str:
        if not task_name:
            return instruction

        category = task_name.split(":", 1)[0]
        target = (
            task_name.split(":", 1)[1].replace("_", " ")
            if ":" in task_name
            else task_name.replace("_", " ")
        )

        common = (
            "\n\n## Similar task demonstrations\n"
            "Use these examples as behavioral hints, but still act from the current screenshot only.\n"
            "Always output exactly one valid Minecraft action for the next step.\n"
        )
        hints = {
            "kill_entity": (
                "Example: Kill a zombie. Scan left/right until it is visible, center it, approach, attack when close.\n"
                "Example: Kill a skeleton. If it is not visible, keep turning and moving to search; never stare at the ground.\n"
                "Example: Kill a spider. Move toward it while keeping it centered, then attack continuously when in range.\n"
                "Avoid: attacking empty space or standing still while the target is off-screen.\n"
                f"Current target: kill the {target}. Prioritize visual search, approach, and attack."
            ),
            "mine_block": (
                "Example: Mine cobblestone. Center the crosshair on it, move close, then hold attack until it breaks.\n"
                "Example: Mine a log. Look around systematically; only attack when the correct block is centered.\n"
                "Example: Mine an ore. Approach until it is reachable, center it, then hold attack until broken.\n"
                "Avoid: staring at empty sky or attacking while the target block is not centered.\n"
                f"Current target: mine {target}. Prioritize finding the correct block, centering it, and mining."
            ),
            "craft_item": (
                "Example: Craft planks. Open inventory, place the ingredient in the crafting grid, collect the result.\n"
                "Example: Craft a tool. Use the crafting table GUI, place the recipe ingredients, collect the result.\n"
                "Example: Craft a rail. Open the right GUI, place ingredients in the correct slots, collect the result.\n"
                "Avoid: crafting without collecting the result into inventory.\n"
                f"Current target: craft {target}. Prioritize opening the right GUI and collecting the crafted result."
            ),
            "custom": (
                "Example: Interact with a campfire. Locate it, approach, center the crosshair, then use/right-click.\n"
                "Example: Interact with a crafting table. Face it directly and use it; do not walk around after reaching it.\n"
                "Example: Interact with a furnace. Approach until close, center the block, then use/right-click.\n"
                "Avoid: only walking around after reaching the block without using it.\n"
                f"Current target: {target}. Prioritize locating, centering, and using the target block."
            ),
        }

        hint = hints.get(category)
        if not hint:
            return instruction
        return instruction + common + hint


HARNESS = ConcreteEnrichedHint()
