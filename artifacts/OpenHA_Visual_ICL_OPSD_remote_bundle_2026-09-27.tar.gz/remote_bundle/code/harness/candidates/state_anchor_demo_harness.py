"""State-anchored image-demo ICL harness candidate (Stage 2A probe).

Same demo *source* as the Stage-1 image harness (exact task dir, else category
prefix fallback), but frames are selected by state/anchor importance instead of
uniform spacing. ``k`` and ``include_text`` are controlled by env vars.
"""

import os

from harness.base import Harness
from harness import visual_icl

POOL_ROOT = os.environ.get(
    "OPENHA_SUCCESS_POOL",
    "/data3/openha_evo/eval/icl_success_pool/00_original_icl_trainonly",
)


class StateAnchorDemoHarness(Harness):
    name = "state_anchor_demo_harness"

    def __init__(self, k=1, include_text=False):
        self.k = int(k)
        self.include_text = bool(include_text)

    def build_context(self, instruction, task_name, obs=None):
        return instruction

    def build_visual_demos(self, instruction, task_name, obs=None):
        demos = visual_icl.load_demos_for_task(
            POOL_ROOT, task_name, k=self.k, mode="state")
        if not self.include_text:
            demos = [(img, "") for img, _ in demos]
        return demos


HARNESS = StateAnchorDemoHarness(
    k=int(os.environ.get("OPENHA_ICL_K", "1")),
    include_text=os.environ.get("OPENHA_ICL_INCLUDE_TEXT", "0") == "1",
)
