"""Lesson-summary harness candidate (M1).

Hypothesis: the baseline hints narrate a generic example ("Kill a zombie ..."),
but the agent already knows *what* to do. The bottleneck is *what it does wrong*
on repeated failures. Encoding those anti-patterns as explicit "Lessons from
prior attempts" should reduce the most common failure modes (staring at ground /
sky, attacking before centering, crafting without collecting the result).

This is a mechanism change (structured lesson format + failure-mode focus), not
a parameter tweak.
"""

from harness.base import Harness


class LessonSummaryHint(Harness):
    name = "lesson_summary_hint"

    def build_context(self, instruction: str, task_name: str, obs=None) -> str:
        if not task_name:
            return instruction

        category = task_name.split(":", 1)[0]
        target = (
            task_name.split(":", 1)[1].replace("_", " ")
            if ":" in task_name
            else task_name.replace("_", " ")
        )

        header = (
            "\n\n## Task demonstrations and lessons\n"
            "Act only from the current screenshot. Output exactly one valid Minecraft action per step.\n"
        )
        lessons = {
            "kill_entity": (
                "Lessons from prior attempts:\n"
                "- Do not stare at the ground or stand still; keep turning and moving to search for the target.\n"
                "- Only attack when the target is centered in view and close; attacking empty space wastes time.\n"
                "- Center the target, approach while keeping it visible, then attack repeatedly.\n"
                f"Current target: kill the {target}."
            ),
            "mine_block": (
                "Lessons from prior attempts:\n"
                "- Do not stare at empty sky or random terrain; scan systematically for the target block.\n"
                "- Only hold attack when the correct block is centered in the crosshair.\n"
                "- Move close enough that the block is reachable before mining.\n"
                f"Current target: mine {target}."
            ),
            "craft_item": (
                "Lessons from prior attempts:\n"
                "- Open the correct GUI (inventory or crafting table) before placing ingredients.\n"
                "- Place the exact recipe ingredients in the crafting grid in the right slots.\n"
                "- Always collect the crafted result into inventory; crafting without collecting fails.\n"
                f"Current target: craft {target}."
            ),
            "custom": (
                "Lessons from prior attempts:\n"
                "- Locate the target block first, then approach and face it directly.\n"
                "- After reaching the block, use/right-click it; do not keep walking around.\n"
                "- Center the crosshair on the block before interacting.\n"
                f"Current target: {target}."
            ),
        }

        hint = lessons.get(category)
        if not hint:
            return instruction
        return instruction + header + hint


HARNESS = LessonSummaryHint()
