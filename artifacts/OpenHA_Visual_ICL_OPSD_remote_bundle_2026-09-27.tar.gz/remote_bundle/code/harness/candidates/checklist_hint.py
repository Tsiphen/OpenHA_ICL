"""Checklist harness candidate (M2).

Hypothesis: for procedural tasks, an explicit numbered step checklist
decomposes the skill better than a narrative example. This candidate replaces
narrative examples with a numbered plan (with concrete cues in each step), a
mechanism distinct from the baseline's example-narrative format.
"""

from harness.base import Harness


class ChecklistHint(Harness):
    name = "checklist_hint"

    def build_context(self, instruction: str, task_name: str, obs=None) -> str:
        if not task_name:
            return instruction

        category = task_name.split(":", 1)[0]
        target = (
            task_name.split(":", 1)[1].replace("_", " ")
            if ":" in task_name
            else task_name.replace("_", " ")
        )

        common = (
            "\n\n## Task procedure\n"
            "Follow these steps in order, acting only from the current screenshot.\n"
            "Always output exactly one valid Minecraft action for the next step.\n"
        )
        hints = {
            "kill_entity": (
                "1. Turn and move to search until the target is visible.\n"
                "2. Center the target in the crosshair.\n"
                "3. Approach while keeping the target in view.\n"
                "4. Attack repeatedly only when the target is close and centered.\n"
                f"Current target: kill the {target}."
            ),
            "mine_block": (
                "1. Look around systematically to find the target block.\n"
                "2. Center the crosshair on the correct block.\n"
                "3. Move close enough to reach it.\n"
                "4. Hold attack until the block breaks.\n"
                f"Current target: mine {target}."
            ),
            "craft_item": (
                "1. Open the correct GUI (inventory or crafting table).\n"
                "2. Place the required ingredients in the correct slots.\n"
                "3. Collect the crafted result into inventory.\n"
                f"Current target: craft {target}."
            ),
            "custom": (
                "1. Locate the target block.\n"
                "2. Approach and face it directly.\n"
                "3. Center the crosshair on it.\n"
                "4. Use/right-click the block.\n"
                f"Current target: {target}."
            ),
        }

        hint = hints.get(category)
        if not hint:
            return instruction
        return instruction + common + hint


HARNESS = ChecklistHint()
