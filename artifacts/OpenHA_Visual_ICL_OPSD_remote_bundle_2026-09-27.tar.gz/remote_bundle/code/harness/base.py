"""Harness ABC for the OpenHA harness-evolution loop (Meta-Harness aligned).

A "harness" is the *stateful* code that wraps a frozen base model and decides
what to store, retrieve, and show while the model works. This mirrors the
Meta-Harness `MemorySystem` interface (`predict` / `learn_from_batch` /
`get_state` / `set_state`) but specialised for one VLA rollout.

Three responsibilities:

    1. build_context(instruction, task_name, obs=None) -> str
       What to inject into the VLM instruction for the current task
       (retrieve + present). Called at each episode `reset()`.

    2. learn_from_rollout(task_name, success, trajectory=None) -> None
       Update internal memory from one finished rollout (learn from feedback).
       Called once per episode, after success/loss is known.

    3. get_state() -> str / set_state(state) -> None
       Serialize / restore memory so a harness can persist across tasks
       (in-process) and be checkpointed across rounds.

The deprecated `build_icl_instruction` alias is kept so pre-existing candidates
and the original server hook keep working while migrating.

Conventions for a candidate module (one file under `harness/candidates/`):

    from harness.base import Harness

    class CandidateFoo(Harness):
        name = "candidate_foo"

        def build_context(self, instruction, task_name, obs=None):
            ...  # return the full final instruction string

        def learn_from_rollout(self, task_name, success, trajectory=None):
            ...  # optional: update memory

    HARNESS = CandidateFoo()
"""

from abc import ABC, abstractmethod


class Harness(ABC):
    name: str = "base"

    @abstractmethod
    def build_context(self, instruction: str, task_name: str, obs=None) -> str:
        """Return the full instruction (base + injected context) for one task."""
        raise NotImplementedError

    def build_visual_demos(self, instruction: str, task_name: str, obs=None) -> list:
        """Return a list of ``(image, text)`` demo pairs for in-context injection.

        ``image`` is a numpy RGB array (or anything ``create_image_input``
        accepts); ``text`` is an optional short action label. Empty by default
        (text-only / stateless harnesses).
        """
        return []

    def learn_from_rollout(self, task_name: str, success: bool, trajectory=None) -> None:
        """Update internal memory from one finished rollout. Stateless by default."""
        return None

    def get_state(self) -> str:
        """Serialize internal memory. Empty by default (stateless)."""
        return ""

    def set_state(self, state: str) -> None:
        """Restore internal memory from a serialized state. No-op by default."""
        return None

    # Deprecated alias: keeps the old server hook and any un-migrated candidate
    # working while the interface moves to build_context.
    def build_icl_instruction(self, instruction: str, task_name: str) -> str:
        return self.build_context(instruction, task_name)
