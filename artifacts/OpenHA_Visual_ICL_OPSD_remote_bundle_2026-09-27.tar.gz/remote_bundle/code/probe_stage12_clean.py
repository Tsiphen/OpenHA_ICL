"""Leakage-safe Stage 1/2 runner for OpenHA visual ICL.

Stage 1 locks clean baselines and sanity controls:
  - no ICL
  - original OpenHA text ICL
  - text ICL with history-window truncation only

Stage 2 runs the core image-ICL sweep on bare OpenHA:
  - source: prefix / retrieval
  - frame: uniform / state
  - k: 1 / 3 / 5

All demo sources are train-only and the default Stage 2 protocol excludes the
current eval task and same entity from demo selection.
"""

import argparse
import collections
import json
import os
import subprocess
import sys
import time

import config
import experiment_guard
import metrics
import sub_vla
from harness import visual_memory
from harness.candidates.search_demo_harness import SearchDemoHarness


OUT_ROOT = os.path.join(config.EVO_ROOT, "probe_stage12_clean")
SEARCH_HARNESS = os.path.join(
    config.EVO_ROOT, "harness", "candidates", "search_demo_harness.py")
POOL_ROOT = os.path.join(
    config.EVO_ROOT, "eval", "icl_success_pool", "00_original_icl_trainonly")
MEMORY_BANK = os.path.join(
    config.EVO_ROOT, "eval", "icl_memory_bank", "kill_entity_bank.json")
GPU_MIN_FREE_MB = 25000


def stage1_arms():
    return [
        {
            "stage": "stage1",
            "name": "baseline_no_icl",
            "config": "openha_eager",
            "extra_env": {},
        },
        {
            "stage": "stage1",
            "name": "baseline_text_icl",
            "config": "openha_eager_icl",
            "extra_env": {"OPENHA_AGENT_MODULE": "streaming_openha_original_harness"},
        },
        {
            "stage": "stage1",
            "name": "history_trunc_k1",
            "config": "openha_eager_icl",
            "extra_env": {
                "OPENHA_AGENT_MODULE": "streaming_openha_original_harness",
                "OPENHA_HISTORY_TRUNC_K": "1",
            },
        },
        {
            "stage": "stage1",
            "name": "history_trunc_k3",
            "config": "openha_eager_icl",
            "extra_env": {
                "OPENHA_AGENT_MODULE": "streaming_openha_original_harness",
                "OPENHA_HISTORY_TRUNC_K": "3",
            },
        },
        {
            "stage": "stage1",
            "name": "history_trunc_k5",
            "config": "openha_eager_icl",
            "extra_env": {
                "OPENHA_AGENT_MODULE": "streaming_openha_original_harness",
                "OPENHA_HISTORY_TRUNC_K": "5",
            },
        },
    ]


def stage2_arms():
    arms = []
    for source in ("prefix", "retrieval"):
        for frame_mode in ("uniform", "state"):
            for k in (1, 3, 5):
                arms.append({
                    "stage": "stage2",
                    "name": f"{source}_{frame_mode}_{k}",
                    "config": "openha_eager_icl",
                    "source": source,
                    "frame_mode": frame_mode,
                    "k": k,
                })
    return arms


def build_kill_subset(limit=None):
    tasks = metrics.read_task_list(config.TRAIN_TASKS)
    subset = [t for t in tasks if config.category(t) == "kill_entity"]
    if limit is not None:
        subset = subset[:limit]
    os.makedirs(OUT_ROOT, exist_ok=True)
    suffix = f"_{limit}" if limit is not None else ""
    path = os.path.join(OUT_ROOT, f"kill_entity_subset{suffix}.txt")
    with open(path, "w") as f:
        f.write("\n".join(subset) + ("\n" if subset else ""))
    return path, subset


def ensure_memory_bank():
    rebuild = not os.path.exists(MEMORY_BANK)
    if not rebuild:
        try:
            experiment_guard.assert_bank_has_known_splits(MEMORY_BANK)
            return
        except RuntimeError:
            rebuild = True
    if rebuild:
        entries = visual_memory.build_bank(
            POOL_ROOT, MEMORY_BANK, categories=["kill_entity"],
            train_tasks_path=config.TRAIN_TASKS, test_tasks_path=config.TEST_TASKS)
        print(f"[stage12] built memory bank: {len(entries)} -> {MEMORY_BANK}", flush=True)


def stage2_env(arm, exclude_eval_task=True, exclude_eval_entity=True):
    env = {
        "OPENHA_HARNESS_PATH": SEARCH_HARNESS,
        "OPENHA_AGENT_MODULE": "streaming_openha_original_harness",
        "OPENHA_DEMO_SOURCE": arm["source"],
        "OPENHA_FRAME_MODE": arm["frame_mode"],
        "OPENHA_ICL_K": str(arm["k"]),
        "OPENHA_DEMO_TEXT_LEVEL": "none",
        "OPENHA_SUCCESS_POOL": POOL_ROOT,
        "OPENHA_MEMORY_BANK": MEMORY_BANK,
    }
    if exclude_eval_task:
        env["OPENHA_EXCLUDE_EVAL_TASK"] = "1"
    if exclude_eval_entity:
        env["OPENHA_EXCLUDE_EVAL_ENTITY"] = "1"
    return env


def arm_extra_env(arm, exclude_eval_task=True, exclude_eval_entity=True):
    if arm["stage"] == "stage2":
        return stage2_env(arm, exclude_eval_task, exclude_eval_entity)
    return dict(arm.get("extra_env") or {})


def offline_validate_stage2(subset, arms, exclude_eval_task=True, exclude_eval_entity=True):
    os.environ["OPENHA_SUCCESS_POOL"] = POOL_ROOT
    os.environ["OPENHA_MEMORY_BANK"] = MEMORY_BANK
    report = {}
    for arm in arms:
        if arm["stage"] != "stage2":
            continue
        harness = SearchDemoHarness(
            source=arm["source"],
            frame_mode=arm["frame_mode"],
            k=arm["k"],
            text_level="none",
            exclude_eval_task=exclude_eval_task,
            exclude_eval_entity=exclude_eval_entity,
        )
        per_task = {}
        empty = 0
        short = 0
        for task in subset:
            demos = harness.build_visual_demos("", task)
            n = len(demos)
            per_task[task] = n
            if n == 0:
                empty += 1
            elif n < arm["k"]:
                short += 1
        report[arm["name"]] = {
            "tasks": len(subset),
            "empty": empty,
            "short_of_k": short,
            "avg_demos": round(sum(per_task.values()) / max(1, len(subset)), 3),
            "sample": {t: per_task[t] for t in subset[:5]},
        }
        print(
            f"[offline] {arm['name']}: empty={empty}/{len(subset)} "
            f"short={short} avg={report[arm['name']]['avg_demos']}",
            flush=True,
        )
    return report


def parse_csv(spec):
    return [x.strip() for x in spec.split(",") if x.strip()]


def parse_gpus(spec):
    return [int(x) for x in parse_csv(spec)]


def parse_seeds(spec):
    return [int(x) for x in parse_csv(spec)]


def pick_free_gpus(n, min_free_mb=GPU_MIN_FREE_MB):
    out = subprocess.check_output(
        [
            "nvidia-smi",
            "--query-gpu=index,memory.used,memory.total",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )
    gpus = []
    for line in out.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 3:
            idx, used, total = int(parts[0]), int(parts[1]), int(parts[2])
            gpus.append((idx, total - used))
    gpus.sort(key=lambda x: -x[1])
    chosen = [idx for idx, free in gpus if free >= min_free_mb][:n]
    if len(chosen) < n:
        raise RuntimeError(f"Need {n} free GPUs, found {len(chosen)}")
    return chosen


def select_arms(stage, arm_names):
    arms = []
    if stage in ("stage1", "both"):
        arms.extend(stage1_arms())
    if stage in ("stage2", "both"):
        arms.extend(stage2_arms())
    if arm_names:
        want = set(arm_names)
        arms = [a for a in arms if a["name"] in want or f"{a['stage']}:{a['name']}" in want]
    return arms


def record_path_for(seed, arm):
    return os.path.join(OUT_ROOT, f"seed{seed}", arm["stage"], arm["name"])


def launch_arm(arm, subset_path, gpu, seed, max_steps,
               exclude_eval_task=True, exclude_eval_entity=True):
    record_path = record_path_for(seed, arm)
    os.makedirs(record_path, exist_ok=True)
    log_name = f"probe_stage12_seed{seed}_{arm['stage']}_{arm['name']}.log"
    log_file = os.path.join(config.LOGS_DIR, log_name)
    proc = sub_vla.run_eval(
        arm["config"],
        subset_path,
        record_path,
        gpu,
        max_steps=max_steps,
        log_file=log_file,
        lora_adapter_path=None,
        bench_seed=seed,
        extra_env=arm_extra_env(arm, exclude_eval_task, exclude_eval_entity),
    )
    print(
        f"[stage12] launched seed={seed} {arm['stage']}:{arm['name']} "
        f"config={arm['config']} gpu={gpu} pid={proc.pid}",
        flush=True,
    )
    return record_path, proc


def collect_arm(arm, seed, record_path, proc, subset_path):
    rc = proc.wait()
    result_dir = os.path.join(record_path, arm["config"])
    result = metrics.compute_metrics(result_dir, subset_path) if rc == 0 else None
    asr = result["overall"]["asr"] if result else None
    entry = {
        "stage": arm["stage"],
        "arm": arm["name"],
        "config": arm["config"],
        "seed": seed,
        "rc": rc,
        "asr": asr,
        "overall": result["overall"] if result else None,
        "by_category": result["by_category"] if result else None,
        "missing": len(result["missing"]) if result else None,
        "record_path": record_path,
    }
    print(
        f"[stage12] finished seed={seed} {arm['stage']}:{arm['name']} "
        f"rc={rc} asr={asr}",
        flush=True,
    )
    return entry


def run_queue(arms, seeds, subset_path, gpus, max_steps,
              exclude_eval_task=True, exclude_eval_entity=True):
    pending = collections.deque((seed, arm) for seed in seeds for arm in arms)
    running = {}
    summary = {}

    for gpu in gpus:
        if not pending:
            break
        seed, arm = pending.popleft()
        record_path, proc = launch_arm(
            arm, subset_path, gpu, seed, max_steps,
            exclude_eval_task, exclude_eval_entity)
        running[gpu] = (seed, arm, record_path, proc)

    while running:
        finished_gpu = None
        for gpu, (seed, arm, record_path, proc) in running.items():
            if proc.poll() is not None:
                key = f"seed{seed}/{arm['stage']}/{arm['name']}"
                summary[key] = collect_arm(arm, seed, record_path, proc, subset_path)
                finished_gpu = gpu
                break
        if finished_gpu is None:
            time.sleep(5)
            continue
        del running[finished_gpu]
        if pending:
            seed, arm = pending.popleft()
            record_path, proc = launch_arm(
                arm, subset_path, finished_gpu, seed, max_steps,
                exclude_eval_task, exclude_eval_entity)
            running[finished_gpu] = (seed, arm, record_path, proc)

    return summary


def write_summary(summary, stage, seeds):
    out_path = os.path.join(OUT_ROOT, f"{stage}_summary_seed{'-'.join(map(str, seeds))}.json")
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    latest = os.path.join(OUT_ROOT, "latest_summary.json")
    with open(latest, "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"[stage12] summary -> {out_path}", flush=True)
    print(f"[stage12] latest summary -> {latest}", flush=True)
    return out_path


def main():
    parser = argparse.ArgumentParser(description="Stage 1/2 clean OpenHA ICL runner")
    parser.add_argument("--stage", choices=("stage1", "stage2", "both"), default="both")
    parser.add_argument("--arms", default="", help="comma-separated arm names")
    parser.add_argument("--seeds", default=str(config.BENCH_SEED), help="comma-separated seeds")
    parser.add_argument("--gpus", default="", help="comma-separated GPU ids")
    parser.add_argument("--max-steps", type=int, default=config.DEFAULT_MAX_STEPS)
    parser.add_argument("--subset-limit", type=int, default=None)
    parser.add_argument("--offline", action="store_true")
    parser.add_argument("--exclude-eval-task", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--exclude-eval-entity", action=argparse.BooleanOptionalAction, default=True)
    args = parser.parse_args()

    os.makedirs(OUT_ROOT, exist_ok=True)
    ensure_memory_bank()
    guard = experiment_guard.assert_no_test_leak(POOL_ROOT, MEMORY_BANK)
    subset_path, subset = build_kill_subset(args.subset_limit)
    arms = select_arms(args.stage, parse_csv(args.arms))
    seeds = parse_seeds(args.seeds)
    if not arms:
        print("ERROR: no arms selected", file=sys.stderr)
        sys.exit(2)
    if not seeds:
        print("ERROR: no seeds selected", file=sys.stderr)
        sys.exit(2)

    offline_report = offline_validate_stage2(
        subset, arms, args.exclude_eval_task, args.exclude_eval_entity)
    offline_path = os.path.join(OUT_ROOT, "offline_stage2_validation.json")
    with open(offline_path, "w") as f:
        json.dump(offline_report, f, indent=2, ensure_ascii=False)

    config_path, snapshot = experiment_guard.write_run_config_snapshot(
        OUT_ROOT,
        stage=f"stage12_clean_{args.stage}",
        success_pool=POOL_ROOT,
        memory_bank=MEMORY_BANK,
        task_list=subset_path,
        subset_limit=args.subset_limit,
        arms=[f"{a['stage']}:{a['name']}" for a in arms],
        seeds=seeds,
        max_steps=args.max_steps,
        exclude_eval_task=args.exclude_eval_task,
        exclude_eval_entity=args.exclude_eval_entity,
        offline_stage2_validation=offline_path,
        guard=guard,
    )
    print(f"[stage12] guard ok; run config -> {config_path}", flush=True)
    print(f"[stage12] run config sha256 = {snapshot['config_sha256']}", flush=True)
    print(f"[stage12] kill_entity subset = {len(subset)} tasks -> {subset_path}", flush=True)
    arm_labels = [f"{a['stage']}:{a['name']}" for a in arms]
    print(f"[stage12] arms = {arm_labels}", flush=True)

    if args.offline:
        print(f"[stage12] offline validation -> {offline_path}", flush=True)
        return

    gpus = parse_gpus(args.gpus) if args.gpus else pick_free_gpus(min(len(arms), 2))
    print(f"[stage12] GPUs = {gpus}", flush=True)
    summary = run_queue(
        arms,
        seeds,
        subset_path,
        gpus,
        args.max_steps,
        args.exclude_eval_task,
        args.exclude_eval_entity,
    )
    write_summary(summary, args.stage, seeds)
    print(json.dumps(summary, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
