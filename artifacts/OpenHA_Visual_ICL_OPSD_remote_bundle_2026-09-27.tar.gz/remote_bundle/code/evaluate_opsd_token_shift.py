#!/usr/bin/env python3
"""Measure teacher/student token NLL and KL on task-disjoint eval prefixes."""

from __future__ import annotations

import argparse
import copy
import gc
import json
from pathlib import Path

import torch
import torch.nn.functional as F
from peft import PeftModel
from qwen_vl_utils import process_vision_info
from transformers import AutoProcessor, Qwen2VLForConditionalGeneration


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).open(encoding="utf-8") if line.strip()]


def encode(processor, messages):
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=False)
    images, videos = process_vision_info(messages)
    x = processor(text=[text], images=images, videos=videos,
                  return_tensors="pt", padding=True)
    marker = processor.tokenizer("<|im_start|>assistant\n", add_special_tokens=False).input_ids
    ids = x["input_ids"][0].tolist()
    start = next(i for i in range(len(ids) - len(marker) + 1)
                 if ids[i:i + len(marker)] == marker) + len(marker)
    return x, start


def move(x, device):
    return {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in x.items()}


def score(model, processor, messages):
    x, start = encode(processor, messages)
    device = next(model.parameters()).device
    with torch.no_grad():
        logits = model(**move(x, device), use_cache=False).logits[0]
    end = int(x["attention_mask"][0].sum().item())
    pred = logits[start - 1:end - 1].float()
    ids = x["input_ids"][0, start:end].to(device)
    logp = F.log_softmax(pred, dim=-1)
    token_nll = -logp.gather(-1, ids[:, None]).squeeze(-1)
    return pred.cpu(), ids.cpu(), float(token_nll.mean().item())


def load_model(path, adapter):
    base = Qwen2VLForConditionalGeneration.from_pretrained(
        path, torch_dtype=torch.float16, device_map="auto",
        trust_remote_code=True, attn_implementation="sdpa",
    )
    return PeftModel.from_pretrained(base, adapter) if adapter else base


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-path", required=True)
    ap.add_argument("--eval-jsonl", required=True)
    ap.add_argument("--teacher-jsonl", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--opsd1")
    ap.add_argument("--ordinary")
    ap.add_argument("--opsd2")
    args = ap.parse_args()
    eval_rows = read_jsonl(args.eval_jsonl)
    smoke = {r["id"]: r for r in read_jsonl(args.teacher_jsonl)}
    variants = {
        "frozen_no_demo": None,
        "opsd1_pseudo_label": args.opsd1,
        "ordinary_self_imitation": args.ordinary,
        "opsd2_token_kl": args.opsd2,
    }
    teacher_processor = AutoProcessor.from_pretrained(args.model_path, trust_remote_code=True)
    teacher = load_model(args.model_path, None)
    teacher.eval()
    teacher_device = next(teacher.parameters()).device
    teacher_cache = {}
    for row in eval_rows:
        target = row["teacher_target"]
        messages = copy.deepcopy(smoke[row["id"]]["messages"])
        messages.append({"role": "assistant", "content": [{"type": "text", "text": target}]})
        logits, ids, nll = score(teacher, teacher_processor, messages)
        teacher_cache[row["id"]] = {"logits": logits, "ids": ids, "nll": nll}
    del teacher
    gc.collect()
    torch.cuda.empty_cache()

    all_results = []
    for name, adapter in variants.items():
        processor = AutoProcessor.from_pretrained(args.model_path, trust_remote_code=True)
        model = load_model(args.model_path, adapter)
        model.eval()
        for row in eval_rows:
            student_logits, student_ids, nll = score(
                model, processor, copy.deepcopy(row["messages"])
            )
            t = teacher_cache[row["id"]]
            n = min(len(t["ids"]), len(student_ids), t["logits"].shape[0], student_logits.shape[0])
            teacher_logits = t["logits"][:n].float()
            s = student_logits[:n].float()
            kl = F.kl_div(
                F.log_softmax(s, dim=-1),
                F.softmax(teacher_logits, dim=-1),
                reduction="batchmean",
            ).item()
            all_results.append({
                "variant": name,
                "id": row["id"],
                "task": row["task"],
                "phase": row["phase"],
                "teacher_nll": t["nll"],
                "student_nll": nll,
                "student_minus_teacher_nll": nll - t["nll"],
                "teacher_to_student_kl": kl,
                "aligned_tokens": n,
            })
        del model, processor
        gc.collect()
        torch.cuda.empty_cache()
    Path(args.output).write_text(json.dumps({
        "stage": "held-out-token-shift",
        "eval_rows": len(eval_rows),
        "results": all_results,
        "note": "Teacher has success demo; all students are evaluated without demo.",
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
