# 精细选帧的 OpenHA 图片 ICL（项目完整说明）

> 本项目在原始 OpenHA（冻结 Qwen2-VL-7B + LoRA 行为克隆 SFT）的**文本 ICL** 基础上，新增一条**图片 ICL 通道**，并研究「如何从一个成功 rollout 里精细选出 k 帧 demo」最有效（均匀采样 / 状态锚帧 / 属性检索）。
>
> **2026-09-06 范围锁定：论文主线定义为
> `Demonstration-conditioned autoregressive next-action VLA`。核心对象是
> OpenHA/CrossHA、OpenVLA 和 ECoT；π0 flow matching、π0-FAST action
> chunk 与 Octo action head 只作为范式边界，不进入主验证链。**

---

## 一、先建立坐标系：OpenHA 每一步的输入长什么样

OpenHA 的 VLM 每步吃一个 `messages` 序列（`openha.py:gen_response`，`openha.py:300-340`）：

```
[user: system_message + instruction + 第一帧历史图]
[assistant: 第1步动作文本]
[user: 第2帧历史图]
[assistant: 第2步动作文本]
   ...（滚动历史，最多 15 帧）
[user: 当前观测图]          ← 最后这个才是「现在看到的东西」
→ VLM 生成 → 当前动作
```

关键参数（`run_streaming_eval_evo.py` 的 `openha_eager_sft_v4_icl` 配置）：

- `maximum_history_length = 15` → 历史最多保留 15 帧
- `temperature = 0.8`，`max_tokens = 1024`（但内部被改写）
- 内部 `max_tokens = max(1024, 400*(15+1)) = 6400`（`openha.py:128`）
- 内部 `limit_mm_per_prompt_image = 15+1 = 16`（`openha.py:131`）——**这是「每个 prompt 最多 16 张图」的硬上限**

所以原始输入 = `1 张当前图 + 最多 15 张历史图 = 最多 16 张图`，刚好顶到 `limit_mm_per_prompt_image=16`。

---

## 二、「选帧/插帧」和这个输入的关系

**注意：我们说的「选帧」不是插进历史里，而是选「ICL demo 帧」。** 两条帧流是分开的：

1. **历史帧**：来自当前 episode 自己之前的观测，episode 内每步增长。
2. **demo 帧**：来自**成功池里某个成功 rollout**，在 `reset()` 时一次性选好，整个 episode 固定不变。

选帧发生在 `build_visual_demos`（`harness/candidates/*.py`），它从一个成功 rollout 里用 uniform/state/retrieval 挑出 k 帧，作为 `(image, action_text)` demo 对。然后 `gen_response` 把这些 demo **前置**到历史之前（`patch_harness_hook.py:155-165`）：

```
[user: system_message + instruction + demo_0 图]
[assistant: demo_0 动作文本]
[user: demo_1 图]
[assistant: demo_1 动作文本]
   ...（k 个 demo）
[user: 历史第1帧] ... [assistant: 历史]
[user: 当前观测图]
```

**为什么会有「历史位移」**：因为加了 k 张 demo 图后，总图数变成 `k + 15 + 1 = k+16`，超过 `limit_mm_per_prompt_image=16`。所以把历史从 15 压到 `15-k`（`patch_harness_hook.py:167-170`），总图数回到 `k + (15-k) + 1 = 16`，刚好不爆。

一句话：**「选帧」决定 demo 用成功 rollout 的哪 k 帧；这些 demo 帧在 reset 时「选好并缓存」，之后每一步 `gen_response` 都把它们前置在历史之前；历史相应缩短以维持 16 图上限。**

---

## 三、和「Loop 自进化」的关系

它们是**生产方 vs 消费方**的关系，不是一回事：

**Loop（`evo_loop.py`）= 自进化闭环**，会训练、会更新模型：
```
round0: 冻结 round0 LoRA adapter → TEST_V2 打 baseline
round r≥1:
  1. 当前 adapter 在 TRAIN_V2 上跑 → 收集 success rollout
  2. 把 success rollout 复制进持久成功池 (icl_success_pool)
  3. 用成功池构建 parser-constrained SFT 数据
  4. 训练 LoRA adapter
  5. 新 adapter 在 TEST_V2 上评 ASR
```

**ICL probe（`probe_image_icl.py` / `probe_stage2.py`）= 纯诊断**，不训练、不更新模型，冻结 round0 adapter，测「不同 ICL 注入配方」哪个好。

它俩共享两样东西：
1. **成功池 `icl_success_pool`**——Loop 负责「生产」成功 rollout，probe 负责「读」它们当 demo 来源。
2. **round0 LoRA adapter**——Loop 的 round0 基线，probe 冻结它。

所以：**Loop 是「攒数据 + 训练模型」；ICL probe 是「在同一套冻结模型上，测怎么往 context 里塞 demo 最有效」。** 选帧/检索都是 probe 这边（inference 期）的事，不碰 Loop 的训练。

---

## 四、我们是基于哪个 baseline 改 ICL 的

**Baseline = 原始 OpenHA 的「文本 ICL」**，即 `openha_eager_sft_v4_icl` 配置里的 `_build_icl_instruction`（`streaming_openha_original.py:175-220`）。

它做的是：`icl_enabled=True` 时，在 reset 时按类别往 instruction 后面拼一段**硬编码文本提示**：

```python
hints = {
  "kill_entity": "Example: Kill a zombie. First scan ... ",
  "mine_block": "Example: Mine cobblestone. ... ",
  "craft_item": "Example: Craft planks. ... ",
  "custom":     "Example: Interact with a campfire. ... ",
}
return instruction + common + hint
```

我们就是在这个文本 ICL 基础上，**新增了一条图片 ICL 通道**：
- 加 `build_visual_demos()`（返回 `(image, text)` demo 对）
- 加 `gen_response` 覆盖，把 demo 图片前置（`patch_harness_hook.py`）

**关键结论：原始 baseline 只有文本 hint，没有任何图片 demo，因此也根本不存在「选帧」。** 选帧（均匀/状态锚/检索）是我们为图片 ICL 新造的东西，不是从 baseline 继承的。

---

## 五、「均匀采样」是在 ICL-OpenHA 基础上改的吗？有 SFT 版本吗

分两问：

**（1）均匀采样不是 baseline 自带的。** 它是 Stage 1 图片 ICL 里，我们给「从成功 rollout 挑 k 帧」设计的第一个（最朴素的）策略。原始 ICL-OpenHA 是纯文本，没有这个环节。

**（2）有 SFT 版本。** 我们的模型不是裸 Qwen2-VL，而是：

```
冻结 Qwen2-VL-7B  +  LoRA SFT adapter（行为克隆）
```

- 这个 adapter 来自 **parser-constrained 行为克隆 SFT**：从成功 rollout 里取 `(图像 → 离散动作)` 对，配上干净指令 `instruction_for_task`（`build_openha_lora_sft_v3_data_evo.py:67-78`）训练 LoRA。
- `sft_v4` 和 `sft_v4_icl` 是**同一套 v4 SFT**，唯一区别是 eval 时 `icl_enabled` 开不开——开了就在推理期拼文本 hint。注意有两个 v4 adapter 工件：
  - 原始 `task_adaptive_v4/final_adapter`（Jul 30，OpenHA 仓库自带）
  - 本项目重训的 `adapters/round0/final_adapter/final_adapter`（Aug 20，checkpoint-120/150）——**probe/loop 实际用这个**
- **SFT 训练数据里并没有 ICL 文本 hint**（`instruction_for_task` 是干净指令），文本 ICL 是**纯推理期**注入的。

所以我们整条链路是：

> **冻结 Qwen2-VL + LoRA(SFT 行为克隆) + 推理期注入**——原始 baseline 只注入「文本 hint」，我们扩展成也能注入「图片 demo（均匀/状态锚/检索选帧）」。模型参数全程不动。

一句话回答你的核心疑问：**「均匀采样」不是 ICL-OpenHA 自带的，是我们加的图片 ICL 选帧策略；而它跑在一个有 SFT（LoRA 行为克隆）的 frozen adapter 上，不是裸模型。**

---

## 六、把「reset 时注入」和「ICL 加在哪」讲透（澄清）

### 6.1 `reset()` 是什么，demo 图是不是「只加在开头」

`reset()` 是**每个任务（episode）开始时调用一次**的初始化函数，不是「第一条 message」。它做两件事：

1. **文本 ICL**：`_build_icl_instruction` 把硬编码 hint 拼进 instruction 字符串。
2. **图片 ICL**：调用 `build_visual_demos`，从成功 rollout 里选好 k 帧 demo，缓存到 `self._icl_image_demos`（`patch_harness_hook.py:110-126`）。

之后 **episode 内的每一步**都会调用 `gen_response()`，每一步都从 `self._icl_image_demos` 读出这 k 帧，**前置到 messages 最前面**（`patch_harness_hook.py:153-165`）。

所以准确说法是：

> **demo 帧「选一次」（reset 时缓存），但「每步都注入」（每次 gen_response 都放进 messages）。不是只有开头第一条 message 有 demo，后面每步都有。**

### 6.2 ICL 到底是加在 user 的 instruction 里吗

要分两条通道，别混：

| 通道 | 注入位置 | 具体做法 |
| --- | --- | --- |
| **文本 ICL（baseline）** | 加在 instruction 字符串里 | `instruction + common + hint`，作为首条 user 消息的 prompt |
| **图片 ICL（我们加的）** | **不是**加在 instruction 里 | 作为独立的 `user(图)→assistant(文本)` 消息对，插到 messages 最前面 |

图片 ICL 时，`system_message + instruction` 这段文本**没有单独发一条**，而是挂在**第一个 demo 图的 user 消息的 prompt 字段**上。精确结构（图片 demo，`include_text=0` 时 assistant 文本为空）：

```
user(  image=demo_0图,  prompt=system_message+instruction )   ← 指令挂在这
assistant(  text=demo_0动作文本或空 )
user(  image=demo_1图,  prompt="" )
assistant(  text=demo_1动作文本或空 )
...（k 个 demo）
user(  image=历史第1帧,  prompt="" )
assistant(  text=历史动作 )
...
user(  image=当前观测图, prompt="" )
```

对照纯文本 ICL（无 demo）：`system_message+instruction+hint` 挂在**第一条历史消息**（没有历史就挂在当前观测）的 user prompt 上。

一句话：**文本 ICL 改的是「指令文本」；图片 ICL 加的是「额外的图→文消息对」，指令文本只是搭车挂在了第一张 demo 图上。**

---

## 七、状态锚帧具体怎么抽帧（含 score 的用途）

**先回答「score 是 id 还是选 top-k」：score 是「每帧的重要性打分」，用来挑分数最高的 k 帧，不是当 id 去查帧。**

四步（`visual_icl.py:107-203`）：

1. 读 rollout 的 `action.jsonl`（每步离散动作）+ `info.jsonl`（血量、坐标）。
2. 对每一帧 t 算 5 个数字特征：
   - `transition[t]` = 动作向量从 t-1 到 t 的 L1 变化
   - `health[t]` = |血量 t − 血量 t-1|
   - `attack_onset[t]` = 攻击 0→1 的那一帧
   - `displacement[t]` = |Δx|+|Δz|
   - `boundary[t]` = 首/末帧 = 1
3. 每个特征归一化到 [0,1]，加权求和得 `score[t]`（transition 1.0 / health 1.0 / **attack_onset 2.0** / displacement 1.0 / boundary 1.0）。
4. 按 score 选帧：`k=1` 取 argmax；`k≥2` 强制首帧[0]+末帧[n-1]，剩下按 score 从高到低贪心取（间隔 ≥ min_gap）。

实例：`kill_entity:cow` 均匀 k=3 取 `[0,32,65]`，状态锚帧取 `[0,14,65]`——第 14 帧是「开战瞬间」（attack_onset 最高），顶掉了均匀采样中间帧 32。

**状态锚帧臂 vs 属性检索臂的选帧算子完全相同（都 `mode="state"`），唯一区别是「选哪个 rollout」：**

| 臂 | 选 rollout | 选帧 |
| --- | --- | --- |
| `state_anchor_k*` | `load_demos_for_task`：正式实验中排除精确任务后，使用固定同类别回退（`category_fallback`；历史代码值 `prefix`） | `state_anchor_keyframe_indices` |
| `retrieval_k*` | `visual_memory.retrieve`：属性相似度检索 | 同样 `state_anchor_keyframe_indices` |

所以 retrieval 的增益来自「换了更好的 demo rollout」，不是「换了选帧方式」。

---

## 八、Stage 进度与后续规划

**当前进度**：Stage 1 / 1b / 2A / 2B / Stage2 推理验证均已完成；Stage 3 已切换基线到**原版 OpenHA（无 LoRA）**，并把视觉选帧/检索搜索空间自动化 + 离线验证跑通。

**基线切换**：Stage 3 不再用重训的 v4 adapter，改为 `openha_eager_icl`（`run_streaming_eval_evo.py:514`）——冻结 Qwen2-VL-7B **裸模型** + 文本 ICL（`icl_enabled=True`），**不加载任何 `lora_adapter_path`**，图片 ICL 由 harness 在推理期注入。论文主线聚焦「如何选 ICL 内容」，SFT 作为后续可选的提点方案。

**Stage 3 自动化**（本次新增）：
- `harness/candidates/search_demo_harness.py`：一个通用 harness，用环境变量解耦三个正交轴 `OPENHA_DEMO_SOURCE`（论文名 `category_fallback`/`retrieval`，其中 `prefix` 是前者的历史代码值）× `OPENHA_FRAME_MODE`（uniform/state/coverage）× `OPENHA_ICL_K`（1/3/5），覆盖全部 18 臂，无需每个臂单独建文件。
- `probe_stage3.py`：`CONFIG_NAME="openha_eager_icl"`、无 `lora_adapter_path`；`--offline` 做无 GPU/VLM 的搜索空间 dry-run，`--gpus/--sequential` 跑真实 eval。
- `visual_icl.py` 新增 `coverage_keyframe_indices`：首尾锚 + 均匀候选 + 攻击 onset 峰值交错填充（修复纯 state scorer 在大 k 时聚簇的问题）。

**离线验证结果**（`probe_stage3.py --offline`）：18 臂 × kill_entity 29 任务全部 `empty=0`、`short=0`，demo 数严格等于 k（1/3/5）。搜索空间 wiring 正确。

**后续规划**：

1. **多种子复测**：只复测关键对比 `retrieval_k3/k5` vs `uniform_k3/k5`（+ `baseline`/`image_k1` 锚点），确认 retrieval 信号是否真实。
2. **Stage 3 正式跑**（GPU）：在裸模型上对 18 臂做 frontier 搜索，命令 `python probe_stage3.py --sequential --gpus 7`（或 `--gpus 2,7` 并行），先用 `--subset-limit` 小规模试跑，再全量。
3. **Stage 4**：逐类自适应——每个 category 绑定各自最优的「检索+选帧+k」组合。

---

## 九、Stage 3 试跑结果（kill_entity 3 任务子集）

裸模型 `openha_eager_icl`（无 LoRA），`--sequential --gpus 7`，4 个代表臂 × 3 任务。全部 `rc=0`、`missing=0`，端到端跑通（裸模型加载 → harness 注入 → eval → metrics）。

| 臂 | ASR | 成功/失败 |
| --- | --- | --- |
| `category_fallback_uniform_3`（`prefix_uniform_3`） | 0.0% | 0/3 |
| `category_fallback_state_3`（`prefix_state_3`） | 33.3% | 1/3 |
| `category_fallback_coverage_3`（`prefix_coverage_3`） | 33.3% | 1/3 |
| `retrieval_coverage_3` | 0.0% | 0/3 |

样本太小不下结论；方向上 state/coverage 命中 1 例、uniform/retrieval 未命中，与 Stage 2 一致。全量 18 臂已开启。

---

## 十、文献综述：VLA 的 In-Context Learning（如何选 ICL 内容）

本项目 = **冻结 VLA + 图片 ICL 的 example/keyframe 选择**。对应文献主线是 VLA 的 **in-context learning（ICL）/ demonstration retrieval / keyframe memory / few-shot adaptation**，主要发在 CoRL、RSS、ICRA、ICLR、NeurIPS、ICML。

### 0. 地基 VLA（被下面这些工作改造的底座）
- **RT-2**（CoRL 2023）：VLM+VLA 融合奠基。
- **OpenVLA**（CoRL 2024）：开源 7B VLA。
- **π0 / π0.5**（Physical Intelligence）：连续 action-chunk 的 flow-matching
  VLA；**π0-FAST** 则使用 FAST action tokenizer 做自回归 action-chunk
  生成，RICL 以该自回归版本为底座。

### A. 给预训练 VLA 注入 ICL 能力（最直接对标）
1. **RICL**（CoRL 2025, PMLR 305; arXiv 2508.02062，UPenn）——**最核心**。核心论点：预训练 VLA 不会天然会 ICL，需用专门微调配方 + 少量 demo「后验注入」ICL 能力；针对 π0-FAST，10–20 demo 检索相关段入 context，无需更新参数。与我们区别：它靠**后训练注入能力 + 检索段**，我们是**冻结模型 + 选帧**。
2. **MOS-VLA**（arXiv 2510.16617）：one-shot 技能适配，把 demo 当「输入→输出函数对」（function encoder）而非序列。
3. **ControlVLA**（CoRL 2025）：10–20 demo，object-centric + ControlNet 零初始化投影，few-shot 76.7%。
4. **FOCA**（ICML 2026）：future-oriented conditioning，20 demo 95.7%（LIBERO）。
5. **EVOLVE-VLA**（arXiv 2512.14666）：test-time training，学习到的进度估计器从环境反馈适应，1-shot +22%、跨任务 0→20.8%。

### B. Demonstration 检索 / 选帧（= 本项目的核心问题）
6. **MemER**（ICLR 2026; arXiv 2510.20328，Stanford）——分层策略：高层 VLM 从过去经验里**选关键帧**，低层 VLA 用关键帧+近期帧出动作，分钟级长程记忆。**已中顶会**。
7. **KEMO**（arXiv 2026）：event-driven keyframe memory，选「阶段关键帧」，且 flow-matching loss 在关键帧附近加权。
8. **StellaVLA**（arXiv 2026）：检索带 rationale 的 demo 前缀并 pin 在 rollout 开头，前缀 KV cache 只算一次。
9. **Reflective VLA**（arXiv 2026）：滚动 buffer 存「obs→action chunk→结果 obs」三元组，VLM 侧 KV 复用，训练给逐步加长的 ICL 监督。
10. **OmniVIC**（arXiv 2510.17150）：RAG+ICL 做变阻抗控制，RAG+ICL 比 RAG-only 高 1.59×。
11. **Cortex 2.5**（Sereact，工业界）：每步重算检索最相关 demo 段，同时喂 planner 与 world model。
12. **DEMONSTRATE**（arXiv 2507.12855）：用真实 demo 替代手工 prompt，逆最优控制+多任务保证示例相似。
13. **MOKA**（RSS 2024; arXiv 2403.03174，UC Berkeley）：mark-based visual prompting，0/2-shot，ICL 减少失败。**已中顶会**。

> B 节里真正已中顶会的是 **MemER（ICLR 2026）** 与 **MOKA（RSS 2024）**；KEMO/StellaVLA/Reflective VLA 是 2026 年很新的 arXiv（未确认接收），OmniVIC/DEMONSTRATE 是 arXiv，Cortex 2.5 是工业界。整条线顶会锚点 = RICL（CoRL 2025）+ MemER（ICLR 2026）+ MOKA（RSS 2024）。

### C. Keyframe / 历史帧选择（长程 VLA）
14. **Keyframe Chaining**（arXiv 2026）：KSM 流式检测语义转移，稀疏语义关键帧流替代稠密窗口。
15. **BPP**（Key History Frames）：long-context imitation 聚焦关键历史帧。
16. **HAMLET**（ICLR 2025）：learnable moment tokens 压缩每步，而非保留原始视觉帧。

### D. 视频生成为通用策略（context 条件化）
17. **UniPi**（NeurIPS 2023）：视频规划 + 逆动力学模型，first-frame tiling 条件化。
18. **GR-2**（arXiv 2410.06158）：生成式 video-language-action，future-video 预训练，多视角+状态 history 条件化。

### E. Minecraft 垂直（我们的 base 领域）
19. **OpenHA**（arXiv 2509.13347）：本项目 base，CoA 统一规划与控制。
20. **JARVIS-VLA**（ACL Findings 2025）：ActVLP 后训练，1000+ 原子任务。
21. **OmniJARVIS**：unified VLA tokenization。
22. **Promptable VLM for RL**（TMLR 2025）：promptable VLM embedding 用于 Minecraft/Habitat RL。

> **关键 Gap**：Minecraft VLA 上几乎没有「图片 ICL 选帧」的直接工作——这正是本项目的空白点。

### F. 一个反直觉警示（直接关系我们的结论）
一项双机械臂研究（arXiv 2604.20348）对比文本 ICL（BiCICLe）vs 视觉 ICL（RICL）：视觉 ICL 平均 **12.4%** vs 文本 **70.5%**。作者归因：纯像素相似度的视觉 ICL 在需要精确空间协调的任务上，比离散化文本观测信息量低。**提示我们图片 ICL 的边际收益需小心论证「何时图片 ICL > 文本 ICL / 无 ICL」**。

### G. 本项目定位
- 处于三线交叉空白：**RICL（注入 ICL）× MemER/KEMO/StellaVLA（选帧/检索）× OpenHA（Minecraft VLA）**。
- 增量贡献：(1) Minecraft VLA 上的图片 ICL 选帧；(2) state/coverage/retrieval 选帧策略系统消融；(3) 在**无 SFT 原版模型**上验证「ICL 内容选择」本身（区别于 RICL 的「后训练注入能力」）。

---

## 十一、长程 VLA 级别 + 「直接整 VLA」的定位讨论

### 11.1 长程级别标尺

| 级别 | 典型步骤数 | 是否需记忆 | 例子 |
| --- | --- | --- | --- |
| 短程（原子动作） | ~10–50 步 | 否 | 「抓红色方块」「按按钮」 |
| 中程（单任务/1–2 子任务） | ~50–300 步 | 弱 | 「拿杯子放托盘」；OpenHA 的 `kill_entity`/`mine_block`（≤400 步） |
| 长程（多阶段/分钟级） | ~500–2000+ 步 | 是（关键） | 「冲咖啡」「准备零食」「收拾厨房」（MemER/KEMO 的任务） |
| 超长程/开放世界 | 数千~数万步 | 是 + 世界模型 + 层次规划 | Minecraft「获得钻石」「建房子」「生存整局」 |

**长程判据不是单看步数，而是三个信号叠加**：(1) 需要跨阶段记忆；(2) 子任务串联（≥3 个不同阶段）；(3) 非马尔可夫依赖（单看当前帧不够）。

按此判据：OpenHA 单任务（`kill_entity`/`mine_block`）＝**中程**；`craft_item` 内部有「砍木→木板→工作台→合成」隐式子任务链，**边缘偏长程**；Minecraft 整局＝**超长程**。

### 11.2 「没人关心 Minecraft 的记忆架构」——这个预感基本成立，但要收窄

- Minecraft 不是没有记忆工作，而是**记忆都做在「高层规划」层**：Voyager（skill library + 自动课程）、JARVIS-1（多模态记忆）、GITM（MineAgent 记忆）。这些是 LLM/VLM agent 的「技能库/经验缓存」，服务的是「下一步做什么」。
- 真正缺的是**「低层 VLA 的 ICL 记忆架构」**——即 MemER/KEMO 那种「从经验里选视觉关键帧 → 注入低层 VLA 的 context」。这一层在 Minecraft 上没人做。所以你的 gap 判断成立，但要把「记忆架构」限定为「**低层 VLA 的 demo/keyframe ICL 检索**」，而不是泛泛的「Minecraft 记忆」。

### 11.3 「Demonstration 检索/选帧 可以直接整 VLA」——成立，且是我们的路线

「直接整 VLA」= 不做 MemER 那种「独立高层 VLM 选帧 + 低层 VLA」的分层记忆架构，而是**选帧结果直接注入 VLA 的 context**（我们正是这样：uniform/state/coverage/retrieval 选好 k 帧 → 前置进 `gen_response` 的 messages）。

这为什么行得通、为什么 MemER/KEMO 又要分层：
- MemER/KEMO 的靶任务是**真实机械臂长程任务**（分钟级、跨阶段、需每步自适应重选关键帧），所以必须有个独立模块持续决策「现在该看哪帧」。
- 我们的 Minecraft 单任务是**中程、demo 在 reset 时一次性选定**，不存在「每步重选」的强需求，因此**独立的记忆架构是过度设计**，直接选帧注入即可。
- 这正是 RICL 的路线（检索 demo → VLA context，无独立记忆模块）在 Minecraft 上的延伸。

**推论（对论文定位）**：我们的贡献可以提炼为——「在 Minecraft 低层 VLA 上，ICL demo/keyframe 选择可以直接做（无需记忆架构），关键变量是**选帧策略**；我们用 state/coverage/retrieval 系统消融给出答案」。注意不要过度外推到「超长程 Minecraft」（获得钻石那种仍需记忆），把范围限定在「中程单任务 + 直接 ICL」即可。

---

## 十二、离散动作输出 + 记忆研究现状 + Prismatic/DiT 谱系

### 12.1 「离散动作输出 / 动作空间控制」除了 Minecraft 还有哪些

离散动作 token 不是 Minecraft 的专利，反而是**机器人 VLA 的主流范式**——只不过它们离散化的是「连续关节量」：

| 模型 | 会议 | 动作输出 | 离散化方式 |
| --- | --- | --- | --- |
| **RT-1** | RSS 2023 | 多分类头 | 每维 256 bin × ~11 维（7 自由度 + 夹爪 + 基座） |
| **RT-2** | CoRL 2023 | PaLI-X/PaLM-E 55B，文本式动作 token | 均匀 256 bin |
| **OpenVLA** | CoRL 2024 | Llama-2-7B + DINOv2/SigLIP，自回归 7 token | 256 bin，按 [1%,99%] 分位数归一化 |
| GUI/web agent | — | 点击/输入坐标 | 像素坐标离散成 token |
| 游戏 agent | — | 键鼠动作 | 按键离散 + 相机连续（同 Minecraft） |

关键点：**RT/OpenVLA 系把本来的连续机械臂动作量化成 256 档离散 token，是「离散输出」最大的群体**；Minecraft 反而是「原生离散按键 + 连续相机」的混合体（见 12.3）。

### 12.2 是否有专门针对「离散 VLA 记忆」的顶会研究

旧版综述曾把 π0-FAST 误写为 flow matching，并把 OpenHA 直接等同于
OpenVLA 式专用离散 action token；现统一修正：

- π0/π0.5 属于连续 action-chunk flow matching；
- π0-FAST 属于 tokenized action-chunk autoregression；
- OpenVLA 属于专用量化 action-token autoregression；
- OpenHA/CrossHA 属于 action-structured language-token autoregression；
- HAMLET/MemER 等记忆工作可作为相邻参考，但不能据此声称
  “autoregressive action-token VLA + memory 完全无人研究”。

因此本文不再主张一个绝对空白，而聚焦更可辩护的组合：
**成功 rollout 的稀疏 demo 选择 + 无污染 retrieval + autoregressive
next-action token shift 分析**。

### 12.3 Minecraft 是不是完全离散的？（你的记忆没错：相机是连续的）

**Minecraft/OpenHA 是「混合动作空间」，不是完全离散。** 看我们自己的代码就能确认（`visual_icl.py:_action_vec`）：

```python
ACTION_KEYS = ["attack", "back", "forward", "left", "right", "jump", "sprint", "sneak", "use", "inventory", "pickItem"]  # 离散按键
cam = action.get("camera") or [0.0, 0.0]           # 连续鼠标/相机增量
v.append(min(1.0, (abs(cam[0]) + abs(cam[1])) / 200.0))  # 连续量被截断进 [0,1]
```

- **离散部分**：11 个布尔按键（attack/forward/use/…）+ pickItem。
- **连续部分**：`camera` 是 (Δyaw, Δpitch) 鼠标增量，是连续浮点数；OpenHA 的 RawHA 里鼠标（相机）是连续、键盘是离散。

所以准确表述是：**OpenHA 动作 = 离散按键 + 连续相机鼠标增量**。你记得「移动/相机是连续的」完全正确——这恰好说明它比 RT/OpenVLA 那种「纯连续关节被强制离散化」更复杂：**本身就是离散/连续混合**。这也让「选帧要不要考虑相机变化」成为一个额外的可消融点（我们的 `_action_vec` 目前把相机当连续特征加进 state/coverage 打分）。

### 12.4 Prismatic-7B + DiT vs OpenHA（谱系与差异）

**谱系链（MemoryVLA 侧）**：

```
LLaMA-2-7B + DINOv2 + SigLIP
   └─(投影融合)→ Prismatic VLMs（Stanford, ICML 2024）
        └─→ Prismatic-7B VLM
             └─(+Open-X Embodiment + DiT 扩散动作头 ~300M)→ CogACT（CoRL 2024）
                  └─(+ PCMB 记忆库)→ MemoryVLA（ICLR 2026）
```

**谱系链（OpenHA 侧）**：

```
Qwen2-VL-7B（阿里，预训练 VLM）
   └─(+CoA 统一 tokenization + Minecraft 数据 + RocketPolicy/MotionPolicy)→ OpenHA（arXiv 2509.13347）
```

**对比表**：

| 维度 | Prismatic-7B + DiT（MemoryVLA/CogACT 底座） | OpenHA（本项目 base） |
| --- | --- | --- |
| 视觉编码器 | DINOv2 + SigLIP（双塔拼接） | Qwen2-VL 原生 ViT |
| 语言骨干 | LLaMA-2-7B | Qwen2-VL-7B（Qwen2 语言骨干） |
| 动作输出 | DiT **扩散**去噪（连续，DDIM 10 步） | **自回归离散 token**（object_ref / point / action 文本），eager 模式 |
| 动作空间 | 连续关节（Open-X Embodiment） | 混合：离散按键 + 连续相机 |
| 分层/策略头 | 单低层 policy | CoA：RocketPolicy（grounding）+ MotionPolicy |
| 记忆组件 | MemoryVLA 加 PCMB 记忆库（连续动作头之上） | 无原生记忆 → 我们加图片 ICL 选帧 |

**一句话差异**：MemoryVLA 系是「LLaMA-2 + 双视觉塔 + 连续扩散动作头」；OpenHA 是「Qwen2-VL 单塔 + 离散自回归动作 token」。两者的记忆都缺在「低层 VLA」层，但**OpenHA 是离散 token，MemoryVLA 是连续扩散**——这正对应 12.2 的空白：离散 VLA 的记忆没人专门做。

---

## 十三、CoA 结构澄清 + demo 文本抽象层级杠杆 + 跨领域统一 next-token 框架

### 13.1 OpenHA 的「高层」不是独立模块（澄清一个直觉）

OpenHA 标题里的 *Hierarchical* 指**动作抽象层级**（LanguageHA → GroundingHA → MotionHA → RawHA → LatentHA），**不是**「高层 planner + 低层 controller」的模块分层。

**Chain of Action（CoA）** 把「高层」和「低层」折叠进**同一个 Qwen2-VL-7B 的同一条自回归 token 流**：

```
VLM 自回归输出（一个 forward，一条流）：
  ┌────────────────────────────┬──────────────────────────────┐
  │ ① 高层抽象动作（"思考"）      │ ② 低层可执行动作（"执行"）       │
  │  GroundingHA: Approach(      │  MotionHA: move(dx,dy)        │
  │    object=<tree>, point=…)   │  → RawHA: attack=1,forward=1  │
  └─────────────────────────────┴──────────────────────────────┘
```

`openha_eager_icl` 配置的 `output_mode="eager"` + `grounding_policy_path=ROCKET-1` + `motion_policy_path=Motion_policy`，即：VLM 先吐抽象动作（Grounding→Motion→Raw 的 eager 路由），再由 ROCKET-1（grounding）和 MotionPolicy 解码成可执行键鼠。**所以「高层规划」在 OpenHA 里 = CoA 输出流的第一段，不是另一个模型/另一个 call。**

### 13.2 未利用的杠杆：demo 文本的抽象层级（含一个关键发现）

**关键发现：当前 18 臂实验的 demo 文本是「空」的。** `search_demo_harness.py` 里 `include_text` 默认 `False`（`OPENHA_ICL_INCLUDE_TEXT` 未设置时 = `"0"`），而 `probe_stage3.py:arm_env` 没设这个变量 → `build_visual_demos` 执行 `demos = [(img, "") for img, _ in demos]`。也就是说**现在跑的是「纯图片 ICL」，demo 动作文本根本没注入**。

由此产生一个**没扫过的第四轴：demo 文本抽象层级**：

| 层级 | demo 文本 | 数据来源 | 状态 |
| --- | --- | --- | --- |
| `none` | 空（纯图） | 无 | 现状（18 臂都在此档） |
| `raw` | 低层离散按键 `attack=1, forward=1` | `action.jsonl`（已有） | **可立即测**（include_text=True） |
| `abstract` | 高层 CoA 抽象动作 `Approach(object=zombie, point=…)` | 需捕获模型 `content`（CoA 文本） | 需先做 CoA 标注 |

这是「在高层规划层做 ICL」在 OpenHA 上**唯一可行**的形式：不是加模块，而是**换 demo 文本的抽象层级**。现有 `source×frame×k` 三轴没碰这个维度。

### 13.3 跨领域「中高层统一 next-token」框架（CoA 的同族）

CoA 的「单模型一条流：先高层/推理、再低层动作」在机器人和其他垂类都有对应，分三类：

**A. 机械臂 VLA 最直接同构：ECoT**
- **ECoT**（CoRL 2024; arXiv 2407.08693，Stanford/UCB）：训练 VLA 自回归生成 `TASK→PLAN→SUBTASK→MOVE→GRIPPER→OBJECTS` 推理 token，**再**预测低层动作 token，纯 next-token CE 损失。Bridge V2 上比 OpenVLA **+28%**，7B 击败 55B RT-2-X。**区别**：ECoT 中间段是「自由文本推理」，CoA 中间段是「跨层动作」（本身是动作，只是更抽象）——同族，CoA 的独特性是中间段是 action 而非 free text。

**B. 单模型统一 next-token（离散+连续混合）**
- **GenieReasoner**：FACT（flow-matching action tokenizer）把 reasoning 和 motor action 离散到同一 token 空间。
- **Galaxea G0.5**：memory + CoT 推理 + action token 一条流（Subtask/BBox/Trace/ActionHint → ActionCodec）。
- **OneTwoVLA**（ICLR 2026）：单 π0 VLA，`[BOR]`/`[BOA]` 决策 token 切「推理段（场景/计划/历史/下一步）→ 动作 chunk」。
- **Uni-CoT / Unified Cross-Level CoT**：instruction CoT → 子任务 → 连续动作，MoE 耦合。

**C. 单模型内双系统分层（分层但同模型）**
- **GR00T N1**：VLM（System 2 高层）+ DiT（System 1 低层）cross-attention。
- **Libra-VLA**：Semantic Planner（离散宏 token）+ Action Refiner（连续）。
- **Anticipation-VLA**：UMM 生成子目标 + goal-conditioned VLA 执行。
- **τ0-VLA**：高层 + world-model 引导的 test-time compute。

**D. 文本/Agent 祖先**
- **ReAct**（ICLR 2023）`Thought→Action`、以及 function-calling/tool-use agent——CoA 在纯文本域的祖先。

**对本项目的含义**：CoA/ECoT 这个「推理段 + 动作段一条流」的框架已经是具身智能的显学；但**「用 ICL demo 去引导这条流里哪一段（规划段 vs 动作段）」没人做**——这正是 13.2 的 demo 文本抽象层级实验能切入的新空白。

## 14. 基准榜单溯源（CrossHA）+ 标注 hook 落地

### 14.1 「All-Tasks 54.6% vs OpenHA 31.5%」是哪个榜

来源：**OpenHA benchmark**（OpenHA 论文提出的 800+ Minecraft 任务基准），这张对比表出现在 **CrossHA / CrossAgent** 论文（CVPR 2026 Highlight；arXiv 2512.09706，*Training One Model to Master Cross-Level Agentic Actions via Reinforcement Learning*）。

基准规模：Minecraft 1.16.5、360×640×3 RGB、三分类 **Mine Blocks**（导航+交互）/ **Kill Entities**（战斗）/ **Craft Items**（GUI 合成）。

All-Tasks 主表（两列关键指标：**FT** = Finished Tasks 完成率；**ASR** = Average Success Rate 平均成功率）：

| Method | All FT ↑ | All ASR ↑ | Mine FT | Craft FT |
| --- | --- | --- | --- | --- |
| **CrossHA** | 58.7 | **54.6** | **94.7** | **83.3** |
| OpenHA | 62.8 | 31.5 | 67.3 | 58.8 |
| Game-TARS | – | 42.2 | – | – |
| JARVIS-VLA | 63.8 | 24.5 | 55.3 | 74.3 |
| GroundingHA | 59.5 | 23.4 | 61.0 | 27.5 |
| CrossHA (w/o STRL) | 44.9 | 41.6 | 35.1 | 55.7 |

解读：**54.6% vs 31.5% 是 All-Tasks ASR**（可靠性/稳定性），CrossHA 大胜；但 **FT 上 OpenHA 反而略高（62.8 vs 58.7）**——即 OpenHA「能完成」但「很不稳定」（能通关的任务平均成功率低）。CrossHA 用 STRL（跨层动作的强化学习）只训 30 个任务就泛化到 800+，并把稳定性拉上来。这对本项目是重要参照：**OpenHA 的短板是「稳定性」而非「能完成」，正是 ICL 记忆/一致性引导想打的目标。**

### 14.2 标注 hook（thought.jsonl）落地

**为什么需要**：Stage 3B 的 `abstract` 档要读每步的 CoA 文本 `thought.jsonl`，但现有 `00_original_icl` 成功池是 hook 存在之前录的，只有 episode/action/info，没有 thought.jsonl。

**hook 做了什么**：
- `patch_thought_dump.py` 在 `run_streaming_eval_evo.py` 的 `run_single_task` 中、`agent.get_action(...)` 之后插入：`OPENHA_DUMP_THOUGHT=1` 时把 `agent._thought` 逐行 append 到 `<rollout>/thought.jsonl`（`{"content": ...}`）。
- `agent._thought` 由 harness patch 暴露：`streaming_openha_original_harness.py:337` `self._thought = content`；`content = output["content"]` 是 `generate()` 返回的 VLM 原始 CoA 文本（与 `openha.py:350` 同源）。

**落地状态（本会话完成）**：
1. `patch_thought_dump.py` 已部署并跑通（`run_streaming_eval_evo.py:729` 验证通过）。
2. `annotate_coa.py` 已写好并部署：裸 OpenHA 跑 kill_entity（29 任务）+ `OPENHA_DUMP_THOUGHT=1`，完成后把「含非空 thought.jsonl 的成功 rollout」提升到 `eval/icl_success_pool/01_annotated_icl`。
3. 标注跑已在 GPU 0 后台启动（pid 306548），首任务 `kill_entity_bat` 已写出 55 行 thought.jsonl。

**捕获到的内容格式（需说明）**：`content` 是模型**紧凑文本动作**，如 `{"content": "Action: move(0, 0) and press(e)<|im_end|>"}`，不是长链自由文本推理。所以 `abstract` 档实际文本 = 模型自己的文本动作（含方向 `move(dx,dy)`、交互键 `press(e)`），语义比 `raw` 的离散按键 `forward=1, attack=1` 更结构化但仍属动作层；这仍是有效杠杆（`raw` 离散键 vs `abstract` 模型文本动作 = 两个不同抽象度的动作描述），只是「abstract」不等于「自由文本高层规划」——更准确的命名应是 `model-text`。

## 15. OpenHA benchmark 开源确认 + 与原版逐字节对齐验证

**结论：开源，且我们服务器上的副本与上游 GitHub 逐字节一致；本项目 bench 的 801 个任务 = 原版 801 个唯一任务（双向 diff 为空）。**

### 15.1 开源位置

- 仓库：`github.com/CraftJarvis/OpenHA`（OpenHA 论文官方仓库；CrossHA/CrossAgent 也指向同一仓库）。
- 任务定义（benchmark 本体）：
  - `openagents/assets/spawns/*.json` —— 每个任务一个 key，含 seed/position/tool/reward 等（权威任务清单）。
  - `openagents/envs/tasks/*.py` —— 每个类目的 `get_available_*_tasks()` + `gen_*_task_config()`。
- 服务器本地副本：`/data3/openha_repro/OpenHA/`（非 git 仓库，纯拷贝）。

### 15.2 逐字节对齐验证（关键）

对 5 个 spawn JSON 计算 git blob SHA，与 GitHub API 返回的上游 SHA 逐一比对，**全部一致**：

| 文件 | 上游 SHA（GitHub API） | 服务器 SHA | 一致 |
| --- | --- | --- | --- |
| mine_block.json | a6b6e330… | a6b6e330… | ✅ |
| kill_entity.json | 3990d8a5… | 3990d8a5… | ✅ |
| craft_item.json | 143e0bfd… | 143e0bfd… | ✅ |
| smelt_item.json | 1579684a… | 1579684a… | ✅ |
| interact_block.json | 44d6c2cd… | 44d6c2cd… | ✅ |

### 15.3 原版 benchmark 的真实规模（「800+」精确拆解）

| 类目 | 任务数 | 说明 |
| --- | --- | --- |
| mine_block | 153 | 采矿/挖掘类 |
| kill_entity | 49 | 61 个里剔除 12 个非 normal（nether/the_end/boss 维度生物，如 blaze/ender_dragon） |
| craft_item | 551 | 工作台合成 |
| smelt_item | 45 | 熔炉冶炼（任务名也是 `craft_item:*` 前缀） |
| interact_block | 13 | `custom:interact_with_*` |

- `get_available_tasks()` 原始条目 = 153 + 49 + 551 + 45 + 13 = **811**；
- 唯一任务名 = **801**（有 10 个 `craft_item:*` 同时出现在 craft_item 与 smelt_item，如 `craft_item:iron_ingot`/`coal`/`diamond`/`gold_ingot`/`lapis_lazuli`/`redstone`/`dried_kelp`/`gold_nugget`/`iron_nugget`/`lime_dye`）；
- `gen_task_config` 先查 craft_item，所以这 10 个重名任务走「合成」配置，smelt 的 35 个（如 `craft_item:cooked_beef`）才走「冶炼」——即「800+」= 801 唯一任务。

### 15.4 本项目 bench 与原版的精确 diff

- 服务器 `bench/train_v2_tasks.txt`（724）+ `bench/test_v2_tasks.txt`（77）= **801**。
- `orig - ours = []`、`ours - orig = []`、交集 = 801：**双向无差，逐名一致**。
- 唯一的语义差异在 `config.category()` 映射：原版把 smelt_item 当独立类目，我们的 `category()` 因 smelt 任务名是 `craft_item:*` 前缀而归入 `craft_item`；这只是**类目标签**的归类差异，任务名与任务集本身完全一致。

## 16. 成功池 train/test 组成 + CrossHA 代码与 ICL 可移植性

### 16.1 成功 rollout（demo 池）选自训练集还是测试集？

当前 Stage 3/3B 用的 `POOL_ROOT = eval/icl_success_pool/00_original_icl` 是**混合池，含测试集泄漏**：

| 池 | 任务数 | 在 train | 在 test | 结论 |
| --- | --- | --- | --- | --- |
| `00_original_icl`（当前用） | 79 | 67 | **12** | 混合，有泄漏 |
| `round1` | 203 | 203 | 0 | **纯 train，干净** |

泄漏进 `00_original_icl` 的 12 个 test 任务：`craft_item:birch_sign`、`custom:interact_with_cartography_table`、`kill_entity:{cow, drowned, fox, husk, parrot, pig, skeleton_horse, turtle, villager, vindicator}`。

影响：Stage 3/3B 在 **train** 的 kill_entity(29) 上评测，泄漏不致命（不是测 test）；但**正式在 test_v2(77) 上报数前，必须切到 train-only 池**（用 `round1`，或把 `00_original_icl` 过滤掉这 12 个 test 目录）。

### 16.2 OpenHA repo 里有 CrossHA 代码吗？能把我们的 ICL 加到 CrossHA 上吗？

**有**。`CraftJarvis/OpenHA` 仓库的 `CrossAgent/` 目录就是 CrossHA 完整代码：
- `CrossAgent/SFT/`（Mixed-Space SFT）、`CrossAgent/STRL/`（单轮 GRPO，verl `main_ppo` + `custom_reward_funcs/mix_vla.py` 等）、`CrossAgent/MTRL/`（多轮 GRPO）。
- 输出用 `<raw>...</raw>` 标签 + `TextActionTokenizer`（`openagents.agents.utils.action_mapping`）+ `mix_action_system_prompt` / `coa_system_prompt`。

**能加 ICL**，理由（技术上可行）：
1. **同架构**：CrossHA 基座也是 Qwen2-VL-7B（HF 模型卡 `CraftJarvis/CrossAgent-qwen2vl-7b`）→ 图片 ICL 是输入级注入，与权重无关。
2. **同框架**：CrossHA 复用 `openagents` 包（`make_data.py` 直接 import `openagents.agents.utils.*`），我们的 harness hook（`gen_response` 前置 demo image→text）是同一条注入路径。
3. **demo 池模型无关**：成功 rollout = 帧 + 动作文本，换模型照样可用。

需要做的工作/障碍：
- 把 `patch_harness_hook.py` 的 `gen_response` 覆盖从 `streaming_openha_original.py` 移植到 CrossHA 的 eval agent（不是同一文件）。
- demo 文本抽象层级要适配 CrossHA 的 `<raw>` / mix-action 格式（`raw`/`abstract` 的文本源不同）。
- CrossHA checkpoint **不在我们服务器**（只有 `minecraft-openha-qwen2vl-7b-2509`），需从 HF 下 `CraftJarvis/CrossAgent-qwen2vl-7b`；RL 训练脚本里的路径指向 `/share/hkc/...`（另一台机器）。

这正好是新的研究角度：**OpenHA 是 SFT/CoA，CrossHA 是 RL 训练的同族**——在 RL 模型上测「ICL 引导」是否仍有效，是 13.3 那个「没人做」空白的一个自然延伸。

## 17. CrossHA 架构 + 测试集泄漏修复（已完成）

### 17.1 CrossHA 架构是什么（相对 CoA）

CrossHA（CraftJarvis/CrossAgent-qwen2vl-7b）是一个**统一多动作空间的 RL VLA**，基座 Qwen2-VL-7B：

1. **输出层**：模型输出结构化文本 `<raw>...</raw>`，由 `TextActionTokenizer`（`openagents.agents.utils.action_mapping`）把文本 token 还原成可执行的混合动作空间（离散动作 + 连续相机/移动等），动作空间按任务自适应选择。
2. **CoA（Chain-of-Action）是它的「推理输出」**：`coa_system_prompt` 让模型在输出动作前先给出动作链推理文本，这个推理是 **RL（GRPO）学出来的**。
3. **训练管线**：`CrossAgent/SFT/`（Mixed-Space SFT）→ `CrossAgent/STRL/`（单轮 GRPO）→ `CrossAgent/MTRL/`（多轮 GRPO），奖励在 `custom_reward_funcs/mix_vla.py`。

关键区分：
- **CoA = 输出侧**（模型生成的推理 token，RL 习得）。
- **我们的 ICL = 输入侧**（推理时在 prompt 里注入成功 demo 的帧+动作文本，零训练）。
- 两者正交、可叠加：CoA 是「模型内部怎么说」，ICL 是「给模型看什么例子」。所以「像我们这样加 CoA/ICL」都能加，且能同时加。

### 17.2 能不能把 ICL 加到 CrossHA 上

**能**，且比 CoA 更直接，因为：同基座（Qwen2-VL-7B）+ 同 `openagents` 框架，ICL 是纯推理期注入、与 RL 权重无关。移植点 = 把 `gen_response` 前置 demo 注入从 `streaming_openha_original.py` 挪到 CrossHA 的 eval agent；demo 文本需适配 `<raw>`/mix-action 格式；checkpoint 需从 HF 下载（不在本机）。

### 17.3 测试集泄漏修复（响应「之后的测试都不能泄漏测试集」）

已定位并修复 `00_original_icl` 池的 test 泄漏（12 个 test 任务混入 79 个 demo 目录）：

- **新建 train-only 池** `/data3/openha_evo/eval/icl_success_pool/00_original_icl_trainonly`：仅 67 个 train 目录，12 个泄漏目录（`craft_item_birch_sign`、`custom_interact_with_cartography_table`、`kill_entity_{cow,drowned,fox,husk,parrot,pig,skeleton_horse,turtle,villager,vindicator}`）全部剔除，服务器实测 `leaked dirs present: []`。
- **重建 memory bank** `kill_entity_bank.json`：17 条目，仅 11 个 train 实体（donkey/enderman/horse/llama/pillager/polar_bear/salmon/sheep/skeleton/stray/zombie_villager，部分多 rollout）。
- **改 POOL_ROOT**：`probe_stage3.py:39`、`probe_stage3b.py:39`、`search_demo_harness.py:21-23` 默认值全部从 `00_original_icl` → `00_original_icl_trainonly`，已 scp 部署并 grep 确认。

后续约束（已固化）：
- Stage 3/3B 在 train 的 kill_entity(29) 上评测；**正式报 test_v2(77) 前必须确认 POOL_ROOT=trainonly / round1**。
- `abstract` 文本层需 `thought.jsonl`，当前 `00_original_icl_trainonly` 无此文件（标注前记录），故 abstract 臂需指向 `01_annotated_icl`（train-only 标注池，标注运行 GPU0 进行中），否则静默退化为空文本。

## 18. abstract 臂修复 + CrossHA 完整流程（含 CoA 澄清）

### 18.1 abstract 臂指向 annotated 池（已修）

问题：`00_original_icl_trainonly` 是标注前记录，无 `thought.jsonl`，abstract 臂会静默退化为空文本。

修复（已 scp 部署 + 离线 smoke 通过）：
- `probe_stage3b.py`：新增 `ABSTRACT_POOL_ROOT=.../01_annotated_icl`、`ABSTRACT_MEMORY_BANK=.../kill_entity_bank_annotated.json`；`_pool_bank_for(text_level)` 在 abstract 时切到标注池/标注 bank；`ensure_memory_bank` 按需构建标注 bank。
- `search_demo_harness.py`：`SearchDemoHarness` 支持显式 `pool_root`/`bank_path`；`_load_bank` 对缺失 bank 优雅降级为 `[]`。
- 离线 smoke 确认 abstract 臂当前 `empty=5/5` 是正常的（标注运行 26/29 任务、6 个 success，promote 尚未执行）。

### 18.2 CrossHA 有没有 CoA：有

之前 "OpenHA=SFT/CoA，CrossHA=RL 同族" 的写法易误解为 CrossHA 没有 CoA。实际上 **两者都有 CoA**。CoA（Chain-of-Action）= 分层动作链输出（Skill→Grounding→Motion→Action）。区别只在训练方式与动作空间：OpenHA 是 SFT（动作空间较固定），CrossHA 是 GRPO-RL 且**动作空间可混合/自适应选择**（每个 step 可只输出 raw，也可输出完整分层链）。

## 19. CrossHA 移植：demo 来源问题 + gated 访问状态

### 19.1 demo 来源（用户提的顾虑是对的）
OpenHA 成功 rollout 的帧 = OpenHA 的相机轨迹/动作风格（离散动作、离散相机），直接喂给 CrossHA（连续 `move('dx','dy')` 相机、RL 动作空间）有跨模型 mismatch。严谨做法：
1. 下载 + serve CrossHA；
2. 先跑 CrossHA bare（无 ICL）在 kill_entity(29) 采集**它自己的成功 rollout** → `crossha_success_pool`；
3. 用 CrossHA 自己的 rollout 做 uniform/state/retrieval 抽帧；
4. 再跑 9 臂 + baseline 做 SR 消融。
选帧逻辑（`uniform/state_anchor_keyframe_indices`、`visual_memory.retrieve`）可复用，只需喂 CrossHA 的 episode.jsonl/action.jsonl。

### 19.2 CrossAgent-qwen2vl-7b 是 gated（manual）
实测带 token：认证通过但 `GatedRepoError 403 ... you are not in the authorized list. Visit ... to ask for access.` → 账号未在授权列表，需去 HF 页面接受 license / request access。
