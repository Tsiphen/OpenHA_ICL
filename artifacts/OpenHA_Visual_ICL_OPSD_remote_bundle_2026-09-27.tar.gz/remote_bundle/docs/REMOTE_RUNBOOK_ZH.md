# Remote Runbook

## 1. 先确认来源

```bash
cd ~/projects/ICL-OpenHA
cp config/sources.env.example config/sources.env
${EDITOR:-vi} config/sources.env
bash scripts/check_remote_sources.sh
```

如果检查失败，不要从师兄的 `ENV_RUN` 目录读取或修改文件。需要向项目
维护者索取以下内部来源：

```text
OpenHA_ROOT
OpenHA_MODEL
SUCCESS_POOL
MEMORY_BANK
FULL29_REPLAY
```

## 2. Python 环境

优先使用服务器已有的 Python 3.10 + torch/transformers 环境。只有在内部
pip 镜像可用时才安装缺失依赖：

```bash
python3 -m pip install --index-url "$PIP_INDEX_URL" \
  peft accelerate datasets qwen-vl-utils
```

不要从公网 pip、GitHub 或 Hugging Face 重复下载。

## 3. 代码阶段

```text
Stage I/II:
  frozen OpenHA visual ICL
  source × frame mode × k

Stage III:
  same-task / exclude-task / exclude-entity strictness

Stage IV:
  fixed-prefix action/token/phase mechanism replay

OPSD:
  OPSD-0 smoke
  OPSD-1 pseudo-label student
  ordinary self-imitation control
  OPSD-2 offline teacher-logit token KL
  held-out no-demo evaluation
```

每个阶段都必须在 `$EXPERIMENT_ROOT/status/` 写状态和 manifest，日志写入
`$EXPERIMENT_ROOT/logs/`，不能覆盖已有产物。

## 4. 数据边界

- Demo pool 只能使用 train-only success rollouts。
- `negative_demo`、`category_demo`、shuffled demo 保留为 controls。
- held-out/test 不参与 demo 选择、阈值选择或 checkpoint promotion。
- 当前 Visual ICL 的主证据是 `kill_entity` 29-task train/dev，不应伪称为
  801-task image-ICL full result。

## 5. OPSD-3A

只有 OpenHA Minecraft environment、student rollout API 和 teacher privileged
prefill 都可用时才运行：

```text
student no-demo rollout
  -> save student prefix
  -> teacher same prefix + train-only visual demo
  -> action/CoA logits
  -> selective KL
  -> update student LoRA
```

OPSD-3B 的 teacher action override/recovery label 属于可选 DAgger-style
扩展，不是主方法的必要部分。
