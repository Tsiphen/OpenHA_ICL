# OpenHA 图片 ICL：论文故事脉络

> 版本：2026-09-20  
> 用途：凝练论文从宏观动机到微观机制的叙事主线。  
> 正式协议与完整结果见 `OpenHA_ICL_paper_plan_zh.md`。

---

## 1. 宏观问题：VLA 如何在不重新训练的情况下利用成功经验

Vision-Language-Action 模型通常依靠大规模预训练、模仿学习或强化学习
获得能力。但是，真实智能体在部署过程中会不断积累成功轨迹，而这些轨迹
通常只被用于离线再训练，难以在测试时立即转化为策略改进。

这引出一个更一般的问题：

> **一个已经冻结的 VLA，能否像语言模型利用 few-shot examples 一样，
> 在推理上下文中直接利用过去的成功视觉经验？**

如果答案是肯定的，那么成功 rollout 不只是训练数据，还可以成为一种
test-time policy memory。智能体无需更新参数，只需检索少量相关经验，
就可能改变下一步动作预测。

<span style="color:#c62828"><strong>本工作的核心价值不是“给 Minecraft 模型多放几张图片”，而是研究视觉经验如何成为 frozen VLA 的推理时策略条件。</strong></span>

## 2. 现有方法：分别解决了什么，又留下了什么

现有工作已经证明 VLA 可以通过后训练、示范上下文、视觉提示、记忆和
test-time computation 获得提升。我们不能笼统地说这些方法“不行”；准确的
问题是：**它们尚未同时解决 frozen autoregressive next-action VLA 如何从
稀疏成功经验中获得可解释、稳定且可复现的 ICL 增益。**

| 现有路线 | 代表顶会工作 | 已解决的问题 | 尚未覆盖本文问题的部分 |
| --- | --- | --- | --- |
| 参数后训练与任务适配 | [OpenVLA, CoRL 2024](https://proceedings.mlr.press/v270/kim25c.html)、[TraceVLA, ICLR 2025](https://proceedings.iclr.cc/paper_files/paper/2025/hash/8667f264f88c7938a73a53ab01eb1327-Abstract-Conference.html)、[ECoT, CoRL 2024](https://proceedings.mlr.press/v270/zawalski25a.html) | 通过 LoRA、轨迹提示监督或 reasoning supervision 提高下游成功率 | 经验被吸收到参数中，不能单独回答部署时成功 rollout 能否立即改变 frozen policy |
| 完整轨迹 ICL | [ICRT, ICRA 2025](https://arxiv.org/abs/2408.15980)、[RICL, CoRL 2025](https://proceedings.mlr.press/v305/sridhar25a.html) | 证明 sensorimotor demonstrations 可以成为新任务的上下文 | ICRT 训练专用 causal policy；RICL 先后训练 ICL 能力并使用 10-20 条目标任务 demo，均未聚焦固定视觉预算下的稀疏成功关键帧 |
| Retrieval-conditioned adaptation | [Retrieval-VLA, CVPR 2026 Findings](https://openaccess.thecvf.com/content/CVPR2026F/papers/Zhang_Retrieval-VLA_Training-Free_In-Context_Adaptation_for_Vision-Language-Action_Models_CVPRF_2026_paper.pdf) | 证明 training-free retrieval 可以帮助 VLA 测试时适应 | 与本文最接近，但仍留下长 rollout 如何压缩、demo/history 如何分配、来源边界与 action-token 机制等问题 |
| 长程 episodic memory | [MemER, ICLR 2026](https://openreview.net/forum?id=1dH4ARGdwD) | 从历史经验选择关键帧，支持分钟级长程机器人任务 | 重点是当前 episode 的长程记忆和分层控制，不是跨任务成功 rollout 对每一步 next action 的直接条件化 |
| 视觉提示与轨迹标记 | [MOKA, RSS 2024](https://www.roboticsproceedings.org/rss20/p062.pdf)、[TraceVLA, ICLR 2025](https://proceedings.iclr.cc/paper_files/paper/2025/hash/8667f264f88c7938a73a53ab01eb1327-Abstract-Conference.html) | 用 keypoint marks 或 visual traces 提供空间与时序结构 | 依赖标记、轨迹渲染或额外微调，没有研究如何自动从普通成功 rollout 选择最小经验 |
| Test-time action scaling | [RoboMonkey, CoRL 2025](https://proceedings.mlr.press/v305/lee25d.html) | 通过多动作采样、扰动、投票和 verifier 改进当前决策 | 使用更多当前动作候选，而不是检索过去成功经验；无法回答 demo 内容如何改变 token prior |
| 多技能后训练合并 | [MergeVLA, CVPR 2026](https://openaccess.thecvf.com/content/CVPR2026/html/Fu_MergeVLA_Cross-Skill_Model_Merging_Toward_a_Generalist_Vision-Language-Action_Agent_CVPR_2026_paper.html) | 缓解 task-specific experts 的参数冲突和不可合并性 | 仍在参数空间整合技能，不是 context-space 的即时经验复用 |

由此得到一个更精确的 gap：

> <span style="color:#c62828"><strong>现有工作分别研究了“如何训练得更强”“如何看完整 demonstration”“如何保留长历史”或“如何增加测试时计算”，但对 frozen autoregressive next-action VLA，仍缺少一个同时处理稀疏成功经验、检索相关性、上下文预算、来源隔离和 action-token 因果机制的统一框架。</strong></span>

## 3. 技术挑战：为什么不能直接把成功图片塞进 Prompt

### 3.1 长轨迹必须压缩

成功 rollout 包含大量冗余帧，不能完整放入上下文。真正有价值的可能是：

- 搜索与首次发现目标；
- 接近与对齐；
- 首次交互或攻击；
- 阶段切换；
- 任务完成前状态。

这要求回答“哪些视觉状态是下一动作预测所需的最小充分经验”。

### 3.2 Demo 与在线历史竞争同一预算

OpenHA 依靠最近视觉动作历史闭环控制。加入 demo 会挤占在线 history；如果
没有 truncation-only 对照，任何提升或下降都可能只是历史长度变化。

### 3.3 相关性与负迁移

不相关成功轨迹会提供错误动作先验。固定同类别经验、属性检索、随机经验和
最远经验必须区分，不能把“有 demo”视为单一方法。

### 3.4 测试时记忆必须有明确来源边界

参数不更新不等于自动具备清晰的泛化边界。测试时 memory bank 的来源、
任务划分和实体划分必须预先定义，否则难以区分跨任务 ICL 与经验复现。
因此，正式实验使用 train-only memory bank，并分别报告 task/entity exclusion
协议下的结果。

### 3.5 普通 imitation-trained/frozen VLA 不保证具备稳定 ICL

[RICL (CoRL 2025)](https://proceedings.mlr.press/v305/sridhar25a.html)
说明，使用普通 imitation objective 训练的 VLA 不会自动获得稳定的
demonstration-conditioned ICL 能力。因此，frozen prompting 必须先被当作
待验证假设；若后续进行 demo-conditioned post-training，也必须与
training-free 结果分开报告。

我们的当前结果给出的是一个更窄、但已经有实验证据支持的命题：
在 OpenHA 上，**某些经过来源控制和选帧的视觉 demonstration 可以提高
rollout success rate（ASR）**；这不等价于证明 OpenHA 或一般 VLA
“天然会 ICL”，也不等价于所有图片 demo 都有效。

「我们目前的结果只有OpenHA吗，next-prediction的vla ICL不能也可以提高ASR吗？」

<span style="color:#c62828"><strong>目前已经完成并有直接证据的是 OpenHA；“next-prediction 的 VLA 也能通过视觉 demonstration ICL 提高 ASR”是我们要验证的跨域研究假设，而不是当前已经证明的结论。</strong>只要目标 VLA 的动作生成是自回归 next-token/next-action prediction，并且输入上下文中包含 observation、history 与 demonstration，就有合理机制认为成功视觉 demo 可能改变 action-token prior，从而提高 ASR。OpenVLA、ECoT 这类模型可以作为后续验证对象；但不能把 flow-matching action chunk 或没有显式 action-token likelihood 的模型直接并入同一个主结论。论文中应将 OpenHA 写成已验证 testbed，将 OpenVLA/ECoT 写成跨域验证，而不是用 OpenHA 结果替代跨域证据。</span>

### 3.6 性能变化不等于模型使用了 Demo

仅有 ASR 不能排除额外图片、prompt 长度或随机扰动。必须固定相同
observation/history，只改变 demo，并分析 token logit、解码动作和行为阶段。

## 4. 核心研究命题

本文研究以下命题：

> **从 train-only 成功 rollout 中检索少量相关视觉状态，并作为
> demonstration 注入 frozen OpenHA，可以调制其 next-action prediction；
> 但收益取决于经验相关性、帧选择和 demo-history 预算平衡。**

这一定义将工作从 Minecraft 特定技巧上升到
**Demonstration-conditioned autoregressive next-action VLA**。

这里的“上升”首先是一个**可检验的研究假设**，不是已经由 OpenHA 单平台
结果证明的普遍结论。要形成跨域主张，至少还需在一个机械臂
autoregressive action-token VLA（OpenVLA 或 ECoT）上验证。π0 的
flow-matching action chunk 与 Octo 的 action head 不属于本文主范式。
具体代码接口与分阶段实验见
`Demonstration_Conditioned_VLA_Transfer_Plan_zh.md`。

OpenHA 是一个适合研究该问题的 testbed：

- 输入同时包含语言、视觉和多步历史；
- 输出为自回归的结构化动作文本；
- 动作最终落到环境执行；
- 可以同时观察任务成功率、动作序列和 CoA/action text；
- Minecraft 提供长时程、部分可观测和多阶段任务。

## 5. 新方法：Sparse Success-Rollout Conditioning

本文提出暂称 **Sparse Success-Rollout Conditioning（SSRC）** 的统一框架。
它不是单一选帧启发式，而是一条从成功经验到 next-action token 的完整链路：

```text
train-only successful rollouts
        -> source-isolated selection
        -> action/state-aware sparse compression
        -> budget-matched step-wise conditioning
        -> autoregressive next-action prediction
        -> token/action causal analysis
```

每个模块对应一个挑战：

| 挑战 | SSRC 模块 | 当前实现 |
| --- | --- | --- |
| 长 rollout 冗余 | sparse rollout compressor | `uniform`、`state`；后续 `phase-balanced` |
| demo 可能不相关 | source selector | `category_fallback` 对照、`attribute_retrieval` |
| demo 挤占在线历史 | budget-matched injector | 固定 16-image budget + `history_trunc_k*` |
| 来源边界与跨任务泛化 | source-isolation guard | train-only pool、exclude task/entity、hash manifest |
| frozen VLA 未必理解 demo | 双轨协议 | 先 frozen ICL，后独立 demo-conditioned post-training |
| ASR 无法解释机制 | causal analyzer | off-policy replay、token/action/phase metrics |

<span style="color:#c62828"><strong>SSRC 的核心不是“增加图片”，而是把成功 rollout 转化为一种有来源约束、有信息压缩、有预算控制、且可进行 token-level 因果验证的 test-time action prior。</strong></span>

需要保持克制：当前 `attribute_retrieval` 和 `state` scorer 仍是第一版手工方法。
若要形成更强的算法贡献，应继续实现 phase-aware compression、动态
query-conditioned retrieval，或学习式 visual-action retriever。

### 5.1 基本形式

在每一步动作预测前注入：

```text
成功轨迹中的 k 个视觉状态
        +
当前 episode 的最近历史
        +
当前 observation
        ↓
OpenHA 预测 next action
```

模型参数保持冻结。

### 5.2 Demo 来源

论文与报告统一使用以下命名：

| 论文名 | 历史代码兼容名 | 含义 |
| --- | --- | --- |
| `category_fallback` | `prefix` | exact task 被排除后，使用固定的同类别 rollout，不做相似度排序 |
| `attribute_retrieval` | `retrieval` | 根据任务属性选择更相关的同类别 rollout |

当前 clean strict 实验排除了相同 task 和相同 entity。因此：

- `category_fallback` 不是 same-task demo；
- `category_fallback` 主要充当**不具备语义检索能力的同类别对照**；
- `attribute_retrieval` 使用 locomotion、attack style、hostility 等属性排序。

<span style="color:#c62828"><strong>论文中不得把 `category_fallback` 描述为“轨迹前缀帧方法”。`prefix` 只作为脚本参数和历史结果目录的兼容名出现。</strong></span>

### 5.3 Rollout 内选帧

在选定一个成功 rollout 后，再决定抽取哪些帧：

| 方法 | 含义 | 主要假设 |
| --- | --- | --- |
| `uniform` | 时间上均匀抽帧 | 粗粒度覆盖整个过程 |
| `state` | 根据动作/状态变化打分 | 关键转折状态比均匀帧更有价值 |
| future `phase-balanced` | 分阶段抽帧 | scan/approach/engage/finish 都应被覆盖 |

### 5.4 上下文预算

OpenHA 当前最多使用 16 张图片：

```text
baseline:       15 history + 1 current = 16
image ICL k=5:   5 demos + 10 history + 1 current = 16
trunc-only k=5:  0 demos + 10 history + 1 current = 11
```

`history_trunc_k5` 与 image-ICL k=5 保留相同的最近 10 步历史，但不加入
demo。因此两者的差异是“是否存在 5 张成功经验图”。

所有 seed 的窗口长度完全相同。seed 只改变环境与 rollout 随机性，
不改变窗口长度。

### 5.5 与相邻方法的实质区别

SSRC 不是把完整 demonstration、长期 episode 历史或人工视觉标记换一个
名字，而是针对部署时成功经验复用所需的联合约束进行设计：

| 能力维度 | 完整轨迹 ICL | Retrieval-VLA | 长程记忆 | 视觉标记 | SSRC |
| --- | --- | --- | --- | --- | --- |
| 冻结基础策略即可测试 | 部分方法需要专门训练 | 是 | 通常含额外模块 | 常需标注或微调 | **是，且与后训练轨分开** |
| 从普通成功 rollout 自动构造 demo | 使用完整 demonstration | 检索数据样本 | 主要使用当前 episode | 否 | **是** |
| 对长 rollout 做动作/阶段感知压缩 | 通常否 | 非核心 | 选取历史关键帧 | 人工构造提示 | **是** |
| 显式控制 demo/history 预算 | 非核心 | 未作为主要变量拆解 | 关注长期记忆容量 | 非核心 | **是** |
| 控制 same-task/entity/test 来源边界 | 依数据设定而异 | 未形成本文所需分级协议 | 非跨任务 memory 问题 | 非核心 | **是** |
| 验证 demo 对 next-action token 的因果影响 | 通常报告成功率 | 主要报告适应性能 | 分析长程任务能力 | 分析空间提示效果 | **off-policy + token/action 分析** |

因此，本文的方法贡献应表述为：

> **SSRC 将“成功 rollout 能否帮助当前动作预测”转化为一个可实施、
> 可审计、可归因的问题：先安全地选择经验，再压缩为稀疏状态，在固定预算
> 下逐步注入，最后验证它是否真正改变了 next-action distribution。**

这也明确了与 Retrieval-VLA 的关系：后者为 training-free retrieval
adaptation 提供了重要证据，SSRC 则进一步聚焦**长时程成功 rollout 的稀疏
压缩、history 竞争、严格来源隔离和 action-token 机制**。最终论文必须用
直接实验比较或协议差异支撑这一定位，不能仅依靠概念措辞。

## 6. 第一层证据：视觉经验是否真的有用

首先建立三个参照：

| 对照 | 目的 |
| --- | --- |
| no-ICL baseline | 测量原始 frozen policy |
| text-ICL baseline | 测量原始任务类型文本 hint |
| history-truncation only | 测量减少历史帧本身的影响 |

然后比较不同 image demonstration。

Stage1/2 的三 seed clean 结果表明：

- text-only ICL 与 no-ICL 表现相同；
- history truncation 通常使性能下降；
- 部分图片 ICL arm 高于同 seed baseline。

这形成一条比“加图后分数上升”更强的证据链：

> history 减少本身没有带来收益，但在保留相同短历史的情况下加入成功
> demo 后，部分策略可以恢复并超过 baseline。

<span style="color:#c62828"><strong>这说明图片 ICL 的收益不能简单解释为“上下文变短后模型更容易推理”。</strong></span>

实验设计：

1. 三个 seeds 配对运行所有 baseline、trunc-only 和 image ICL。
2. 对每个任务计算 image arm 相对 trunc-only 的 paired win/loss。
3. 同时比较 image arm 相对完整 15-history baseline 的净收益。
4. 报告 bootstrap CI 与 McNemar test，而不是只报告平均 ASR。

Stage3 strictness 已在三种 demo-source protocol、三个 seed 和三个候选上
完成。`retrieval_state_3` 在
`same_task_allowed`、`exclude_eval_task` 和 `exclude_eval_task_entity`
下的均值均为 50.57%，是当前最稳定的候选；这说明候选选择不能只依据
早期 18-arm sweep 的单一排名，而应优先依据严格 protocol 下的稳定性。

<span style="color:#c62828"><strong>主论文不需要展示完整的前期 18-arm 探索过程；正文保留 baseline、
history-truncation、严格 source 对照和最终候选，完整探索表放入附录或历史归档。</strong></span>

## 7. 第二层证据：关键不是“有没有 Demo”，而是“什么 Demo”

Stage1/2/3 的结果显示 image ICL 并非普遍有效：

- 部分 arm 提升；
- 部分 arm 与 baseline 相同；
- 部分 arm 下降；
- 不同 seed 的 state 最优 `k` 不一致。

因此论文不应声称：

> 图片越多越好，或者 state 选帧必然优于 uniform。

更有价值的研究结论是：

> **VLA 对 demonstration 存在选择性敏感；经验的相关性、阶段覆盖和
> 上下文代价共同决定收益。**

实验设计：

| 实验 | 科学问题 |
| --- | --- |
| attribute retrieval vs category fallback | 语义相关性是否重要 |
| nearest vs random vs farthest | 检索质量是否与收益单调相关 |
| k=1/3/5 | 经验数量和历史损失如何平衡 |
| uniform vs state vs phase-balanced | 哪类视觉状态真正有指导作用 |
| same-task vs exclude-task/entity | 记忆复用与跨任务泛化的差别 |

## 8. 第三层证据：Demo 如何改变动作链

仅报告 ASR 仍无法说明模型如何利用 demo。论文的机制部分应回答：

> 在相同当前状态下，加入正确或错误 demo 后，OpenHA 的下一步动作分布
> 和后续行为阶段发生了什么变化？

### 8.1 动作级指标

将每一步动作编码为：

```text
a_t = [attack, back, forward, left, right, jump, sprint, sneak,
       use, inventory, pickItem, |camera|]
```

分析：

- action signature；
- 与 demo 的 L1/cosine/JS distance；
- noop ratio；
- camera magnitude；
- action jerk；
- first-attack step；
- attack burst length。

### 8.2 轨迹阶段

把 kill task 粗分为：

```text
scan -> approach -> engage -> finish
```

比较：

- 各阶段动作分布；
- 阶段切换时间；
- demo 与 eval 轨迹的 DTW；
- demo 帧是否覆盖所有关键阶段。

### 8.3 CoA 与结构化输出

分析：

- parser validity；
- move/press/attack 函数比例；
- 输出长度；
- demo-text copying；
- model-text 与实际 raw action 的一致性。

### 8.4 Off-Policy Replay

固定同一 observation/history，分别输入：

- no demo；
- correct retrieval demo；
- random same-category demo；
- farthest/wrong demo；
- shuffled/reversed demo。

然后只比较 next action，不执行环境。

<span style="color:#c62828"><strong>Off-policy replay 是证明 `demo -> action` 因果影响的关键实验，因为它消除了环境状态差异。</strong></span>

## 9. 第四层证据：从简单图片扩展到结构化经验

当前纯图 demo 是必要的第一性 baseline，但不应成为论文终点。它验证的是
“最小视觉 demonstration 注入”是否有行为效应；后续仍需用 action text、
state、reasoning 和 token-level condition 做结构化比较。

后续比较：

| Demo 形式 | 提供的信息 |
| --- | --- |
| image only | 视觉状态 |
| image + raw action | 低层动作对应关系 |
| image + model-text | 结构化 action/CoA 模板 |
| phase-tagged image | 轨迹阶段 |
| marked image | 目标、关键点或 affordance |
| contact sheet | 在固定图片预算下压缩多阶段经验 |

科学问题不是单纯寻找分数最高的格式，而是分解：

- 目标外观是否重要；
- 动作标签是否重要；
- 时序顺序是否重要；
- 阶段结构是否重要。

## 10. 泛化证据：从 Train/Dev 到 TEST_V2

正式 test 前必须：

1. 完成三 seed train/dev。
2. 完成 retrieval strictness。
3. 在 train/dev 上冻结不超过 3 个方法。
4. 固定 source、frame mode、`k`、text level。
5. 确认 TEST_V2 从未进入 demo pool 或 bank。

TEST_V2 只运行一次，不能再用于选择方法。

<span style="color:#c62828"><strong>论文主结论应来自 frozen TEST_V2，而不是当前 kill_entity train/dev 搜索表。</strong></span>

## 11. 跨模型证据：OpenHA 现象是否具有一般性

完成 OpenHA 主线后，跨模型验证分为“同环境训练范式变化”和“跨域
action-token VLA”两层：

- 在 LoRA-SFT OpenHA 上验证 frozen top arm；
- 报告 CrossHA bare 作为 SOTA reference；
- 采集 CrossHA 自己的 train-only 成功 rollout；
- 在 CrossHA 上测试相同 ICL 原则。
- 在 OpenVLA 或 ECoT 上实现相同的 demo/history 分段接口；
- 使用机械臂 train demonstrations 建立 memory bank，并在 held-out
  instruction、object 或 scene 上评估。

可能出现两种有价值的结论：

1. CrossHA+ICL 仍提升：说明 test-time visual experience conditioning
   可以跨 SFT/RL 训练范式泛化。
2. CrossHA+ICL 不提升：说明 GRPO 可能已经内化了阶段先验，或者强策略
   对外部 demo 的敏感度更低。

因此 CrossHA 不是必须“提升才有价值”的实验，而是用于确定方法边界。

OpenVLA/ECoT 验证承担更强的外部有效性：如果稀疏视觉动作经验也能改变
机械臂 action token 并提高 held-out success，才能将结论从 Minecraft
testbed 推广为 demonstration-conditioned autoregressive next-action VLA。

## 12. 建议的论文贡献

### Contribution 1：问题定义

提出 **demonstration-conditioned autoregressive next-action VLA** 问题：
研究 frozen policy 能否在部署时将过去成功 rollout 直接转化为当前
next-action prior，而不是只能通过重新训练吸收经验。

### Contribution 2：SSRC 方法框架

提出 SSRC，将 source-isolated retrieval、action/state-aware sparse
compression、budget-matched step-wise injection 连接为统一链路，并系统
拆解 demo source、frame selection、`k` 和 history trade-off。

### Contribution 3：来源隔离的 VLA ICL 协议

明确区分：

- same-task memory；
- leave-one-task-out；
- leave-one-entity-out；
- held-out test。

并提供 pool manifest、split assertion 和 run-config hash。

### Contribution 4：机制证据

使用 action-vector、phase alignment、CoA/parser metrics 和 off-policy
replay，在固定 observation/history 下验证 visual demo 是否改变
action-token likelihood、结构化动作和行为阶段，而不只报告 ASR。

当前 fixed-prefix pilot 已观察到两层证据：第一，改变 demonstration 条件
会改变同一 action string 的 teacher-forced likelihood；第二，在
phase-aware 前缀上出现少量离散 decoded-action flip，且 flip 率依赖行为阶段。
但这还不是完整因果结论：成功 rollout 中记录的 next action 不是 oracle action
GT，success demo 对该 reference 的总体提升尚未达到稳定证据。因此论文应将
机制主张写成“phase-dependent action-prior modulation”，并在更大、
phase-balanced 的 paired replay 上验证是否与正确行为方向一致。

### Contribution 5：边界与迁移验证

比较 bare OpenHA、LoRA-SFT OpenHA 和 RL-trained CrossHA，并在 OpenVLA
或 ECoT 上进行跨域 action-token 验证，分析何种策略会利用外部经验、何种
策略已经内化或忽略该先验。

## 13. 论文主线的一句话版本

> <span style="color:#c62828"><strong>经过严格来源隔离、相关检索和预算控制的成功视觉经验，可以在不更新参数的情况下调制冻结 OpenHA 的下一步动作预测；真正重要的不是“更多图片”，而是稳定、相关且能改变动作先验的 demonstration。</strong></span>

## 13.1 第二层故事：从 Frozen ICL 到 Visual OPSD

当前论文不能只停留在“把成功图片放进 prompt 后，OpenHA 的动作分布发生了
变化”。更有价值的后续问题是：

> **如果 privileged success demonstration 能让 teacher 产生更好的
> next-action prior，能否把这个 prior 蒸馏进一个部署时不再看 demo 的
> OpenHA student？**

这形成一个清晰的两层故事：

```text
第一层：context-space adaptation
successful rollout
        -> source-isolated sparse demo
        -> frozen OpenHA + demo
        -> next-action prior modulation

第二层：parameter-space internalization
frozen OpenHA + demo teacher
        -> action/CoA token distillation
        -> no-demo OpenHA student
        -> deployment-time prior internalization
```

### 为什么 OPSD 不能直接替代 Frozen ICL

OPSD 与当前图片 ICL 回答的是不同问题：

| 层次 | 模型参数 | 部署时是否看 demo | 要回答的问题 |
| --- | --- | --- | --- |
| Frozen ICL | 不更新 | 是 | 成功经验能否即时改变 next-action prediction |
| OPSD teacher | 不更新 | 是 | privileged demo 是否真的提供更好的 action prior |
| OPSD student | 更新 LoRA/adapter | 否 | demo 带来的 prior 能否被模型参数内化 |

因此，Frozen ICL 是 OPSD 的必要 teacher-side 证据：如果 demo 在固定
observation/history 下不能稳定改变 action-token、action-vector 或闭环行为，
直接训练 student 只会变成普通后训练或 self-imitation，无法证明是
demonstration prior 的蒸馏。

### OPSD 的严格定义

```text
student query prefix = 当前 observation + online history
teacher query prefix  = 当前 observation + online history + success demo

teacher: frozen OpenHA，输出 action/CoA token distribution
student: same OpenHA initialization，输入不含 demo
training: update student LoRA/adapter
deployment: student 不看 demo
```

teacher 和 student 使用相同的 OpenHA 基座。区别不是 teacher 更强或拥有
额外环境状态，而是 teacher 额外获得 train-only、来源隔离的成功
demonstration。这样才能把 student 的收益归因于 demo-conditioned teacher
提供的 prior，而不是模型规模或额外 privileged state。

「OPSD是同一个student和teacher model，相同的基础模型跑一些训练的数据 有一些图像demo，这些对于student model能够去蒸馏，然后跑测试集 会把分给跑高（相较于蒸馏前后）——我们的思路是这个吗；以及这个是传统的OPSD吗？（传统的是不是要相同的数据集）」

<span style="color:#c62828"><strong>总体思路是这个，但需要补上“teacher 与 student 看到的 prefix 不同”和“teacher 是否在 student 自己访问的状态上提供监督”这两个条件。</strong>我们的设定是：teacher 和 student 使用同一个 OpenHA/Qwen2-VL 基座；teacher 额外看到 train-only success visual demo，student 不看 demo；teacher 的 action/CoA token 分布用于更新 student LoRA；最后在不提供 demo 的 held-out task 上比较蒸馏前后的 student。</span>

<span style="color:#c62828"><strong>不过，当前 OPSD-2 还不是最严格的 traditional on-policy OPSD。</strong>当前实现是 fixed-prefix replay 上的 offline token-level distillation：teacher logits 被离线缓存，student 在相同的 replay prefix 上训练。它已经是真正的 token-level teacher-to-student KL，而不是普通 action-label SFT，但还没有让 student 先在环境中自主 rollout，再让 teacher 在 student 实际访问的 prefix 上在线复核。因此，当前更准确的名称是 **offline demonstration-conditioned self-distillation / OPSD-2**；真正的 online Visual OPSD 应放在 OPSD-3。</span>

<span style="color:#c62828">传统 OPSD 不要求 train/test 必须是完全相同的数据集，也不要求 teacher 使用外部更大的模型。关键是同一模型在 privileged context 与普通 context 下扮演 teacher/student，并将 teacher 的 dense token distribution 蒸馏给 student；若强调 on-policy，还必须使用 student 自己访问的 prefix。数据可以来自同一任务分布，但 demo、student prefix、held-out evaluation 必须有明确的来源隔离，不能把测试任务或测试 rollout 混入 teacher memory。</span>



「我们现在训练的是什么基座？OPSD-3才开始真正训基座吧」

<span style="color:#c62828"><strong>目前训练的是 OpenHA 的 Qwen2-VL-7B 基座上的 LoRA student，不是从 OPSD-3 才开始训练。</strong>原始基座路径是 `/data3/openha_repro/models/minecraft-openha-qwen2vl-7b-2509`；teacher 始终冻结，student 使用同一基座初始化并训练 LoRA adapter。OPSD-0 是 4-step 可训练性 smoke；OPSD-1 是 60 train + 4 eval 的 pseudo-label CE student；OPSD-2 是 60 条 train prefix、离线 teacher full logits 和 token-level KL student。</span>

<span style="color:#c62828"><strong>OPSD-3 的新增点不是“第一次训练基座”，而是第一次把 student 的真实在线 rollout 引入 teacher 纠正闭环。</strong>最小 OPSD-3A 应该是：student 不看 demo 在环境中 rollout，记录自己访问的 prefix；teacher 在完全相同的 prefix 上额外看 success demo 并输出 logits；再用这些 online teacher targets 更新 student LoRA。默认仍然不需要 full-model fine-tuning；只有在 LoRA student 已经证明有效后，才有理由比较 full-parameter tuning。</span>



「我们具体是如何让老师模型去给学生模型进行打分、纠偏的呢？对于图像demo对next-action vla动作轨迹的这个纠偏具体是如何进行的？」



<span style="color:#c62828"><strong>核心不是让 teacher 给整条轨迹输出一个标量分数，而是让 teacher 和 student 在同一个 query prefix 上分别输出“下一段 CoA/action token 的概率分布”，再用 teacher 分布对 student 分布做逐 token 纠偏。</strong>设当前 prefix 为 \(x_t\)，它包含 instruction、当前 observation 和 online history；成功视觉 demo 为 \(d\)。则：

```text
student: p_S(y_j | x_t)
teacher: p_T(y_j | x_t, d)
```

其中 \(y_j\) 是第 \(j\) 个 CoA/action token。teacher 的 demo 不是额外的环境真值，而是 privileged context；它帮助同一个 OpenHA 在当前状态下形成更有利的 action prior。</span>

<span style="color:#c62828"><strong>“打分”主要有三种形式：</strong>

1. **token NLL / log-likelihood**：比较 teacher 或 student 对目标 action token 的平均负对数似然；
2. **teacher-to-student KL**：直接比较两个完整词表分布，\(\mathrm{KL}(p_T \| p_S)\)；
3. **结构化动作检查**：把生成文本解析为 `move/press/attack/use/camera` 等离散动作，检查 parser validity、动作 flip、attack onset、camera magnitude 和 phase 是否合理。

当前 OPSD-2 实际使用的是第二种：teacher logits 离线缓存，student 在 action/CoA target token 上计算 token-level KL；teacher stop-gradient，梯度只更新 student LoRA。当前代码**没有把 teacher 输出压缩成一个 scalar reward，也没有实现显式 confidence filtering 或 action override**。</span>

<span style="color:#c62828"><strong>纠偏的数学形式是：</strong>

```text
L_OPSD = Σ_t Σ_j w_tj · KL(
    p_teacher(y_j | x_t, demo)
    ||
    p_student(y_j | x_t)
)
```

最小实现中 \(w_{tj}=1\)，只在 assistant 的 CoA/action token 上计算；更完整的 OPSD-3 可以让 \(w_{tj}\) 由 teacher confidence、parser validity 和行为 phase 决定。反向传播后，student 会提高 teacher 偏好的 token 概率、降低与 teacher 分布不一致的 token 概率。</span>

<span style="color:#c62828"><strong>图像 demo 对动作轨迹的“纠偏”不是直接把 demo 轨迹复制到当前环境。</strong>例如当前 student 在 query image 中没有锁定目标，预测：

```text
Action: move(0, 0) and press()
```

而 teacher 在看到 success demo 后认为当前状态应继续接近并攻击，分布更偏向：

```text
Action: move(1, 0) and press(attack)
```

那么蒸馏目标会把 student 的 next-action distribution 从前一种 prior 推向后一种 prior。demo 提供的是“搜索—接近—对齐—攻击”的阶段模板，而不是要求 student 在当前状态逐帧复现 demo 的 camera 或 movement 数值。</span>

<span style="color:#c62828"><strong>当前 OPSD-2 只完成了 offline fixed-prefix 纠偏：</strong>prefix 来自 full29 replay，teacher logits 先离线计算，student 再学习这些 logits；它证明了工程上的 teacher-to-student token distillation，但尚未证明 teacher 在 student 自己犯错的在线状态上纠正了 student。真正的 OPSD-3A 应改为：student 先自主 rollout，teacher 在 student 实际访问的同一 prefix 上加入 success demo 并重新打分，再用这些 online logits 更新 student。</span>



### OPSD 的监督层级

OPSD 需要区分三种强度，避免把 pseudo-label self-training 误称为严格
distillation：

| 版本 | teacher 输出 | student 目标 | 论文表述 |
| --- | --- | --- | --- |
| OPSD-lite | action/CoA text | 交叉熵拟合 teacher 文本 | pseudo-label self-distillation |
| action-level OPSD | action-token logits | action token KL | strict action-token OPSD |
| CoA+action OPSD | CoA 与 action logits | 分层 token KL | reasoning/action prior internalization |

当前最合理的实验顺序是先做 OPSD-lite smoke/pilot，再决定是否实现离线
teacher-logit cache 的严格版本。对于 OpenHA，优先蒸馏低层 action tokens；
CoA 蒸馏作为第二个 loss ablation，而不是一开始同时优化所有输出格式。

### OPSD 必须证明的因果链

```text
success rollout
        -> teacher sees relevant success demo
        -> teacher changes action prior
        -> student learns teacher action/CoA distribution
        -> student deploys without demo
        -> held-out task success improves
```

因此 OPSD 的核心比较不是 teacher 与 student 的输出相似度，而是：

1. frozen no-demo OpenHA；
2. frozen demo teacher；
3. ordinary self-imitation SFT；
4. OPSD-lite student；
5. strict token-level OPSD student。

还必须加入 `negative_demo`、`category_demo`、shuffled demo 和 demo dropout。
如果 success demo teacher 有效，但 OPSD student 不优于 ordinary
self-imitation，结论应限定为：**demo 是有效的 privileged inference
context，但其 prior 尚未被 OpenHA 稳定内化。**

### 当前证据与论文位置

目前第一层已经完成 full29 fixed-prefix replay，支持
demonstration-induced action-prior modulation。OPSD-0 的 LoRA smoke 也已
跑通：student loss 可以下降、adapter 可以保存/加载，并能在 no-demo 输入
下生成 OpenHA 风格 action/CoA 文本。但这只是工程可训练性证据，尚未运行
OPSD-1 efficacy pilot，更不能声称 student 已经在 held-out 任务上保留了
teacher 的收益。

因此论文故事应采用：

- **主线结果：** SSRC/frozen demonstration-conditioned OpenHA；
- **深入机制：** demo 如何调制 action-token、结构化动作和行为 phase；
- **第二层扩展：** Visual OPSD，已完成 OPSD-0 可训练性验证，下一步检验
  action prior 能否被参数内化；
- **准入条件：** 只有 no-demo student 在 held-out task 上优于 frozen
  no-demo 和 ordinary self-imitation，OPSD 才升级为主贡献。

如果 OPSD 成功，最终论文可以从“test-time experience conditioning”
上升为：

> **成功 rollout 先在 context space 中提供 privileged action prior，
> 再通过 Visual OPSD 被内化为不依赖 demonstration 的 next-action VLA
> policy。**

如果 OPSD 不成功，论文仍然成立，但应诚实地将结论限定为：
**OpenHA 能在推理时使用外部视觉经验，但标准参数更新尚未证明能够稳定
吸收这一经验。**

### ICL 与 RSI：不是每一步换 demo，而是按迭代轮次更新经验

Stage1–3 的不稳定性本身构成了 RSI 的动机，但 RSI 不应被设计成
“不断试不同 demo，直到 held-out 分数变好”。更严格的定义是：

```text
M_r = 第 r 轮 student checkpoint
D_r = 由 M_r 产生、经过固定质量门筛选的 success-demo bank

M_r rollout
    -> 生成 D_r
    -> teacher = M_r + D_r
    -> student = M_r without demo
    -> on-policy OPD / LoRA update
    -> candidate M_{r+1}
    -> train/dev gate
```

需要区分两个时间尺度：

- **episode 内：**demo 选择一次并固定；每次 VLM request 可以复用同一 demo，
  但不应根据当前一步 action 重新随机替换 demo。
- **RSI 外层迭代：**checkpoint 更新后，重新 rollout、重新筛选成功经验、
  重新抽取帧，得到下一轮 `D_{r+1}`。

成功 rollout 不是永久固定的，但也不是无限在线漂移。每轮只保留：

1. 环境 success；
2. train-only 来源；
3. parser/action 合法；
4. phase 覆盖充分；
5. 去除损坏和高度重复轨迹。

`negative_demo`、`category_demo` 和 shuffled demo 不应被“清洗掉”，它们应
保留为反事实对照。teacher 质量则通过 confidence、parser validity 和 phase
weighting 控制蒸馏权重，而不是靠反复试验删除所有困难样本。

### OPSD-3A 与 OPSD-3B 的关系

**OPSD-3A 是 Visual OPSD 的核心最终版本：**

```text
student 自己 rollout
    -> teacher 在同一 student prefix 上看 success demo
    -> teacher logits
    -> student LoRA update
    -> 环境中仍执行 student action
```

**OPSD-3B 是可选的 interactive correction 扩展：**teacher 可以 override
当前 action 或提供 recovery label，更接近 DAgger/intervention。它不是
3A 的必要组成；如果 3A 和 3B 混在主实验中，就无法区分“student 学到了
teacher prior”和“teacher 直接替 student 执行”的贡献。

### ICL 与 RSI 的统一指标

定义：

```text
ICL_gain_r
  = SR(M_r, D_r) - SR(M_r, no-demo)

Internalization_gain_r
  = SR(M_{r+1}, no-demo) - SR(M_r, no-demo)

Residual_ICL_gain_r
  = SR(M_{r+1}, D_r) - SR(M_{r+1}, no-demo)

Internalization_ratio_r
  = Internalization_gain_r / ICL_gain_r
```

解释：

- `ICL_gain`：demo 在 context space 中的即时收益；
- `Internalization_gain`：student 脱离 demo 后保留的收益；
- `Residual_ICL_gain`：新 student 仍然依赖 demo 的程度；
- `Internalization_ratio`：demo 收益有多少被写入参数。

论文中应同时报告 `SR`、first-attempt success、action-token NLL/KL、
parser validity、demo copying、anchor-task retention、每轮新增成功 rollout
数和每轮计算成本。这样 ICL 与 RSI 的关系就从概念叙事变成可测量的指标链。

完整因果链可以压缩为：

```text
后训练成本高，完整 demonstration 太长，普通图片提示缺少动作结构
        ↓
成功 rollout 有价值，但存在冗余、负迁移、history 竞争和来源边界
        ↓
SSRC：安全检索 + 稀疏压缩 + 固定预算逐步注入
        ↓
成功率证据 + truncation 对照 + retrieval strictness
        ↓
off-policy token/action shift 证明模型确实使用了 demo
        ↓
CrossHA 与 OpenVLA/ECoT 验证适用边界和跨域迁移
```

## 14. 推荐论文结构

1. Introduction：为什么 frozen VLA 需要 test-time experience adaptation。
2. Related Work：VLA、ICL、retrieval memory、embodied reasoning。
3. Method：visual experience construction、retrieval、keyframes、budget。
4. Source-Isolated Protocol：split、strict exclusion、frozen test。
5. Main Results：三 seed OpenHA clean results。
6. Analysis：relevance、`k`、history、state/phase selection。
7. Mechanism：action shift、phase alignment、off-policy replay。
8. Generalization：LoRA-SFT OpenHA 与 CrossHA。
9. Visual OPSD：teacher/student、action-token distillation 与 no-demo
   deployment（仅在 OPSD 准入条件满足时进入主文）。
10. Limitations：Minecraft 范围、手工属性 retrieval、context cost。

## 15. 建议图表

| 图表 | 内容 |
| --- | --- |
| Figure 1 | 成功 rollout -> retrieval/keyframes -> OpenHA next action |
| Figure 2 | demo-history 固定 16-image budget |
| Table 1 | 三 seed clean 主结果 |
| Table 2 | same-task / exclude-task / exclude-entity |
| Figure 3 | retrieval similarity 与 ASR |
| Figure 4 | action-vector 和 first-attack 分布 |
| Figure 5 | 固定 observation 的 off-policy next-action shift |
| Table 3 | image/raw/model-text/marked-image |
| Table 4 | OpenHA、LoRA-SFT、CrossHA 对比 |
| Appendix/Table 5 | OpenVLA 或 ECoT 的跨域 autoregressive action-token 验证 |

## 16. 需要避免的叙事

- 不把未完成正式准入的探索性数字放进论文主结果。
- 不把 seed42 的 65.52% 当成最终性能。
- 不声称所有图片 ICL 都提升。
- 不声称 state 必然优于 uniform。
- 不声称更大的 `k` 必然更好。
- 正文只使用 `category_fallback`；仅在复现说明中注明 legacy alias `prefix`。
- 不把 CrossHA 写成主线方法。
- 不把尚未运行或未通过准入条件的 OPSD 写成已经完成的参数内化结果。
- 不仅依赖 ASR，而缺少动作与 CoA 机制证据。
- 不笼统声称既有方法失败；应准确写成它们未联合覆盖本文约束。
- 在 phase-aware 或 learned retrieval 完成前，不把手工 scorer 夸大为成熟算法。

## 17. 顶会参考文献与本文关系

| 工作 | 会议 | 对本文的直接支撑 |
| --- | --- | --- |
| [OpenVLA](https://proceedings.mlr.press/v270/kim25c.html) | CoRL 2024 | 开源 autoregressive action-token VLA 基座及参数高效适配基线 |
| [ECoT](https://proceedings.mlr.press/v270/zawalski25a.html) | CoRL 2024 | 展示 reasoning/action token 联合建模，可用于分析 demo 对推理链与动作的影响 |
| [ICRT](https://arxiv.org/abs/2408.15980) | ICRA 2025 | 证明机器人策略可以利用多条 sensorimotor demonstration 进行上下文适配 |
| [RICL](https://proceedings.mlr.press/v305/sridhar25a.html) | CoRL 2025 | 说明普通 imitation learning 不必然产生 ICL，支持 frozen/post-trained 双轨协议 |
| [Retrieval-VLA](https://openaccess.thecvf.com/content/CVPR2026F/papers/Zhang_Retrieval-VLA_Training-Free_In-Context_Adaptation_for_Vision-Language-Action_Models_CVPRF_2026_paper.pdf) | CVPR 2026 Findings | 最接近的 training-free retrieval-conditioned VLA 工作，构成核心比较对象 |
| [MemER](https://openreview.net/forum?id=1dH4ARGdwD) | ICLR 2026 | 支持关键帧 episodic memory 对长时程机器人控制有价值 |
| [MOKA](https://www.roboticsproceedings.org/rss20/p062.pdf) | RSS 2024 | 支持结构化视觉提示可改变机器人动作预测 |
| [TraceVLA](https://proceedings.iclr.cc/paper_files/paper/2025/hash/8667f264f88c7938a73a53ab01eb1327-Abstract-Conference.html) | ICLR 2025 | 支持在 VLA 中显式编码运动轨迹，但也体现额外监督/微调路线 |
| [RoboMonkey](https://proceedings.mlr.press/v305/lee25d.html) | CoRL 2025 | 代表 test-time action sampling/scaling，与经验检索形成正交比较 |
| [MergeVLA](https://openaccess.thecvf.com/content/CVPR2026/html/Fu_MergeVLA_Cross-Skill_Model_Merging_Toward_a_Generalist_Vision-Language-Action_Agent_CVPR_2026_paper.html) | CVPR 2026 | 代表参数空间技能整合，反衬本文 context-space 即时经验复用 |

这些工作共同支持研究动机，但**不会自动证明 SSRC 的新颖性或有效性**。
最终主张仍必须依赖严格 baseline、直接方法比较、三 seed 结果、冻结测试集和
机制实验。
