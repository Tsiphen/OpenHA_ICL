# OpenHA 图片 ICL：论文级科研计划与 Clean 结果

> **文档状态：正式实验协议与论文候选结果的权威版本**  
> 更新日期：2026-09-19  
> 本文件只维护预先定义的正式实验协议、候选结果和当前进度；
> 未纳入正式准入的探索性运行另行存档，不参与论文结论。

---

## 1. 研究定位

本项目研究 **Demonstration-conditioned autoregressive next-action
VLA**：从成功 rollout 中提取少量视觉状态，在不更新参数的情况下
注入冻结策略的上下文，研究 demonstration 是否能够系统性地调制
自回归动作 token 流和当前控制步的下一动作预测。

范围定义：

- 每个控制步由多模态自回归模型生成结构化 action text 或离散 action tokens；
- 核心对象包括 OpenHA、CrossHA、OpenVLA 和 ECoT；
- π0 的 flow-matching action chunk、Octo 的 action-head policy 不属于主范围；
- π0-FAST 虽然自回归生成 tokenized action chunk，但不是单步 next-action，
  只作为相邻工作。

主要研究对象：

- bare OpenHA，冻结 Qwen2-VL-7B；
- 推理期注入图片 demonstration；
- 主实验不进行参数更新。

辅助验证：

- LoRA-SFT OpenHA：验证方法鲁棒性；
- CrossHA bare：作为 SOTA reference；
- CrossHA+ICL：验证方法能否跨训练范式迁移，不作为当前主方法。
- OpenVLA 或 ECoT：作为机械臂 autoregressive action-token VLA 的跨域验证。

论文的目标结论是：

> <span style="color:#c62828"><strong>经过合理检索的 demonstration 可以调制冻结 autoregressive VLA 的 action-token 分布并改善 next-action prediction，但效果依赖 demo 表示、检索质量、上下文预算和严格来源隔离的评估协议。</strong></span>

## 2. 正式结果准入规则

只有同时满足以下条件的实验，才能进入本文件的正式结果表：

- demo pool 只包含 train 任务；
- retrieval bank 中每条记录都有已知 split；
- demo pool 和 bank 中不存在任何 TEST_V2 任务；
- 开启 `exclude_eval_task=true`；
- 对 `kill_entity` 开启 `exclude_eval_entity=true`；
- 保存 run config、task list 和数据来源 hash；
- 所有任务均以 `rc=0` 完成，且 `missing=0`；
- 明确记录随机种子。

> <span style="color:#c62828"><strong>任何不满足上述条件或早于协议修复的结果，必须放入探索性归档，不能进入论文主表。</strong></span>

## 3. 方法定义

OpenHA 原本根据 instruction、当前 observation 和滚动视觉动作历史预测下一步
动作。我们在上下文前加入 `k` 组 demonstration：

```text
(demo image -> optional demo action text) x k
instruction + history + current observation -> next action
```

核心变量：

| 变量 | 取值 |
| --- | --- |
| demo source | `category_fallback`、`retrieval`（代码兼容名仍为 `prefix`） |
| frame mode | `uniform`、`state` |
| demo 数量 | `k=1,3,5` |
| demo text | 当前为 `none`；后续比较 `raw`、`model-text` |
| base policy | bare OpenHA；后续验证 LoRA-SFT OpenHA、CrossHA |

当前设置最多允许 16 张 prompt 图片。加入 `k` 张 demo 后，历史帧从 15
缩短为 `15-k`。因此，必须使用 history-truncation-only arm 排除“仅仅缩短
历史窗口”造成的混淆。

## 4. Stage0：协议锁定

Stage0 已经完成。

| 检查项 | 实际结果 | 状态 |
| --- | --- | --- |
| train-only pool | 67 个 train 任务，109 个完整 rollout | 通过 |
| TEST_V2 任务进入 demo pool | 0 | 通过 |
| unknown split 任务 | 0 | 通过 |
| retrieval bank | 17 条，全部为 `split=train` | 通过 |
| Stage2 离线 demo 覆盖 | 12 个 arms 均为 29/29 且满 k | 通过 |
| 运行配置与来源 manifest | 已保存并可复核 | 通过 |

权威路径：

- Pool：`/data3/openha_evo/eval/icl_success_pool/00_original_icl_trainonly`
- Bank：`/data3/openha_evo/eval/icl_memory_bank/kill_entity_bank.json`
- Stage0 manifest：`/data3/openha_evo/stage0_protocol/pool_manifest_trainonly.json`
- Clean runner：`/data3/openha_evo/probe_stage12_clean.py`
- Clean results：`/data3/openha_evo/probe_stage12_clean`

## 5. 当前执行状态

截至 2026-09-17（北京时间）：

| 实验范围 | 状态 |
| --- | --- |
| seed42 Stage1 | 5/5 arms 完成 |
| seed42 Stage2 | 12/12 arms 完成 |
| seed43 Stage1 | 5/5 arms 完成 |
| seed43 Stage2 | 12/12 arms 完成；18 个 missing 已全部补齐 |
| seed44 Stage1 | 5/5 arms 完成 |
| seed44 Stage2 | 12/12 arms 完成 |
| Stage1/2 总进度 | **51/51 arms 均满足 29/29、`missing=0`，100% 完成** |
| Stage3 正式 strictness | **9/9 个 seed×协议组合完成，27/27 个 arm 完成；均 `missing=0`** |
| Stage4-A 动作轨迹描述 | **783 条 rollout 已完成；描述性分析，不是 fixed-prefix 因果证据** |
| Stage4-B fixed-prefix replay | **full29 phase-balanced replay 已完成；进入 action-vector 与闭环验证** |
| Stage11 Visual OPSD | **OPSD-0 LoRA smoke 已完成；OPSD-1 efficacy pilot 尚未启动** |

当前续跑配置：

- Stage3 正式队列：`/data3/openha_evo/probe_stage3_strict`
- 新实验项目目录：`/data3/tsiphen/ICL-OpenHA`
- Stage3 聚合报告：`/data3/tsiphen/ICL-OpenHA/stage3_aggregate`
- Stage4-A 动作分析：`/data3/tsiphen/ICL-OpenHA/stage4_mechanism/descriptive_actions`
- Stage4-B replay 代码与结果：`/mnt/yrfs/tsiphen/ICL-OpenHA/stage4_mechanism/fixed_prefix_v1`
- Stage4-B v3 paired analysis：
  `pilot_v3_recorded_action_3tasks_analysis.md`
- Stage4-B phase-aware pilot paired analysis：
  `pilot_phase_seed42_3tasks_analysis.md`
- Stage3 使用 seeds：42、43、44；protocol：
  `same_task_allowed`、`exclude_eval_task`、`exclude_eval_task_entity`
- Stage3 主队列与 repair 队列均已退出；9 个 `probe_summary.json` 和
  9 个 `repair_summary.json` 均已生成。
- 所有 27 个 arm 均满足 `rc=0`、`total=29`、`missing=0`；
- Stage3 运行使用 GPU1/GPU3，GPU2 因已有 VLLM 服务占用而未使用。
- 正式 Stage3 结果只认 `/data3/openha_evo/probe_stage3_strict` 及其聚合产物；
  其他运行目录不进入正式 Stage3 结果表。
- 完成判据：`rc=0` 不是充分条件；每个 arm 必须同时满足
  `total=29`、`missing=0`。seed43 完成后需自动补跑缺失任务。
- 已定位缺失根因：服务器根分区 `/` 使用率 100%，Java/Malmo 日志出现
  shared-memory temp file 与 GLFW 初始化失败。清理根分区或显式将 Java
  temp/Xvfb 临时目录迁到 `/data3` 后，才能补跑缺失项。
- 2026-09-07 已将 `java.io.tmpdir`、`TMPDIR` 和 `XDG_RUNTIME_DIR`
  显式迁到 `/data3/openha_runs/zengqifen/tmp/<arm>`；repair monitor 已完成
  seed43/44 全部缺失检查与补跑。日志为
  `/data3/openha_evo/logs/repair_stage12_seed43_44.nohup`。
- 同日启动的第二个 GPU 2 worker 已补齐 seed43 的 18 个 missing；
  `repair_summary_seed43.json` 中所有 arms 均为 `complete=true`。
- `repair_summary_seed43-44.json` 共34个 entries，全部
  `complete=true`，无 unresolved arm。
- 服务器根分区已从100%回落至96%；`/data3` 仍有约2.5TB可用。

## 6. Stage1：Clean Baseline 与 Sanity Controls

以下结果均满足 clean 协议。

| Arm | Seed | ASR | 成功数 | Missing | 状态 |
| --- | ---: | ---: | ---: | ---: | --- |
| `baseline_no_icl` | 42 | 34.48% | 10/29 | 0 | 完成 |
| `baseline_text_icl` | 42 | 34.48% | 10/29 | 0 | 完成 |
| `history_trunc_k1` | 42 | 24.14% | 7/29 | 0 | 完成 |
| `history_trunc_k3` | 42 | 34.48% | 10/29 | 0 | 完成 |
| `history_trunc_k5` | 42 | 31.03% | 9/29 | 0 | 完成 |
| `baseline_no_icl` | 43 | 44.83% | 13/29 | 0 | 完成 |
| `baseline_text_icl` | 43 | 44.83% | 13/29 | 0 | 完成 |
| `history_trunc_k1` | 43 | 27.59% | 8/29 | 0 | 完成 |
| `history_trunc_k3` | 43 | 31.03% | 9/29 | 0 | 完成 |
| `history_trunc_k5` | 43 | 34.48% | 10/29 | 0 | 完成 |
| `baseline_no_icl` | 44 | 27.59% | 8/29 | 0 | 完成 |
| `baseline_text_icl` | 44 | 41.38% | 12/29 | 0 | 完成 |
| `history_trunc_k1` | 44 | 41.38% | 12/29 | 0 | 完成 |
| `history_trunc_k3` | 44 | 31.03% | 9/29 | 0 | 完成 |
| `history_trunc_k5` | 44 | 34.48% | 10/29 | 0 | 完成 |

阶段性结论：

- seed42、43 中 text-only ICL 与 no-ICL 相同；seed44 中 text-only 高
  13.79 pp。三 seed 均值分别为 40.23% 与 35.63%，但差异由 seed44 驱动，
  必须通过逐任务配对统计判断。
- history truncation 的三 seed 均值为 k1 31.03%、k3 32.18%、k5 33.33%，
  均低于 text baseline 均值；但 seed44 k1 与 text baseline 相同。
- 图片 ICL 必须与同 seed 的 text baseline 配对比较。

> <span style="color:#c62828"><strong>三 seed 结果继续反对“缩短历史本身普遍带来收益”，但 text/no-ICL 差异也存在 seed 方差，最终结论必须依赖逐任务配对检验。</strong></span>

## 7. Stage2：Clean 图片 ICL

三个 seed 已全部完成。三 seed text baseline 均值为40.23%。

| Arm | Seed42 | Seed43 | Seed44 | Mean | SD | Δ vs text |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `category_fallback_uniform_1` (`prefix_uniform_1`) | 37.93% | 44.83% | 58.62% | 47.13% | 10.53 | +6.90 pp |
| `category_fallback_uniform_3` (`prefix_uniform_3`) | 44.83% | 44.83% | 44.83% | 44.83% | **0.00** | +4.60 pp |
| `category_fallback_uniform_5` (`prefix_uniform_5`) | 44.83% | 48.28% | 34.48% | 42.53% | 7.18 | +2.30 pp |
| `category_fallback_state_1` (`prefix_state_1`) | 41.38% | 34.48% | 51.72% | 42.53% | 8.68 | +2.30 pp |
| `category_fallback_state_3` (`prefix_state_3`) | 48.28% | 37.93% | 34.48% | 40.23% | 7.18 | +0.00 pp |
| `category_fallback_state_5` (`prefix_state_5`) | 41.38% | 51.72% | 41.38% | 44.83% | 5.97 | +4.60 pp |
| `retrieval_uniform_1` | 65.52% | 41.38% | 31.03% | 45.98% | 17.70 | +5.75 pp |
| `retrieval_uniform_3` | 34.48% | 37.93% | 41.38% | 37.93% | 3.45 | -2.30 pp |
| `retrieval_uniform_5` | 48.28% | 51.72% | **62.07%** | **54.02%** | 7.18 | **+13.79 pp** |
| `retrieval_state_1` | 34.48% | 37.93% | 41.38% | 37.93% | 3.45 | -2.30 pp |
| `retrieval_state_3` | 55.17% | 51.72% | 48.28% | **51.72%** | **3.45** | **+11.49 pp** |
| `retrieval_state_5` | 51.72% | 34.48% | 51.72% | 45.98% | 9.95 | +5.75 pp |

探索性逐任务配对结果，共87个 seed-task pairs：

| 对比 | Win/Loss/Tie | Δ | Exact McNemar p |
| --- | --- | ---: | ---: |
| `retrieval_uniform_5` vs text baseline | 19/7/61 | +13.79 pp | 0.02896 |
| `retrieval_uniform_5` vs `history_trunc_k5` | 26/8/53 | +20.69 pp | 0.00294 |
| `retrieval_uniform_5` vs `category_fallback_uniform_5` | 20/10/57 | +11.49 pp | 0.09874 |
| `retrieval_state_3` vs text baseline | 17/7/63 | +11.49 pp | 0.06391 |
| `retrieval_state_3` vs `history_trunc_k3` | 21/4/62 | +19.54 pp | 0.00091 |
| `retrieval_state_3` vs `category_fallback_state_3` | 16/6/65 | +11.49 pp | 0.05248 |

当前可接受的结论：

- 三 seed 最高均值是 `retrieval_uniform_5`，54.02%，相对 text baseline
  +13.79 pp；它也显著优于 matched `history_trunc_k5`。
- 最稳定的强候选是 `retrieval_state_3`，均值51.72%、SD 3.45；相对
  matched truncation 的配对优势明显。
- `retrieval_uniform_1` 从 seed42 的65.52%下降到 seed44 的31.03%，
  SD 17.70，已不能作为稳定最优候选。
- category fallback 最稳定的是 `uniform_3`，三个 seed 均为44.83%，
  但绝对增益仅+4.60 pp。
- retrieval 相对同 frame/`k` category fallback 的优势为+11.49 pp，
  但 p 值约0.05至0.10，只能视为支持性趋势。

> <span style="color:#c62828"><strong>Stage1/2 已支持“相关成功 demo 能抵消历史截断并提高 frozen OpenHA 成功率”，但候选由同一 train/dev sweep 选出，上述 p 值未经选择偏差和多重比较校正，不能替代 Stage3 strictness 与冻结 TEST_V2。</strong></span>

## 7.1 当前假设审计

| 假设 | 当前判断 | 需要如何修正 |
| --- | --- | --- |
| H1：视觉 ICL 能提升 OpenHA | 部分支持 | 应改为“合适的 demo 策略可以提升”，不是所有图片 ICL 都提升 |
| H2：retrieval 比 category fallback 更重要 | 趋势支持，未确认 | 两个主候选均高11.49 pp，但配对 p≈0.05至0.10；需 Stage3 |
| H3：存在最佳 `k`，不是越多越好 | 支持 | 不同 source/frame 下最佳 `k` 不同 |
| H4：state 选帧稳定优于 uniform | 当前不支持 | state 排名跨 seed 波动，需要机制分析和 state-v2 |
| H5：demo 文本层级是独立杠杆 | 未测试 | 等 Stage5 |
| H6：demo 改变 CoA/action prior | 尚未证明 | ASR 只能说明行为变化，需 Stage4 action/CoA 指标 |
| H7：收益伴随可解释的中间行为变化 | 尚未证明 | 需 parser、first attack、noop、DTW 等指标 |
| H8：外部成功 demo 比在线失败历史更早提供有效先验 | 未测试 | 需 Stage4 经验来源分解与 first-attempt/recovery 指标 |

> <span style="color:#c62828"><strong>当前结果推翻的是“单 seed 排名足够稳定”和“某一种选帧必然最优”，并没有推翻视觉 demonstration 可以帮助 frozen OpenHA 的核心方向。</strong></span>

## 7.2 时间预算

Stage1/2 和 Stage3 strictness 三 seed 已全部完成。Stage3 共 9 个组合
（seed42/43/44 × same-task-allowed/task-excluded/entity-strict），
每个组合固定运行 `prefix_uniform_3`、`retrieval_uniform_5`、
`retrieval_state_3` 三个候选，并自动完成缺失任务补跑。

Stage3 三 protocol 的均值如下：

| Protocol | `prefix_uniform_3` | `retrieval_uniform_5` | `retrieval_state_3` |
| --- | ---: | ---: | ---: |
| `same_task_allowed` | 47.13% | 44.83% | **50.57%** |
| `exclude_eval_task` | 43.68% | 49.43% | **50.57%** |
| `exclude_eval_task_entity` | 50.57% | 48.28% | **50.57%** |

上述是 train/dev strictness 结果，不是 TEST_V2 结果；最终候选仍需进行
bootstrap CI、逐任务 paired analysis 和方法冻结。

- Stage4-B v3 pilot 使用 9 个固定前缀、5 个条件和两种 reference：
  固定的截断条件输出，以及 rollout 中实际记录的 next action；
- phase-aware pilot 使用 12 个固定前缀、5 个条件，覆盖
  `scan`、`approach_onset`、`engage_onset`、`late_execution`；
- 当前 pilot 支持“demo 会在固定 observation/history 下调制 action-token
  likelihood，且少量情况下改变离散 decoded action”；但不支持“成功 demo
  稳定提高 oracle/correct action probability”，因为 recorded action 不是
  oracle GT，且 paired CI 仍较宽；
- 5-task phase-balanced pilot 已达到 19 个固定前缀，覆盖 5 个实体、
  4 个 phase，且 95/95 condition rows 完整；
- full29 phase-balanced replay 已完成：335 条 condition rows、67 个固定前缀、
  29 个实体任务，全部 condition 成对齐全；
- full29 结果显示 success demo 相对 truncation control 的 recorded-action
  mean log-likelihood 为 `+0.0486`，95% CI 为 `[+0.0069,+0.0866]`；
- 但 success demo 相对 negative demo 的差异仅为 `+0.0033`，95% CI
  `[-0.0206,+0.0267]`，因此当前证据支持 demo-induced action-prior
  modulation，不足以证明成功语义的独有效应；
- 下一步转向 action-vector distance、phase alignment、以及闭环 SR/首次
  有效动作的验证，并显式报告 success-vs-negative/category contrasts；
- OPSD-0 已完成：16 条 train、4 条 eval，5 个 entity 做任务级隔离；
  SDPA 兼容的 LoRA smoke 训练 4 steps，最终 train loss `2.1024`、
  eval loss `1.9031`，adapter 已保存并可加载生成 action/CoA 文本；
- OPSD-0 只证明输入、loss、反向传播、adapter 保存/加载链路可运行，
  不证明 student 已经内化 demo prior，也不替代 OPSD-1 的 held-out SR；
- `retrieval_state_3` 在三种 protocol 下均为 50.57%，是当前最稳定候选；
- `retrieval_uniform_5` 的均值受 protocol 影响，不再直接视为默认主方法；
- category fallback 仍作为固定预算和无检索能力的对照。
- Stage3-6 论文核心实验：单卡预计额外 2 至 3 周。
- Stage7-9（LoRA-SFT、CrossHA bare、CrossHA+ICL）：预计额外 1 至 3 周。
- Stage10 demo-conditioned 后训练与性能轨：预计再增加 2 至 4 周，取决于
  OpenVLA/ECoT 数据重组、训练资源和 benchmark rollout 成本。

> **按当前单 GPU 资源，完成 Stage0-9 的论文主体预计还需要约 4 至 6 周；如果能稳定使用两张 GPU，可压缩到约 2 至 3 周。**
> Stage10 属于独立性能扩展，不计入上述冻结模型论文主体周期。

## 8. 统计协议

Stage1/2 必须：

- 使用 seed42、43、44；
- 同一 seed 的不同 arm 保持相同任务顺序；
- 报告 mean ASR、standard deviation 和 95% bootstrap CI；
- 报告逐任务 paired win/loss/tie；
- 使用 paired bootstrap 与 McNemar test 比较候选方法和同 seed baseline；
- 同时报告 `rc`、`missing` 和失败任务列表。

在 action-vector/phase alignment 和闭环 SR 验证完成之前，不为 TEST_V2
冻结最终方法。

## 9. Stage3：Retrieval Strictness

目标：将同任务记忆与跨任务泛化分开。

| 协议 | 规则 | 能说明什么 |
| --- | --- | --- |
| `same_task_allowed` | 允许 exact task/entity demo | 重复任务 memory upper bound |
| `exclude_eval_task` | 当前任务不能作为 demo | 跨任务迁移 |
| `exclude_eval_entity` | 同实体不能作为 demo | 属性级迁移 |
| `heldout_test_only` | TEST_V2 永不进入 demo | official 泛化 |

计划结果表：

| 方法 | 协议 | 任务 | Seeds | Mean ASR | Delta | 备注 |
| --- | --- | --- | --- | ---: | ---: | --- |
| best category fallback | same-task allowed | train/dev | 42,43,44 |  |  | 上限 |
| best category fallback | exclude task/entity | train/dev | 42,43,44 |  |  | 严格设置 |
| best retrieval | same-task allowed | train/dev | 42,43,44 |  |  | 上限 |
| best retrieval | exclude task/entity | train/dev | 42,43,44 |  |  | 严格设置 |

## 9.1 Stage3B：Phase-Aware Compression 与 Learned Retrieval

这一阶段把“更好的 demo”拆成两个不同问题，避免同时修改压缩器和检索器后
无法归因。

### Stage3B-A：Phase-Aware Compression

目标：验证长 rollout 的价值是否集中在任务阶段转换，而不是均匀时间位置。

对 kill task 使用统一阶段：

```text
scan -> approach -> engage -> finish
```

候选关键事件包括首次发现目标、距离快速缩短、首次攻击、连续攻击开始和
成功前状态。只在 Stage2 选出的最多两个 source/`k` 配置上比较：

| Arm | 作用 |
| --- | --- |
| uniform | 时间覆盖基线 |
| state-v1 | 当前手工状态 scorer |
| phase-balanced | 每个阶段至少保留一个关键状态 |
| shuffled-phase | 保留相同帧但打乱阶段顺序 |

通过条件：

- 三 seed 相对 budget-matched uniform 有一致方向；
- paired bootstrap CI 与逐任务 win/loss 不显示明显负迁移；
- first-attack、noop、阶段 DTW 至少一项与 ASR 同方向改善。

### Stage3B-B：Learned Visual-Action Retriever

该阶段是**有门槛的算法扩展**，不是在 Stage1/2 未完成时立即启动。只有当
nearest/random/farthest 或 phase-aware 实验表明“demo 相关性确实决定收益”
时，才训练 learned retriever。

输入与输出：

```text
query instruction + current visual state
        +
candidate rollout visual/action/phase summary
        ->
predicted utility for query next-action and task success
```

训练约束：

- 训练数据只来自 train-only pool；
- 正样本为相关成功 rollout，hard negatives 包括不相关成功、失败、
  shuffled-action 和 farthest rollout；
- 禁止使用 TEST_V2、当前 eval episode 或同一 task/entity；
- retriever 的阈值、embedding 和 checkpoint 必须在 train/dev 冻结。

必须比较：

| Retriever | 科学作用 |
| --- | --- |
| category fallback | 无检索能力对照 |
| hand-crafted attribute retrieval | 当前方法 |
| frozen visual/text embedding retrieval | 无任务训练的语义检索 |
| learned visual-action retriever | 是否能学习 demo 对当前动作的真实效用 |

learned retriever 只有在三 seed 上优于手工 retrieval，并且 off-policy
action-token 指标同步改善时，才升级为论文主方法；否则作为负结果或未来工作。

## 10. Stage4：机制分析

论文需要证明 demonstration 在指导 next-action prediction，而不是随机扰动 prompt。

### 10.1 经验来源的操作性定义

必须区分三种容易混淆的能力：

| 能力 | 可用信息 | 能说明什么 |
| --- | --- | --- |
| current-state replanning | 仅当前 image/state | 模型根据新状态重新决策，不代表从历史学习 |
| within-episode adaptation | 当前状态 + 自己之前的 observation/action/output | 模型是否从本 episode 的动作后果或失败中调整 |
| cross-episode demonstration conditioning | 当前状态 + 其他 episode 的成功经验 | 外部成功记忆能否在执行前提供控制先验 |

本文真正需要检验的是：**外部成功 demo 能否提高第一次有效尝试，并减少
依赖在线失败才能完成的试错；以及它是否与 online history 互补。**

### 10.2 主实验矩阵

固定模型参数、任务、环境 seed、解码设置和最大步数。主实验先在 Stage2
选出的最多两个 `k/source/frame` 配置上运行：

| Arm | 上下文 | 主要问题 |
| --- | --- | --- |
| `current_only_h0` | current observation，不含历史和 demo | 当前状态本身能做到什么 |
| `online_history_h15` | 15-step online history + current | 标准 zero-shot closed-loop adaptation |
| `history_trunc_k` | 最近 `15-k` history + current | 缩短历史的代价，复用 Stage1 |
| `success_demo_only_k` | k 个成功 demo + current | 外部经验在没有在线历史时是否可用 |
| `history_plus_success_demo_k` | k demo + `15-k` history + current | SSRC 主方法，复用 Stage2 |
| `history_plus_random_success_k` | 随机成功 demo + 相同 history | 额外成功图片是否足够 |
| `history_plus_failed_demo_k` | 失败 rollout + 相同 history | 模型是否盲目模仿任意经验 |
| `history_plus_shuffled_demo_k` | 打乱成功帧/动作顺序 + 相同 history | 时序结构是否重要 |

主表使用固定 16-image budget：

```text
online history:        15 history + 1 current
history + demo:        k demo + (15-k) history + 1 current
matched truncation:    0 demo + (15-k) history + 1 current
```

如果模型接口允许更长上下文，可增加一个**独立次要实验**：

```text
15 history + k relevant demo + current
15 history + k irrelevant demo + current
```

该实验只能说明扩展上下文下 demo 是否增益，不能与固定16图主表直接混算。

### 10.3 闭环效率指标

最终成功率之外必须报告：

| 指标 | OpenHA/Minecraft 定义 | 机械臂定义 |
| --- | --- | --- |
| first-attempt success | 首次有效 engage 后是否完成击杀 | 第一次 grasp 是否成功 |
| attempts-to-success | 独立攻击/接触阶段次数 | grasp/regrasp 次数 |
| steps-to-success | episode 开始到成功的动作步数 | 到成功放置的控制步数 |
| failure-recovery rate | 首次 engage 失败后最终成功比例 | 首次抓取失败后恢复比例 |
| repeated-failure ratio | 对相同无效动作模式的重复比例 | 重复空抓、滑落或错误接触比例 |
| success-before-feedback | 尚未经历明显失败前完成的比例 | 第一次失败反馈前完成的比例 |

其中 `success-before-feedback` 和 first-attempt success 是检验外部 demo
价值的核心：online history 必须先产生动作后果，外部成功经验则可能在
第一次尝试前提供 warm start。

执行与统计要求：

- 闭环主实验使用与 Stage1/2 相同的29个 train/dev任务和 seeds 42、43、44；
- 各 arm 使用完全相同的任务顺序、环境 seed、最大步数和解码参数；
- 除固定16张图片外，还要限制相同最大 history text/action token 数；
- first-attempt success 与最终 success 使用 paired McNemar/paired bootstrap；
- attempts、steps-to-success 使用 paired bootstrap，并报告中位数和IQR；
- 对未成功 episode，将 steps-to-success 作为右删失数据，补充 Kaplan-Meier
  或 time-to-event 比较，避免只统计成功样本；
- failure-recovery 只在各 arm 共同经历首次失败的 paired subset 上比较；
- 所有选择和阈值仅在 train/dev 冻结，TEST_V2 不用于定义“尝试”或调参。

计划结果表：

| Arm | Seeds | Final ASR | First-attempt | Attempts ↓ | Steps ↓ | Recovery ↑ | Repeated failure ↓ |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `current_only_h0` | 42,43,44 |  |  |  |  |  |  |
| `online_history_h15` | 42,43,44 |  |  |  |  |  |  |
| `history_trunc_k` | 42,43,44 |  |  |  |  |  |  |
| `success_demo_only_k` | 42,43,44 |  |  |  |  |  |  |
| `history_plus_success_demo_k` | 42,43,44 |  |  |  |  |  |  |
| `history_plus_random_success_k` | 42,43,44 |  |  |  |  |  |  |
| `history_plus_failed_demo_k` | 42,43,44 |  |  |  |  |  |  |
| `history_plus_shuffled_demo_k` | 42,43,44 |  |  |  |  |  |  |

### 10.4 固定状态反事实 Replay

仅观察到“失败几次后成功”不能证明模型从历史中学习，因为当前画面和物体
位置也已经变化。必须从真实 rollout 保存三个 checkpoint：

```text
T0: 第一次尝试前
Tf: 第一次明确失败后
Tr: 开始恢复或切换策略时
```

在完全相同的 current image/state 下，替换上下文：

| Condition | 改动 |
| --- | --- |
| state only | 删除全部历史 |
| true online history | 保留真实 observation/action/output |
| action-masked history | 保留旧 observation，屏蔽历史动作/输出 |
| shuffled online history | 打乱历史顺序 |
| counterfactual failure history | 拼入其他失败动作链 |
| retrieved success demo | 替换为外部相关成功经验 |
| wrong/farthest success demo | 控制额外上下文和成功标签 |
| online history + success demo | 检验互补性 |

不执行环境，只记录 next-action text/token、logit、entropy 和 action vector。
如果固定当前状态后 true history 仍系统性改变动作，才能称为
history-conditioned adaptation；如果只有 current image 决定动作，则更接近
普通闭环 replanning。

每个最终候选方法至少抽取：

- 29个任务各一个 `T0` checkpoint；
- 有明确首次失败的任务各一个 `Tf`；
- 有恢复行为的任务各一个 `Tr`；
- 每个 checkpoint 对全部8种 conditions 使用相同解码 seed；
- 另用 greedy decoding 复核 action shift 是否依赖随机采样。

计划结果表：

| Condition | Action changed | Token KL/JS | Entropy Δ | Demo distance ↓ | Correct phase action ↑ |
| --- | ---: | ---: | ---: | ---: | ---: |
| state only |  |  |  |  |  |
| true online history |  |  |  |  |  |
| action-masked history |  |  |  |  |  |
| shuffled online history |  |  |  |  |  |
| counterfactual failure history |  |  |  |  |  |
| retrieved success demo |  |  |  |  |  |
| wrong/farthest success demo |  |  |  |  |  |
| online history + success demo |  |  |  |  |  |

### 10.5 动作与轨迹指标

动作向量：

```text
a_t = [attack, back, forward, left, right, jump, sprint, sneak,
       use, inventory, pickItem, |camera|]
```

必要指标：

| 指标 | 对应问题 |
| --- | --- |
| action-signature distance | 策略是否更接近成功 demo 的行为分布 |
| JS divergence | 动作组合分布是否发生系统性变化 |
| noop ratio | 是否减少空转和卡住 |
| first-attack step | 是否更早发现并攻击目标 |
| attack burst length | 战斗阶段是否更连贯 |
| camera magnitude | 是否改变扫描和瞄准行为 |
| action jerk | 动作是否更稳定或更混乱 |
| parser validity | 结构化动作输出是否更合法 |
| DTW to demo | 轨迹阶段顺序是否更接近成功 demo |

必要反事实：

- 只缩短 history，不加入 demo；
- random same-category demo；
- random cross-category demo；
- farthest retrieval；
- 打乱或逆序 demo 帧；
- mask/blur demo 图片；
- 正确图片配打乱文本。

Off-policy replay 应固定相同 observation/history，只改变 demo condition，
直接测量 `demo -> next action` 的因果影响。

> <span style="color:#c62828"><strong>机制分析是把工作从“图片 ICL 能提分”提升为“视觉 demonstration 如何调制 CoA/VLA 动作链”的关键。</strong></span>

### 10.6 结果解释规则

| 观察结果 | 允许的结论 |
| --- | --- |
| current-only 与 full history 相同 | 主要是当前状态重规划，不能声称在线 ICL |
| full history 只在失败后改善 | 存在 within-episode recovery，但需要先试错 |
| success demo 提高 T0/first-attempt success | 外部经验提供执行前 warm start |
| history + success demo 最优 | 在线经验与跨 episode 记忆互补 |
| relevant 优于 random/failed/shuffled | 收益来自经验内容，而不是额外上下文 |
| demo 只帮助 OpenHA、不帮助更强模型 | 方法存在能力边界，不作普遍 VLA 主张 |

### 10.7 Frontier Generalist Pilot

GPT-6 或其他闭源 frontier model 的抓取观察只作为独立 pilot。若要写入论文，
必须保存模型精确版本、系统 prompt、输入图像/state、完整输出历史、环境 seed
和逐步视频，并在相同机械臂环境运行上述主矩阵。

未经重复实验和固定状态 replay 的单次“失败后成功”案例，只能作为研究动机，
不能作为模型已经发生 in-context policy learning 的证据，也不能与 OpenHA
ASR 直接比较。

## 11. Stage5：Demo 表示形式

只在 Stage2/3 选出的 top methods 上运行。

| 层级 | Demo 内容 |
| --- | --- |
| `none` | 纯图片 |
| `raw` | 低层动作字典 |
| `model-text` | 模型生成的结构化动作文本 |
| `marked-image` | 目标框、点或 affordance 标记 |
| `phase-tagged` | scan、approach、engage、finish 阶段标签 |

当前 `01_annotated_icl` 数据量不足，正式比较 model-text 前必须扩大
train-only annotated pool。

## 12. Stage6：冻结 TEST_V2

进入条件：

- 三 seed Stage1/2 完成；
- Stage3 strictness 完成；
- 在 train/dev 上选择不超过 3 个最终方法；
- 冻结 retrieval、frame mode、`k` 和方法名称；
- TEST_V2 不存在于任何 demo pool 或 bank。

最终结果表：

| 方法 | 任务 | Seeds | Overall ASR | 分类 ASR | 备注 |
| --- | --- | --- | ---: | --- | --- |
| bare OpenHA text baseline | TEST_V2 77 | 42,43,44 |  |  |  |
| final image ICL method 1 | TEST_V2 77 | 42,43,44 |  |  |  |
| final image ICL method 2 | TEST_V2 77 | 42,43,44 |  |  |  |
| final structured method | TEST_V2 77 | 42,43,44 |  |  | 可选 |

> <span style="color:#c62828"><strong>TEST_V2 是单向评估：看到测试结果后不得再修改方法或选择超参数。</strong></span>

## 13. 鲁棒性与 CrossHA

Stage7：

- 在 LoRA-SFT OpenHA 上重跑冻结后的最佳方法；
- 作为 robustness，而不是主结果。

Stage8：

- 在对齐 benchmark 上评估 CrossHA bare；
- 作为强 SOTA reference。

Stage9：

- 采集 CrossHA 自己的 train-only 成功 rollout；
- 构建 CrossHA-specific bank；
- 在 CrossHA 上验证冻结后的 top ICL 策略；
- OpenHA rollout 到 CrossHA 的迁移仅作为附录 stress test。

> **CrossHA 是对比基线与跨训练范式验证对象，不是本项目主线方法。**

## 13.1 Stage10：Demo-Conditioned 后训练与性能轨

Stage10 只在冻结模型的 Stage1-6 完成并锁定结论后启动，不能反过来修改
冻结实验的方法选择。

训练数据：

- OpenHA/CrossHA：只使用 train-only Minecraft 成功 rollout；
- OpenVLA/ECoT：优先复用其原有机器人训练轨迹，将不同 episode 重组为
  `support demo -> query next action`；
- 若进入新 benchmark，只能使用该 benchmark 官方 train split；
- TEST_V2 或机器人 benchmark test episodes 永不进入 support pool。

训练方式：

- 首选 demo adapter、segment embedding 和 LoRA；
- demo 可包含 image、action text/token，以及 ECoT reasoning；
- loss 只监督 query reasoning/action tokens；
- 随机执行 demo dropout，并加入 irrelevant/shuffled demo；
- 不以全量模型微调作为第一选择。

必须比较：

| Arm | 作用 |
| --- | --- |
| frozen no-demo | 原始能力 |
| frozen + demo | 训练免费 ICL 效应 |
| post-trained no-demo | 普通后训练收益 |
| demo-conditioned post-trained | 后训练后的 ICL 总性能 |
| strong recipe no-demo | OFT/RL 等强性能基线 |
| strong recipe + demo | demo 在强后训练之上的独立增益 |

只有 `demo-conditioned post-trained - post-trained no-demo`，以及
`strong recipe + demo - strong recipe no-demo` 才能归因于 demo conditioning。

> <span style="color:#c62828"><strong>可以把 benchmark SOTA 作为性能轨目标，但主贡献不能依赖 SOTA。优先争取“frozen/no-update setting SOTA”或“同一 autoregressive backbone 与相同后训练预算下 SOTA”；只有在完整官方协议、强基线和多 seed 下超过所有公开方法，才声明 global SOTA。</strong></span>

## 14. 可选高级方向

核心论文稳定后再考虑：

- contact-sheet 关键帧压缩；
- 显式目标或 affordance 标记；
- 扩展到 OpenVLA 的离散 action-token VLA；
- 扩展到 ECoT 的 reasoning-then-action token VLA。

动态 query-conditioned retrieval、视觉/action 联合检索和 phase-balanced
compression 已提升为 Stage3B，不再仅作为未排期的发散方向。

跨 Minecraft 与机械臂 autoregressive next-action VLA 的统一接口、
上游代码接入点和迁移实验阶段见
`Demonstration_Conditioned_VLA_Transfer_Plan_zh.md`。

> **只有当 OpenHA 之外至少一个机械臂 autoregressive action-token VLA
> 复现 demonstration-conditioned 效应后，才提出跨域
> autoregressive next-action VLA 主张；否则结论仍限定在 OpenHA/Minecraft。**

## 15. 接下来执行顺序

1. 聚合已完成的 Stage1/2/3 三 seed 统计、bootstrap CI 与逐任务 paired outcomes。
2. 根据 strictness 结果冻结一个主 retrieval 候选和必要的 category-fallback
   / history control。
3. 完成 Stage4-B fixed-prefix replay，比较 current-only、online history、
   success demo
   和二者联合。
4. 实现 fixed-prefix replay、action-vector 和 action-token 因果分析。
5. 在 train/dev 上冻结不超过 3 个 TEST_V2 方法。
6. 只运行一次 TEST_V2 正式评估。
7. 完成 LoRA-SFT robustness 与 CrossHA 对比。
8. 仅在主线结果稳定后，运行单配置、单 seed 的 Stage11 OPSD pilot。
9. 在独立扩展实验中验证 OpenVLA 或 ECoT，不影响 OpenHA 主协议冻结和
   TEST_V2 决策；π0/Octo 不进入主论文验证链。

## 16. Stage11：Demonstration-Conditioned OPSD

Stage11 建立在 Stage3 strictness 和 Stage4 机制分析之后。它不是当前
frozen image-ICL 主实验的替代品，而是回答一个更深入的问题：

> **成功 demonstration 带来的 next-action prior，能否从推理期 context
> 被蒸馏进不再依赖 demo 的 OpenHA student？**

### 16.1 与当前 ICL 的边界

当前图片 ICL：

```text
success rollout -> retrieve/select demo -> prepend to prompt -> frozen OpenHA
```

不更新 OpenHA 权重，只测 demonstration-conditioned inference。

OPSD：

```text
student rollout prefix
  -> teacher: same OpenHA + privileged success demo
  -> student: same OpenHA without demo
  -> action/CoA token distillation
  -> update student LoRA
```

teacher 与 student 使用相同的基础模型；区别是 teacher 额外看到
success demonstration。student 的 query prefix 必须由当前 student 自己
rollout 产生，才能保留 on-policy 属性。

### 16.2 轨迹标签的定义

success pool 中的 `success.json` 是环境结果级标签，`action.jsonl` 是
实际执行的动作记录。它们可以作为：

- outcome-verified successful demonstration；
- self-generated positive trajectory；
- pseudo-GT action target；
- teacher 的 privileged reference。

除非动作来自人工或环境专家策略，否则不能称为 oracle-optimal action GT。
这不妨碍使用它们做 OPSD，但论文中应使用
`outcome-verified self-generated demonstrations` 等准确表述。

### 16.3 OPSD-0：输入与监督 smoke test

目的：确认多图 demo/query 输入和 query-only supervision 能够训练。

最小输入：

```text
demo image/action context
query observation
query action target
```

要求：

- 使用 `k=3` 和 Stage3 冻结后的最佳 demo source；
- batch size 1，先使用少量样本；
- 冻结视觉 backbone，只训练 LoRA；
- demo action 只能作为 condition，不能进入监督 loss；
- loss 只落在 query action/CoA tokens；
- 检查多图数量、segment 顺序、processor 对齐和 adapter 保存/加载。

通过条件：

- 训练 loss 能下降；
- 输出仍满足 OpenHA parser；
- adapter 可以被现有 `run_streaming_eval_evo.py` 加载；
- 无 demo 输入不会崩溃。

### 16.4 OPSD-1：可运行的 pseudo-label 版本

这是低成本的 OPSD-lite，不要求保存完整 teacher logits。

```text
teacher: success demo + query prefix -> action/CoA text
student: query prefix -> 学习 teacher action/CoA text
```

比较：

| 方法 | teacher 是否看 demo | student 部署时是否看 demo | 是否更新参数 |
| --- | --- | --- | --- |
| frozen no-demo | 否 | 否 | 否 |
| frozen demo teacher | 是 | 是 | 否 |
| ordinary self-imitation SFT | 否 | 否 | 是 |
| OPSD-lite student | 是 | 否 | 是 |

OPSD-lite 的 action text 是 teacher 的 pseudo-label，因此应称为
`pseudo-label self-distillation` 或 `success-conditioned self-training`。
只有在 teacher logits 被用于 token-level distillation 时，才升级为严格
OPSD。

### 16.5 OPSD-2：严格 token-level OPSD

对相同的 student query prefix，分别构造：

```text
student input = observation + online history
teacher input = observation + online history + success demo
```

离线缓存 teacher 的 action/CoA token logits，然后训练 student：

\[
\mathcal{L}_{\mathrm{OPSD}}
=
\sum_{t\in\mathrm{query\ tokens}}
w_t\,\mathrm{KL}
\left(
p_{\mathrm{teacher}}(y_t\mid x_t,d)
\parallel
p_{\mathrm{student}}(y_t\mid x_t)
\right)
\]

优先实验：

| Loss | 作用 |
| --- | --- |
| `L_action` | 只蒸馏低层 action tokens |
| `L_CoA+action` | 同时蒸馏结构化推理与动作 |
| `L_all` | 作为输出风格蒸馏对照，不作为首选 |

训练建议：

- teacher forward 使用 `no_grad`；
- 优先离线缓存 teacher logits，避免训练时同时驻留两个 7B 模型；
- teacher 只使用 train-only success pool；
- student prefix 来自当前 student 的 on-policy rollout；
- 对低置信度 teacher token 降权；
- 训练期加入 demo dropout，防止 student 过度依赖 demo；
- 同时保留普通 self-imitation SFT 对照。

### 16.6 OPSD 必要反事实与准入条件

必须比较：

- relevant success demo；
- random same-category demo；
- failed demo；
- shuffled image/action demo；
- no-demo teacher/student；
- image-only 与 image+executed-action teacher。

进入论文核心结果的条件：

1. frozen demo teacher 在固定 query prefix 上相对 no-demo student
   产生稳定的 action-token shift；
2. OPSD-lite 或 full OPSD student 在**部署时不看 demo**的情况下，
   优于 frozen no-demo；
3. 提升在未参与 teacher/demo 选择的 held-out 任务上保留；
4. action/CoA 指标与 ASR 同方向，而不是只有 parser 或输出格式变化；
5. 普通 self-imitation SFT 不能完全解释该提升。

如果只观察到 teacher 有效、student 蒸馏后无提升，则结论应限定为：

> demonstration 可以作为 privileged inference context，但其能力尚未被
> OpenHA 参数稳定内化。

### 16.7 Stage11 的执行顺序

1. 完成 Stage3 strictness；
2. 完成最小 fixed-prefix action shift 分析；
3. 冻结一个最佳 demo 配置；
4. **已完成** OPSD-0 smoke test；
5. 运行单 seed、单配置的 OPSD-1 pilot；
6. 只有 pilot 有正向结果，才实现 OPSD-2 teacher-logit cache；
7. 在三 seed train/dev 上复现；
8. 最后再决定是否把 OPSD student 纳入 TEST_V2；
9. OpenVLA/ECoT 的 OPSD 迁移放在 OpenHA OPSD 成立之后。

### 16.8 方向 A：ICL ↔ RSI 的受控递归自提升

方向 A 不采用“每一步重新随机换 demo”或“反复试验直到 held-out 变好”的
做法，而采用按 iteration/round 更新的受控 RSI：

```text
M_r = 第 r 轮 student checkpoint
D_r = M_r 在 train-only rollout 上产生的 success-demo bank

M_r no-demo rollout
    -> 成功 rollout 过滤与 phase-aware 选帧
    -> 得到 D_r
    -> teacher = M_r + D_r
    -> student = M_r without demo
    -> student-prefix token-level OPD / LoRA update
    -> candidate M_{r+1}
    -> train/dev promotion gate
```

#### Demo 更新单位

- episode 内：demo 选择一次并缓存；每轮 VLM request 复用同一 demo segment；
- RSI round 间：checkpoint 更新后重新 rollout，再生成新的 `D_{r+1}`；
- 保留固定 `D_anchor` 作为旧经验回放，和当前 `D_r` 混合，防止灾难性遗忘；
- `negative_demo`、`category_demo`、shuffled demo 保留为反事实控制，不作为
  “需要清洗掉的失败数据”。

#### 固定质量门

每轮只按预先注册的规则过滤：

- outcome success；
- train-only 来源；
- action/parser 合法；
- rollout 完整、无损坏帧；
- phase 覆盖；
- 去除高度重复 trajectory；
- teacher confidence、parser validity 和 phase weight 用于 token mask/weight。

阈值只允许在 train/dev 选择，held-out/test 不得参与 demo 清洗、checkpoint
选择或 RSI 停止条件。

#### Checkpoint 晋级

每轮保存 `M_r`、`M_{r+1}^{candidate}` 和 `M_{r+1}^{best}`。候选只有同时满足
以下条件才晋级：

```text
SR(M_{r+1}, no-demo) > SR(M_r, no-demo) + δ
anchor-task retention 不显著下降
parser validity 不下降
negative-demo sensitivity 不异常升高
```

不要依据 train loss 最低或 KL 最低直接选最终 checkpoint；最终 checkpoint
应是 dev gate 通过的 best student，held-out 只做一次最终报告。

#### ICL 与 RSI 的关系指标

```text
ICL_gain_r
  = SR(M_r, D_r) - SR(M_r, no-demo)

Internalization_gain_r
  = SR(M_{r+1}, no-demo) - SR(M_r, no-demo)

Residual_ICL_gain_r
  = SR(M_{r+1}, D_r) - SR(M_{r+1}, no-demo)

Internalization_ratio_r
  = Internalization_gain_r / ICL_gain_r
```

同时记录 first-attempt success、action-token NLL/KL、parser validity、
demo copying、anchor-task retention、每轮新增成功 rollout 数、达到目标 SR
所需轮次和计算成本。

#### 最小 RSI pilot

先运行两轮，不直接扩展到长期递归：

1. `M_0`：frozen no-demo 与 `M_0 + D_0`；
2. `M_0` student-prefix OPSD-3A → `M_1`；
3. 比较 `M_1` no-demo、`M_1 + D_0`；
4. 用 `M_1` 重新生成 `D_1`；
5. 第二轮 OPSD-3A → `M_2`；
6. 比较 `M_2` no-demo、`M_2 + D_1`。

出现以下任一情况即停止 RSI：

- no-demo SR 连续两轮不提升；
- 新增成功 rollout 数饱和；
- train/dev 提升而 anchor task 下降；
- demo copying 增加；
- KL 降低但 action/ASR 不提升；
- student 只有在旧 demo 条件下才有效。

OPSD-3A 是方向 A 的核心 online self-distillation；OPSD-3B 的 teacher
action override/recovery label 属于可选的 DAgger-style interactive extension，
不纳入主方法的必要定义。

<span style="color:#c62828"><strong>Stage11 不是当前主线的前置阻塞项。OpenHA 图片 ICL 即使不产生 OPSD
正结果，也可以形成独立的 frozen demonstration-conditioning 结论；
OPSD 的价值在于进一步验证 demonstration prior 是否能够被模型内部化。</strong></span>
