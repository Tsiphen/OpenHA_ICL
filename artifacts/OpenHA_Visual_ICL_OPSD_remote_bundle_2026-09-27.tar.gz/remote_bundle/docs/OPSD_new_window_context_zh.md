# OpenHA Visual OPSD 新窗口接续上下文

> 更新时间：2026-09-20（Asia/Shanghai）  
> 用途：在新的 Codex 对话线程中恢复 OpenHA Visual OPSD 项目，不要从头重复 OPSD-0。

## 1. 项目定位

当前主线是：

> **Demonstration-conditioned autoregressive next-action VLA**

项目核心对象是 Minecraft OpenHA。CrossHA 是对比基线，不是主线方法。

当前研究分两层：

1. **Frozen visual ICL**
   - 从 train-only 成功 rollout 中选取视觉 demo；
   - 不更新 OpenHA 权重；
   - 研究 demo 是否调制 next-action prediction。
2. **Visual OPSD**
   - teacher：同一个 OpenHA 额外看到 success demo；
   - student：不看 demo；
   - 用 teacher 的 action/CoA 输出蒸馏到 student LoRA；
   - 研究 demonstration-induced action prior 能否被参数内化。

## 2. 服务器连接

以下是项目使用的服务器信息，属于敏感信息，仅在本地项目上下文中使用：

```bash
sshpass -p '7982yg3fb203r' ssh -p 40022 \
  -o StrictHostKeyChecking=no \
  -o UserKnownHostsFile=/dev/null \
  zengqifen@117.74.67.2
```

服务器：

```text
Host: 117.74.67.2
Port: 40022
User: zengqifen
Python: /opt/miniconda3/envs/vllm_env/bin/python
Conda environment: vllm_env
```

实验命令通常需要：

```bash
cd /data3/openha_repro/OpenHA
```

否则 OpenHA 的相对路径可能找不到，例如：

```text
openagents/assets/system_prompt/grounding.txt
```

## 3. 服务器关键路径

```text
OpenHA 复现仓库：
/data3/openha_repro

OpenHA 代码：
/data3/openha_repro/OpenHA

OpenHA 模型：
/data3/openha_repro/models/minecraft-openha-qwen2vl-7b-2509

OpenHA 项目旧代码：
/data3/openha_evo

项目新实验根目录，优先使用：
/mnt/yrfs/tsiphen/ICL-OpenHA

train-only success pool：
/data3/openha_evo/eval/icl_success_pool/00_original_icl_trainonly

retrieval memory bank：
/data3/openha_evo/eval/icl_memory_bank/kill_entity_bank.json

正式 Stage3 rollout：
/data3/openha_evo/probe_stage3_strict
```

### 存储约束

新实验结果、训练数据、adapter 和日志都放在：

```text
/mnt/yrfs/tsiphen/ICL-OpenHA
```

不要把新的大文件放在 `/data3`。最近检查时：

```text
/mnt/yrfs：约 8.5 TB 可用
/data3：约 89 GB 可用，接近满载
/：约 34 GB 可用，约 96% 使用率
```

## 4. 现有实验进度

### Stage1/2

- `51/51 arms` 完成；
- 全部 `missing=0`；
- 使用 seeds 42、43、44。

### Stage3 strictness

- `27/27 arms` 完成；
- 9 个 seed × protocol 组合；
- 全部 `rc=0`、`missing=0`；
- 主要 protocol：
  - `same_task_allowed`
  - `exclude_eval_task`
  - `exclude_eval_task_entity`

### Stage4-A

- 已完成约 `783` 条 rollout 的动作描述性分析；
- 仅是描述性统计，不是 fixed-prefix 因果证据。

### Stage4-B full29

已完成 full29 phase-balanced fixed-prefix replay：

```text
29 个实体任务
67 个有效 fixed prefixes
4 个 phase：
  scan
  approach_onset
  engage_onset
  late_execution
5 个 condition：
  truncation_control
  current_history
  success_demo
  category_demo
  negative_demo
335/335 condition rows 完整
```

结果：

```text
success_demo 相对 truncation_control 的 recorded-action mean log-likelihood:
+0.0486
95% bootstrap CI:
[+0.0069, +0.0866]

success_demo 相对 negative_demo:
+0.0033
95% bootstrap CI:
[-0.0206, +0.0267]
```

decoded action flip：

```text
success_demo: 21/67
category_demo: 14/67
negative_demo: 22/67
```

目前可以支持的结论：

> demonstration 会在固定 observation/history 下调制 action-token likelihood，
> 并在部分前缀上改变离散动作；作用具有 phase dependence。

目前不能支持的结论：

> success demo 已被证明比 negative/category demo 更能指导正确动作。

原因是 `recorded_next_action` 不是 oracle action GT，且 success-vs-negative
差异的置信区间跨 0。

full29 报告：

```text
/mnt/yrfs/tsiphen/ICL-OpenHA/stage4_mechanism/fixed_prefix_v1/results/phase_balanced_full29_seed42_analysis.md
```

## 5. OPSD 当前状态

### OPSD-0：已完成

OPSD-0 使用：

```text
teacher target = full29 replay 中 success_demo 的 teacher 输出
student input = 当前 query image + instruction，不含 demo
student model = Qwen2-VL-7B + LoRA
```

数据：

```text
16 条 train
4 条 eval
5 个 entity
train/eval 按 entity 做隔离
```

processor smoke：

```text
student 单图输入正常
teacher 多图输入正常：
  2 张图
  约 807 input tokens
```

LoRA smoke：

```text
4/4 steps 完成
train loss: 2.1024
eval loss: 1.9031
trainable params: 20,185,088
all params: 8,311,560,704
trainable ratio: 0.243%
```

adapter 已成功加载，并在 no-demo 输入下生成合法的 OpenHA 风格 CoA/action。

OPSD-0 产物：

```text
/mnt/yrfs/tsiphen/ICL-OpenHA/opsd/opsd0_smoke_seed42/
```

目录包含：

```text
train.jsonl
eval.jsonl
teacher_smoke.jsonl
manifest.json
student_adapter/final_adapter/adapter_model.safetensors
```

代码：

```text
/Users/tsiphenzeng/openha_evo/build_opsd0_smoke.py
/Users/tsiphenzeng/openha_evo/train_opsd0_lora_sdpa.py
```

远端代码：

```text
/mnt/yrfs/tsiphen/ICL-OpenHA/opsd/code/build_opsd0_smoke.py
/mnt/yrfs/tsiphen/ICL-OpenHA/opsd/code/train_opsd0_lora_sdpa.py
```

### 重要：OPSD-0 不是完整 OPSD 结果

OPSD-0 只证明：

- 多图输入 processor 能运行；
- LoRA loss 能下降；
- student adapter 能保存/加载；
- no-demo student 能生成 action/CoA 文本。

它没有证明：

- student 已经学会 demonstration prior；
- held-out SR 提升；
- OPSD 优于 ordinary self-imitation；
- success demo 的语义效应已被参数内化。

## 6. 下一步必须自动执行

不要重新运行 OPSD-0。正确顺序如下。

### OPSD-1：full pseudo-label student

full29 replay 实际只有 16 个任务满足 4 个 phase 前缀，因此使用：

```text
16 个有效实体任务
64 个 fixed prefixes
60 train
4 task-disjoint eval
```

上一次构造失败的原因是错误请求了 17 个任务：

```text
RuntimeError: Only found 16 eligible tasks, requested 17
```

应自动改用：

```bash
--tasks 16 --prefixes-per-task 4
```

输出目录建议：

```text
/mnt/yrfs/tsiphen/ICL-OpenHA/opsd/opsd1_seed42/
```

### OPSD-1 对照

必须至少准备：

```text
frozen no-demo
frozen success-demo teacher
ordinary self-imitation SFT student
OPSD-1 pseudo-label student
```

ordinary self-imitation 应使用相同 query prefix，但 target 改为 rollout 中
实际记录并 canonicalize 的 action text，不使用 success-demo teacher 输出。

### OPSD-2：token-level teacher-logit distillation

输入：

```text
teacher = query observation/history + success demo
student = query observation/history，不含 demo
```

目标：

```text
teacher action/CoA token distribution
        -> student token-level KL
```

工程要求：

- teacher `no_grad`；
- teacher logits 离线缓存；
- student 只计算 query action/CoA token loss；
- 优先 `L_action`；
- 再做 `L_CoA+action`；
- 添加 teacher confidence weighting；
- 保留 ordinary self-imitation 对照；
- 所有 teacher demo 必须来自 train-only pool；
- held-out task 不得进入 demo pool 或调参。

注意：现有 `/data3/openha_repro/train_openha_lora_sft.py` 强制使用
`flash_attention_2`，服务器环境没有 `flash_attn`。训练应使用项目内已经
跑通的 SDPA 入口：

```text
/mnt/yrfs/tsiphen/ICL-OpenHA/opsd/code/train_opsd0_lora_sdpa.py
```

如果实现 OPSD-2，需要新增 SDPA-compatible token-KL trainer，而不是修改
共享 OpenHA 训练脚本。

## 7. 评估准入条件

OPSD student 只有同时满足以下条件，才能写成论文中的正结果：

1. no-demo deployment 下优于 frozen no-demo；
2. 优于 ordinary self-imitation SFT；
3. 在 held-out task 上仍然提升；
4. action/CoA 指标与 SR 同方向；
5. parser 合法率提升不是唯一收益；
6. success-demo teacher 与 negative/category-demo teacher 存在可解释差异；
7. student 不依赖 demo 才能运行。

如果 teacher 有效但 student 没有提升，最终结论应写成：

> demonstration 是有效的 privileged inference context，但其 action prior
> 尚未被 OpenHA 参数稳定内化。

## 8. 自动化执行要求

新窗口不要等待用户判断，按以下原则自行推进：

- 先检查已有 checkpoint、`status.json` 和进程；
- 已完成阶段直接跳过；
- 数据不足时自动降低到实际有效任务数，不要直接失败；
- 训练/评估命令使用 `nohup`、`< /dev/null` 和明确日志；
- 新输出全部写 `/mnt/yrfs/tsiphen/ICL-OpenHA/opsd/`；
- 每个阶段写：

```text
status.json
manifest.json
stdout/stderr log
checkpoint
```

- 失败时保留错误日志，并自动选择已定义的 fallback，不要删除已有结果；
- 不要把 smoke 数字写入论文主结果；
- 完成后生成：

```text
/mnt/yrfs/tsiphen/ICL-OpenHA/opsd/FINAL_OPSD_REPORT_ZH.md
```

## 9. 新窗口直接执行的指令

把下面这段作为新窗口第一条消息：

```text
请继续自动完成 OpenHA Visual OPSD 全流水线。

读取：
/Users/tsiphenzeng/openha_evo/OPSD_new_window_context_zh.md

从已完成的 OPSD-0 恢复，不要重跑 OPSD-0。
full29 replay 实际只有 16 个满足 4 phase 前缀的任务，因此 OPSD-1
使用 16 个任务、60 train + 4 task-disjoint eval。

自动执行：
1. OPSD-1 full pseudo-label student；
2. ordinary self-imitation 对照；
3. frozen no-demo / frozen success-demo / negative/category-demo 对照；
4. held-out rollout 评估；
5. OPSD-2 token-level teacher-logit distillation；
6. held-out 复评；
7. 生成 FINAL_OPSD_REPORT_ZH.md。

不要等待我判断。所有新结果放：
/mnt/yrfs/tsiphen/ICL-OpenHA/opsd/
```

## 10. 文档位置

主计划：

```text
/Users/tsiphenzeng/openha_evo/OpenHA_ICL_paper_plan_zh.md
```

论文故事：

```text
/Users/tsiphenzeng/openha_evo/OpenHA_ICL_paper_story_zh.md
```

最终文档索引：

```text
/Users/tsiphenzeng/openha_evo/FINAL_DOCUMENTS_INDEX_ZH.md
```

当前论文叙事边界：

```text
Frozen ICL = 当前已有机制证据
Visual OPSD = 第二层待验证的 parameter-space internalization
```

不要把 OPSD-0 的可训练性 smoke 写成 OPSD 已经成功。
