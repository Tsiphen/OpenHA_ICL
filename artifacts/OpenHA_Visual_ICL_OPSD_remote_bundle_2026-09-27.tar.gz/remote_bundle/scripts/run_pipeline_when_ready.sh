#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="$ROOT/config/sources.env"
source "$CONFIG"

mkdir -p "$EXPERIMENT_ROOT"/{logs,status,opsd,stage4}
bash "$ROOT/scripts/check_remote_sources.sh"

cat > "$EXPERIMENT_ROOT/status/pipeline_status.json" <<JSON
{
  "project": "ICL-OpenHA",
  "protocol": "Visual ICL -> OPSD-1 -> ordinary self-imitation -> OPSD-2",
  "status": "sources_verified",
  "host": "$(hostname)",
  "openha_root": "$OPENHA_ROOT",
  "model": "$OPENHA_MODEL",
  "success_pool": "$SUCCESS_POOL",
  "memory_bank": "$MEMORY_BANK",
  "full29_replay": "$FULL29_REPLAY"
}
JSON

echo "[ready] Sources verified."
echo "[next] Run the commands in docs/REMOTE_RUNBOOK_ZH.md after reviewing GPU ownership."
echo "[guard] This wrapper does not kill processes, overwrite ENV_RUN, or invent missing data."
