#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="$ROOT/config/sources.env"

if [[ ! -f "$CONFIG" ]]; then
  echo "[blocked] Missing $CONFIG"
  echo "Copy config/sources.env.example to config/sources.env and fill internal paths."
  exit 2
fi

# shellcheck disable=SC1090
source "$CONFIG"

missing=0
for pair in \
  "OPENHA_ROOT:$OPENHA_ROOT" \
  "OPENHA_MODEL:$OPENHA_MODEL" \
  "SUCCESS_POOL:$SUCCESS_POOL" \
  "MEMORY_BANK:$MEMORY_BANK" \
  "FULL29_REPLAY:$FULL29_REPLAY"; do
  name="${pair%%:*}"
  value="${pair#*:}"
  if [[ -z "$value" || ! -e "$value" ]]; then
    echo "[missing] $name=$value"
    missing=1
  else
    echo "[ok] $name=$value"
  fi
done

echo "[env] host=$(hostname)"
echo "[env] pwd=$(pwd)"
command -v "${OPENHA_PYTHON:-python3}" || true
nvidia-smi --query-gpu=index,name,memory.total,memory.free,utilization.gpu --format=csv,noheader || true
df -h "$ROOT" || true

if [[ "$missing" -ne 0 ]]; then
  echo "[blocked] Internal OpenHA/model/data sources are incomplete."
  exit 3
fi

echo "[ready] All required source paths exist."
