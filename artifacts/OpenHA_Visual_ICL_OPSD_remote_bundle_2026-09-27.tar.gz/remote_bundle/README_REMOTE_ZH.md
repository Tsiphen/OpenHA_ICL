# OpenHA Visual ICL / Visual OPSD Remote Bundle

本 bundle 对应截至 2026-09-27 的方向 A 故事：

```text
OpenHA frozen visual ICL
-> SSRC: source isolation + retrieval + sparse keyframes + budget control
-> fixed-prefix mechanism replay
-> OPSD-1 pseudo-label student
-> OPSD-2 offline teacher-logit token KL
-> OPSD-3A online student-prefix visual teacher correction
```

## 重要边界

这个 bundle 不包含以下大文件：

- OpenHA 源码及 Minecraft 环境；
- Qwen2-VL/OpenHA、teacher/student 模型权重；
- train-only success rollout pool；
- full29 replay 与 benchmark 原始数据。

远端机器没有这些来源时，bootstrap 会停止并列出缺失项，不会把师兄的
`ENV_RUN` 当成项目目录，也不会覆盖其中的文件。

## 目录

```text
code/        ICL、memory、Stage3、Stage4、OPSD-0/1/2、held-out scripts
docs/        最新 story、paper plan、OPSD context、历史 report
scripts/     远程环境检查、来源检查、运行队列模板
config/      sources.env.example、实验 manifest
```

## 远端使用

```bash
cd ~/projects/ICL-OpenHA
bash scripts/check_remote_sources.sh
```

先复制并填写：

```bash
cp config/sources.env.example config/sources.env
```

必须填写：

```bash
OPENHA_ROOT=
OPENHA_MODEL=
SUCCESS_POOL=
MEMORY_BANK=
FULL29_REPLAY=
```

来源检查通过后再执行：

```bash
bash scripts/run_pipeline_when_ready.sh
```

脚本会先写 manifest/status，再按以下顺序执行：

```text
source check
-> frozen ICL offline/config validation
-> Stage4 mechanism replay
-> OPSD-1 60 train + 4 task-disjoint eval
-> ordinary self-imitation control
-> OPSD-2 token-level teacher-logit KL
-> held-out token/generation checks
```

OPSD-3A 需要额外的 OpenHA Minecraft online rollout service；在没有环境入口时
只会生成 protocol/status，不会伪称 online OPSD 已完成。
